#GLPI Dump database on 2017-08-29 23:03

### Dump table glpi_alerts

DROP TABLE IF EXISTS `glpi_alerts`;
CREATE TABLE `glpi_alerts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '0' COMMENT 'see define.php ALERT_* constant',
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`itemtype`,`items_id`,`type`),
  KEY `type` (`type`),
  KEY `date` (`date`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_apiclients

DROP TABLE IF EXISTS `glpi_apiclients`;
CREATE TABLE `glpi_apiclients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `ipv4_range_start` bigint(20) DEFAULT NULL,
  `ipv4_range_end` bigint(20) DEFAULT NULL,
  `ipv6` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `app_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `app_token_date` datetime DEFAULT NULL,
  `dolog_method` tinyint(4) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `is_active` (`is_active`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_apiclients` VALUES ('1','0','1','full access from localhost',NULL,'1','2130706433','2130706433','::1','',NULL,'0',NULL);

### Dump table glpi_authldapreplicates

DROP TABLE IF EXISTS `glpi_authldapreplicates`;
CREATE TABLE `glpi_authldapreplicates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `authldaps_id` int(11) NOT NULL DEFAULT '0',
  `host` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `port` int(11) NOT NULL DEFAULT '389',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `authldaps_id` (`authldaps_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_authldaps

DROP TABLE IF EXISTS `glpi_authldaps`;
CREATE TABLE `glpi_authldaps` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `host` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `basedn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rootdn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `port` int(11) NOT NULL DEFAULT '389',
  `condition` text COLLATE utf8_unicode_ci,
  `login_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'uid',
  `use_tls` tinyint(1) NOT NULL DEFAULT '0',
  `group_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `group_condition` text COLLATE utf8_unicode_ci,
  `group_search_type` int(11) NOT NULL DEFAULT '0',
  `group_member_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email1_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `realname_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `firstname_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone2_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `use_dn` tinyint(1) NOT NULL DEFAULT '1',
  `time_offset` int(11) NOT NULL DEFAULT '0' COMMENT 'in seconds',
  `deref_option` int(11) NOT NULL DEFAULT '0',
  `title_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `category_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entity_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entity_condition` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `rootdn_passwd` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `registration_number_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email2_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email3_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email4_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `location_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pagesize` int(11) NOT NULL DEFAULT '0',
  `ldap_maxlimit` int(11) NOT NULL DEFAULT '0',
  `can_support_pagesize` tinyint(1) NOT NULL DEFAULT '0',
  `picture_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `is_default` (`is_default`),
  KEY `is_active` (`is_active`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_authldaps` VALUES ('1','SaludPol','192.168.0.9','OU=SaludPol,DC=saludpol,DC=local','fmendoza@saludpol.local','389','','samaccountname','0','memberof','(&(objectClass=user)(objectCategory=person)(!(userAccountControl:1.2.840.113556.1.4.803:=2)))','2','','','sn','givenname','telephonenumber','othertelephone','mobile','info','1','0','0','title',NULL,NULL,'ou','(objectclass=organizationalUnit)','2017-08-24 15:37:20','','1','1','94e/w8DyFa1eqqU=','employeenumber','mail','','',NULL,'0','0','0',NULL,'2017-08-22 23:43:30');

### Dump table glpi_authmails

DROP TABLE IF EXISTS `glpi_authmails`;
CREATE TABLE `glpi_authmails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `connect_string` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `host` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `is_active` (`is_active`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_authmails` VALUES ('1','Servidor de Correo SaludPol','{zimbra.saludpol.gob.pe:465}','zimbra.saludpol.gob.pe','2017-08-24 14:44:45','','1');

### Dump table glpi_autoupdatesystems

DROP TABLE IF EXISTS `glpi_autoupdatesystems`;
CREATE TABLE `glpi_autoupdatesystems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_blacklistedmailcontents

DROP TABLE IF EXISTS `glpi_blacklistedmailcontents`;
CREATE TABLE `glpi_blacklistedmailcontents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8_unicode_ci,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_blacklists

DROP TABLE IF EXISTS `glpi_blacklists`;
CREATE TABLE `glpi_blacklists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `type` (`type`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_blacklists` VALUES ('1','1','empty IP','',NULL,NULL,NULL);
INSERT INTO `glpi_blacklists` VALUES ('2','1','localhost','127.0.0.1',NULL,NULL,NULL);
INSERT INTO `glpi_blacklists` VALUES ('3','1','zero IP','0.0.0.0',NULL,NULL,NULL);
INSERT INTO `glpi_blacklists` VALUES ('4','2','empty MAC','',NULL,NULL,NULL);

### Dump table glpi_bookmarks

DROP TABLE IF EXISTS `glpi_bookmarks`;
CREATE TABLE `glpi_bookmarks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` int(11) NOT NULL DEFAULT '0' COMMENT 'see define.php BOOKMARK_* constant',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `is_private` tinyint(1) NOT NULL DEFAULT '1',
  `entities_id` int(11) NOT NULL DEFAULT '-1',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `query` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `type` (`type`),
  KEY `itemtype` (`itemtype`),
  KEY `entities_id` (`entities_id`),
  KEY `users_id` (`users_id`),
  KEY `is_private` (`is_private`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_bookmarks_users

DROP TABLE IF EXISTS `glpi_bookmarks_users`;
CREATE TABLE `glpi_bookmarks_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `bookmarks_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`users_id`,`itemtype`),
  KEY `bookmarks_id` (`bookmarks_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_budgets

DROP TABLE IF EXISTS `glpi_budgets`;
CREATE TABLE `glpi_budgets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `begin_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `value` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `budgettypes_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_recursive` (`is_recursive`),
  KEY `entities_id` (`entities_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `begin_date` (`begin_date`),
  KEY `is_template` (`is_template`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `locations_id` (`locations_id`),
  KEY `budgettypes_id` (`budgettypes_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_budgettypes

DROP TABLE IF EXISTS `glpi_budgettypes`;
CREATE TABLE `glpi_budgettypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_calendars

DROP TABLE IF EXISTS `glpi_calendars`;
CREATE TABLE `glpi_calendars` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `cache_duration` text COLLATE utf8_unicode_ci,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_calendars` VALUES ('1','Default','0','1','Default calendar',NULL,'[0,43200,43200,43200,43200,43200,0]',NULL);

### Dump table glpi_calendars_holidays

DROP TABLE IF EXISTS `glpi_calendars_holidays`;
CREATE TABLE `glpi_calendars_holidays` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `calendars_id` int(11) NOT NULL DEFAULT '0',
  `holidays_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`calendars_id`,`holidays_id`),
  KEY `holidays_id` (`holidays_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_calendarsegments

DROP TABLE IF EXISTS `glpi_calendarsegments`;
CREATE TABLE `glpi_calendarsegments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `calendars_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `day` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'numer of the day based on date(w)',
  `begin` time DEFAULT NULL,
  `end` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `calendars_id` (`calendars_id`),
  KEY `day` (`day`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_calendarsegments` VALUES ('1','1','0','0','1','08:00:00','20:00:00');
INSERT INTO `glpi_calendarsegments` VALUES ('2','1','0','0','2','08:00:00','20:00:00');
INSERT INTO `glpi_calendarsegments` VALUES ('3','1','0','0','3','08:00:00','20:00:00');
INSERT INTO `glpi_calendarsegments` VALUES ('4','1','0','0','4','08:00:00','20:00:00');
INSERT INTO `glpi_calendarsegments` VALUES ('5','1','0','0','5','08:00:00','20:00:00');

### Dump table glpi_cartridgeitems

DROP TABLE IF EXISTS `glpi_cartridgeitems`;
CREATE TABLE `glpi_cartridgeitems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ref` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `cartridgeitemtypes_id` int(11) NOT NULL DEFAULT '0',
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `alarm_threshold` int(11) NOT NULL DEFAULT '10',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `locations_id` (`locations_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `cartridgeitemtypes_id` (`cartridgeitemtypes_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `alarm_threshold` (`alarm_threshold`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_cartridgeitems` VALUES ('1','0','0','CF281X','','0','0','0','0','0','1','','10','2017-08-24 11:56:39','2017-08-24 11:51:10');

### Dump table glpi_cartridgeitems_printermodels

DROP TABLE IF EXISTS `glpi_cartridgeitems_printermodels`;
CREATE TABLE `glpi_cartridgeitems_printermodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cartridgeitems_id` int(11) NOT NULL DEFAULT '0',
  `printermodels_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`printermodels_id`,`cartridgeitems_id`),
  KEY `cartridgeitems_id` (`cartridgeitems_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_cartridgeitemtypes

DROP TABLE IF EXISTS `glpi_cartridgeitemtypes`;
CREATE TABLE `glpi_cartridgeitemtypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_cartridges

DROP TABLE IF EXISTS `glpi_cartridges`;
CREATE TABLE `glpi_cartridges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `cartridgeitems_id` int(11) NOT NULL DEFAULT '0',
  `printers_id` int(11) NOT NULL DEFAULT '0',
  `date_in` date DEFAULT NULL,
  `date_use` date DEFAULT NULL,
  `date_out` date DEFAULT NULL,
  `pages` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cartridgeitems_id` (`cartridgeitems_id`),
  KEY `printers_id` (`printers_id`),
  KEY `entities_id` (`entities_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_changecosts

DROP TABLE IF EXISTS `glpi_changecosts`;
CREATE TABLE `glpi_changecosts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `changes_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `begin_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `actiontime` int(11) NOT NULL DEFAULT '0',
  `cost_time` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `cost_fixed` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `cost_material` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `budgets_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `changes_id` (`changes_id`),
  KEY `begin_date` (`begin_date`),
  KEY `end_date` (`end_date`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `budgets_id` (`budgets_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_changes

DROP TABLE IF EXISTS `glpi_changes`;
CREATE TABLE `glpi_changes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '1',
  `content` longtext COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `solvedate` datetime DEFAULT NULL,
  `closedate` datetime DEFAULT NULL,
  `due_date` datetime DEFAULT NULL,
  `users_id_recipient` int(11) NOT NULL DEFAULT '0',
  `users_id_lastupdater` int(11) NOT NULL DEFAULT '0',
  `urgency` int(11) NOT NULL DEFAULT '1',
  `impact` int(11) NOT NULL DEFAULT '1',
  `priority` int(11) NOT NULL DEFAULT '1',
  `itilcategories_id` int(11) NOT NULL DEFAULT '0',
  `impactcontent` longtext COLLATE utf8_unicode_ci,
  `controlistcontent` longtext COLLATE utf8_unicode_ci,
  `rolloutplancontent` longtext COLLATE utf8_unicode_ci,
  `backoutplancontent` longtext COLLATE utf8_unicode_ci,
  `checklistcontent` longtext COLLATE utf8_unicode_ci,
  `global_validation` int(11) NOT NULL DEFAULT '1',
  `validation_percent` int(11) NOT NULL DEFAULT '0',
  `solutiontypes_id` int(11) NOT NULL DEFAULT '0',
  `solution` longtext COLLATE utf8_unicode_ci,
  `actiontime` int(11) NOT NULL DEFAULT '0',
  `begin_waiting_date` datetime DEFAULT NULL,
  `waiting_duration` int(11) NOT NULL DEFAULT '0',
  `close_delay_stat` int(11) NOT NULL DEFAULT '0',
  `solve_delay_stat` int(11) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `is_deleted` (`is_deleted`),
  KEY `date` (`date`),
  KEY `closedate` (`closedate`),
  KEY `status` (`status`),
  KEY `priority` (`priority`),
  KEY `date_mod` (`date_mod`),
  KEY `itilcategories_id` (`itilcategories_id`),
  KEY `users_id_recipient` (`users_id_recipient`),
  KEY `solvedate` (`solvedate`),
  KEY `solutiontypes_id` (`solutiontypes_id`),
  KEY `urgency` (`urgency`),
  KEY `impact` (`impact`),
  KEY `due_date` (`due_date`),
  KEY `global_validation` (`global_validation`),
  KEY `users_id_lastupdater` (`users_id_lastupdater`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_changes_groups

DROP TABLE IF EXISTS `glpi_changes_groups`;
CREATE TABLE `glpi_changes_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `changes_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`changes_id`,`type`,`groups_id`),
  KEY `group` (`groups_id`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_changes_items

DROP TABLE IF EXISTS `glpi_changes_items`;
CREATE TABLE `glpi_changes_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `changes_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`changes_id`,`itemtype`,`items_id`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_changes_problems

DROP TABLE IF EXISTS `glpi_changes_problems`;
CREATE TABLE `glpi_changes_problems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `changes_id` int(11) NOT NULL DEFAULT '0',
  `problems_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`changes_id`,`problems_id`),
  KEY `problems_id` (`problems_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_changes_projects

DROP TABLE IF EXISTS `glpi_changes_projects`;
CREATE TABLE `glpi_changes_projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `changes_id` int(11) NOT NULL DEFAULT '0',
  `projects_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`changes_id`,`projects_id`),
  KEY `projects_id` (`projects_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_changes_suppliers

DROP TABLE IF EXISTS `glpi_changes_suppliers`;
CREATE TABLE `glpi_changes_suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `changes_id` int(11) NOT NULL DEFAULT '0',
  `suppliers_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '1',
  `use_notification` tinyint(1) NOT NULL DEFAULT '0',
  `alternative_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`changes_id`,`type`,`suppliers_id`),
  KEY `group` (`suppliers_id`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_changes_tickets

DROP TABLE IF EXISTS `glpi_changes_tickets`;
CREATE TABLE `glpi_changes_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `changes_id` int(11) NOT NULL DEFAULT '0',
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`changes_id`,`tickets_id`),
  KEY `tickets_id` (`tickets_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_changes_users

DROP TABLE IF EXISTS `glpi_changes_users`;
CREATE TABLE `glpi_changes_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `changes_id` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '1',
  `use_notification` tinyint(1) NOT NULL DEFAULT '0',
  `alternative_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`changes_id`,`type`,`users_id`,`alternative_email`),
  KEY `user` (`users_id`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_changetasks

DROP TABLE IF EXISTS `glpi_changetasks`;
CREATE TABLE `glpi_changetasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `changes_id` int(11) NOT NULL DEFAULT '0',
  `taskcategories_id` int(11) NOT NULL DEFAULT '0',
  `state` int(11) NOT NULL DEFAULT '0',
  `date` datetime DEFAULT NULL,
  `begin` datetime DEFAULT NULL,
  `end` datetime DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `content` longtext COLLATE utf8_unicode_ci,
  `actiontime` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `changes_id` (`changes_id`),
  KEY `state` (`state`),
  KEY `users_id` (`users_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `date` (`date`),
  KEY `date_mod` (`date_mod`),
  KEY `begin` (`begin`),
  KEY `end` (`end`),
  KEY `taskcategories_id` (`taskcategories_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_changevalidations

DROP TABLE IF EXISTS `glpi_changevalidations`;
CREATE TABLE `glpi_changevalidations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  `changes_id` int(11) NOT NULL DEFAULT '0',
  `users_id_validate` int(11) NOT NULL DEFAULT '0',
  `comment_submission` text COLLATE utf8_unicode_ci,
  `comment_validation` text COLLATE utf8_unicode_ci,
  `status` int(11) NOT NULL DEFAULT '2',
  `submission_date` datetime DEFAULT NULL,
  `validation_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `users_id` (`users_id`),
  KEY `users_id_validate` (`users_id_validate`),
  KEY `changes_id` (`changes_id`),
  KEY `submission_date` (`submission_date`),
  KEY `validation_date` (`validation_date`),
  KEY `status` (`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_computerantiviruses

DROP TABLE IF EXISTS `glpi_computerantiviruses`;
CREATE TABLE `glpi_computerantiviruses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `computers_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `antivirus_version` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `signature_version` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_uptodate` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `date_expiration` datetime DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `antivirus_version` (`antivirus_version`),
  KEY `signature_version` (`signature_version`),
  KEY `is_active` (`is_active`),
  KEY `is_uptodate` (`is_uptodate`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `is_deleted` (`is_deleted`),
  KEY `computers_id` (`computers_id`),
  KEY `date_expiration` (`date_expiration`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_computerdisks

DROP TABLE IF EXISTS `glpi_computerdisks`;
CREATE TABLE `glpi_computerdisks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `computers_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `device` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mountpoint` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `filesystems_id` int(11) NOT NULL DEFAULT '0',
  `totalsize` int(11) NOT NULL DEFAULT '0',
  `freesize` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `device` (`device`),
  KEY `mountpoint` (`mountpoint`),
  KEY `totalsize` (`totalsize`),
  KEY `freesize` (`freesize`),
  KEY `computers_id` (`computers_id`),
  KEY `filesystems_id` (`filesystems_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_computermodels

DROP TABLE IF EXISTS `glpi_computermodels`;
CREATE TABLE `glpi_computermodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_computers

DROP TABLE IF EXISTS `glpi_computers`;
CREATE TABLE `glpi_computers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_num` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `operatingsystems_id` int(11) NOT NULL DEFAULT '0',
  `operatingsystemversions_id` int(11) NOT NULL DEFAULT '0',
  `operatingsystemservicepacks_id` int(11) NOT NULL DEFAULT '0',
  `operatingsystemarchitectures_id` int(11) NOT NULL DEFAULT '0',
  `os_license_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `os_licenseid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `os_kernel_version` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `autoupdatesystems_id` int(11) NOT NULL DEFAULT '0',
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `domains_id` int(11) NOT NULL DEFAULT '0',
  `networks_id` int(11) NOT NULL DEFAULT '0',
  `computermodels_id` int(11) NOT NULL DEFAULT '0',
  `computertypes_id` int(11) NOT NULL DEFAULT '0',
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  `ticket_tco` decimal(20,4) DEFAULT '0.0000',
  `uuid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `name` (`name`),
  KEY `is_template` (`is_template`),
  KEY `autoupdatesystems_id` (`autoupdatesystems_id`),
  KEY `domains_id` (`domains_id`),
  KEY `entities_id` (`entities_id`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `groups_id` (`groups_id`),
  KEY `users_id` (`users_id`),
  KEY `locations_id` (`locations_id`),
  KEY `computermodels_id` (`computermodels_id`),
  KEY `networks_id` (`networks_id`),
  KEY `operatingsystems_id` (`operatingsystems_id`),
  KEY `operatingsystemservicepacks_id` (`operatingsystemservicepacks_id`),
  KEY `operatingsystemversions_id` (`operatingsystemversions_id`),
  KEY `operatingsystemarchitectures_id` (`operatingsystemarchitectures_id`),
  KEY `states_id` (`states_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `computertypes_id` (`computertypes_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `serial` (`serial`),
  KEY `otherserial` (`otherserial`),
  KEY `uuid` (`uuid`),
  KEY `date_creation` (`date_creation`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_computers_items

DROP TABLE IF EXISTS `glpi_computers_items`;
CREATE TABLE `glpi_computers_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to various table, according to itemtype (ID)',
  `computers_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `computers_id` (`computers_id`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_computers_softwarelicenses

DROP TABLE IF EXISTS `glpi_computers_softwarelicenses`;
CREATE TABLE `glpi_computers_softwarelicenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `computers_id` int(11) NOT NULL DEFAULT '0',
  `softwarelicenses_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`computers_id`,`softwarelicenses_id`),
  KEY `computers_id` (`computers_id`),
  KEY `softwarelicenses_id` (`softwarelicenses_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_computers_softwareversions

DROP TABLE IF EXISTS `glpi_computers_softwareversions`;
CREATE TABLE `glpi_computers_softwareversions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `computers_id` int(11) NOT NULL DEFAULT '0',
  `softwareversions_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted_computer` tinyint(1) NOT NULL DEFAULT '0',
  `is_template_computer` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `date_install` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`computers_id`,`softwareversions_id`),
  KEY `softwareversions_id` (`softwareversions_id`),
  KEY `computers_info` (`entities_id`,`is_template_computer`,`is_deleted_computer`),
  KEY `is_template` (`is_template_computer`),
  KEY `is_deleted` (`is_deleted_computer`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `date_install` (`date_install`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_computertypes

DROP TABLE IF EXISTS `glpi_computertypes`;
CREATE TABLE `glpi_computertypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_computervirtualmachines

DROP TABLE IF EXISTS `glpi_computervirtualmachines`;
CREATE TABLE `glpi_computervirtualmachines` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `computers_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `virtualmachinestates_id` int(11) NOT NULL DEFAULT '0',
  `virtualmachinesystems_id` int(11) NOT NULL DEFAULT '0',
  `virtualmachinetypes_id` int(11) NOT NULL DEFAULT '0',
  `uuid` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `vcpu` int(11) NOT NULL DEFAULT '0',
  `ram` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `computers_id` (`computers_id`),
  KEY `entities_id` (`entities_id`),
  KEY `name` (`name`),
  KEY `virtualmachinestates_id` (`virtualmachinestates_id`),
  KEY `virtualmachinesystems_id` (`virtualmachinesystems_id`),
  KEY `vcpu` (`vcpu`),
  KEY `ram` (`ram`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `uuid` (`uuid`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_configs

DROP TABLE IF EXISTS `glpi_configs`;
CREATE TABLE `glpi_configs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `context` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`context`,`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_configs` VALUES ('1','core','version','9.1.6');
INSERT INTO `glpi_configs` VALUES ('2','core','show_jobs_at_login','0');
INSERT INTO `glpi_configs` VALUES ('3','core','cut','500');
INSERT INTO `glpi_configs` VALUES ('4','core','list_limit','15');
INSERT INTO `glpi_configs` VALUES ('5','core','list_limit_max','50');
INSERT INTO `glpi_configs` VALUES ('6','core','url_maxlength','30');
INSERT INTO `glpi_configs` VALUES ('7','core','event_loglevel','5');
INSERT INTO `glpi_configs` VALUES ('8','core','use_mailing','1');
INSERT INTO `glpi_configs` VALUES ('9','core','admin_email','soporte@saludpol.gob.pe');
INSERT INTO `glpi_configs` VALUES ('10','core','admin_email_name','Soporte Técnico');
INSERT INTO `glpi_configs` VALUES ('11','core','admin_reply','soporte@saludpol.gob.pe');
INSERT INTO `glpi_configs` VALUES ('12','core','admin_reply_name','Soporte Técnico');
INSERT INTO `glpi_configs` VALUES ('13','core','mailing_signature','Sistema de Incidencias - SaludPol');
INSERT INTO `glpi_configs` VALUES ('14','core','use_anonymous_helpdesk','0');
INSERT INTO `glpi_configs` VALUES ('15','core','use_anonymous_followups','0');
INSERT INTO `glpi_configs` VALUES ('16','core','language','es_419');
INSERT INTO `glpi_configs` VALUES ('17','core','priority_1','#fff2f2');
INSERT INTO `glpi_configs` VALUES ('18','core','priority_2','#ffe0e0');
INSERT INTO `glpi_configs` VALUES ('19','core','priority_3','#ffcece');
INSERT INTO `glpi_configs` VALUES ('20','core','priority_4','#ffbfbf');
INSERT INTO `glpi_configs` VALUES ('21','core','priority_5','#ffadad');
INSERT INTO `glpi_configs` VALUES ('22','core','priority_6','#ff5555');
INSERT INTO `glpi_configs` VALUES ('23','core','date_tax','2017-01-02');
INSERT INTO `glpi_configs` VALUES ('24','core','cas_host','');
INSERT INTO `glpi_configs` VALUES ('25','core','cas_port','443');
INSERT INTO `glpi_configs` VALUES ('26','core','cas_uri','');
INSERT INTO `glpi_configs` VALUES ('27','core','cas_logout','');
INSERT INTO `glpi_configs` VALUES ('28','core','existing_auth_server_field_clean_domain','0');
INSERT INTO `glpi_configs` VALUES ('29','core','planning_begin','08:00');
INSERT INTO `glpi_configs` VALUES ('30','core','planning_end','20:00');
INSERT INTO `glpi_configs` VALUES ('31','core','utf8_conv','1');
INSERT INTO `glpi_configs` VALUES ('32','core','use_public_faq','1');
INSERT INTO `glpi_configs` VALUES ('33','core','url_base','http://192.168.1.96/sist_inc');
INSERT INTO `glpi_configs` VALUES ('34','core','show_link_in_mail','0');
INSERT INTO `glpi_configs` VALUES ('35','core','text_login','Bienvenidos, para acceder al sistema ingrese el mismo usuario y clave utilizado para acceder a su PC.');
INSERT INTO `glpi_configs` VALUES ('36','core','founded_new_version','');
INSERT INTO `glpi_configs` VALUES ('37','core','dropdown_max','100');
INSERT INTO `glpi_configs` VALUES ('38','core','ajax_wildcard','*');
INSERT INTO `glpi_configs` VALUES ('42','core','ajax_limit_count','50');
INSERT INTO `glpi_configs` VALUES ('43','core','use_ajax_autocompletion','1');
INSERT INTO `glpi_configs` VALUES ('44','core','is_users_auto_add','1');
INSERT INTO `glpi_configs` VALUES ('45','core','date_format','1');
INSERT INTO `glpi_configs` VALUES ('46','core','number_format','0');
INSERT INTO `glpi_configs` VALUES ('47','core','csv_delimiter',';');
INSERT INTO `glpi_configs` VALUES ('48','core','is_ids_visible','0');
INSERT INTO `glpi_configs` VALUES ('50','core','smtp_mode','2');
INSERT INTO `glpi_configs` VALUES ('51','core','smtp_host','zimbra.saludpol.gob.pe');
INSERT INTO `glpi_configs` VALUES ('52','core','smtp_port','465');
INSERT INTO `glpi_configs` VALUES ('53','core','smtp_username','fmendoza@saludpol.gob.pe');
INSERT INTO `glpi_configs` VALUES ('54','core','proxy_name','');
INSERT INTO `glpi_configs` VALUES ('55','core','proxy_port','8080');
INSERT INTO `glpi_configs` VALUES ('56','core','proxy_user','');
INSERT INTO `glpi_configs` VALUES ('57','core','add_followup_on_update_ticket','1');
INSERT INTO `glpi_configs` VALUES ('58','core','keep_tickets_on_delete','0');
INSERT INTO `glpi_configs` VALUES ('59','core','time_step','5');
INSERT INTO `glpi_configs` VALUES ('60','core','decimal_number','2');
INSERT INTO `glpi_configs` VALUES ('61','core','helpdesk_doc_url','');
INSERT INTO `glpi_configs` VALUES ('62','core','central_doc_url','');
INSERT INTO `glpi_configs` VALUES ('63','core','documentcategories_id_forticket','0');
INSERT INTO `glpi_configs` VALUES ('64','core','monitors_management_restrict','1');
INSERT INTO `glpi_configs` VALUES ('65','core','phones_management_restrict','1');
INSERT INTO `glpi_configs` VALUES ('66','core','peripherals_management_restrict','1');
INSERT INTO `glpi_configs` VALUES ('67','core','printers_management_restrict','1');
INSERT INTO `glpi_configs` VALUES ('68','core','use_log_in_files','1');
INSERT INTO `glpi_configs` VALUES ('69','core','time_offset','0');
INSERT INTO `glpi_configs` VALUES ('70','core','is_contact_autoupdate','1');
INSERT INTO `glpi_configs` VALUES ('71','core','is_user_autoupdate','1');
INSERT INTO `glpi_configs` VALUES ('72','core','is_group_autoupdate','1');
INSERT INTO `glpi_configs` VALUES ('73','core','is_location_autoupdate','1');
INSERT INTO `glpi_configs` VALUES ('74','core','state_autoupdate_mode','0');
INSERT INTO `glpi_configs` VALUES ('75','core','is_contact_autoclean','0');
INSERT INTO `glpi_configs` VALUES ('76','core','is_user_autoclean','0');
INSERT INTO `glpi_configs` VALUES ('77','core','is_group_autoclean','0');
INSERT INTO `glpi_configs` VALUES ('78','core','is_location_autoclean','0');
INSERT INTO `glpi_configs` VALUES ('79','core','state_autoclean_mode','0');
INSERT INTO `glpi_configs` VALUES ('80','core','use_flat_dropdowntree','0');
INSERT INTO `glpi_configs` VALUES ('81','core','use_autoname_by_entity','1');
INSERT INTO `glpi_configs` VALUES ('84','core','softwarecategories_id_ondelete','1');
INSERT INTO `glpi_configs` VALUES ('85','core','x509_email_field','');
INSERT INTO `glpi_configs` VALUES ('86','core','x509_cn_restrict','');
INSERT INTO `glpi_configs` VALUES ('87','core','x509_o_restrict','');
INSERT INTO `glpi_configs` VALUES ('88','core','x509_ou_restrict','');
INSERT INTO `glpi_configs` VALUES ('89','core','default_mailcollector_filesize_max','10485760');
INSERT INTO `glpi_configs` VALUES ('90','core','followup_private','0');
INSERT INTO `glpi_configs` VALUES ('91','core','task_private','0');
INSERT INTO `glpi_configs` VALUES ('92','core','default_software_helpdesk_visible','0');
INSERT INTO `glpi_configs` VALUES ('93','core','names_format','0');
INSERT INTO `glpi_configs` VALUES ('94','core','default_graphtype','svg');
INSERT INTO `glpi_configs` VALUES ('95','core','default_requesttypes_id','1');
INSERT INTO `glpi_configs` VALUES ('96','core','use_noright_users_add','1');
INSERT INTO `glpi_configs` VALUES ('97','core','cron_limit','5');
INSERT INTO `glpi_configs` VALUES ('98','core','priority_matrix','{\"1\":{\"1\":\"1\",\"2\":\"1\",\"3\":\"2\",\"4\":\"2\",\"5\":\"2\"},\"2\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"2\",\"4\":\"3\",\"5\":\"3\"},\"3\":{\"1\":\"2\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"4\"},\"4\":{\"1\":\"2\",\"2\":\"3\",\"3\":\"4\",\"4\":\"4\",\"5\":\"5\"},\"5\":{\"1\":\"2\",\"2\":\"3\",\"3\":\"4\",\"4\":\"5\",\"5\":\"5\"}}');
INSERT INTO `glpi_configs` VALUES ('99','core','urgency_mask','62');
INSERT INTO `glpi_configs` VALUES ('100','core','impact_mask','62');
INSERT INTO `glpi_configs` VALUES ('101','core','user_deleted_ldap','4');
INSERT INTO `glpi_configs` VALUES ('102','core','auto_create_infocoms','0');
INSERT INTO `glpi_configs` VALUES ('103','core','use_slave_for_search','0');
INSERT INTO `glpi_configs` VALUES ('104','core','proxy_passwd','');
INSERT INTO `glpi_configs` VALUES ('105','core','smtp_passwd','94e/w8DyFa1eqqU=');
INSERT INTO `glpi_configs` VALUES ('106','core','transfers_id_auto','0');
INSERT INTO `glpi_configs` VALUES ('107','core','show_count_on_tabs','1');
INSERT INTO `glpi_configs` VALUES ('108','core','refresh_ticket_list','0');
INSERT INTO `glpi_configs` VALUES ('109','core','set_default_tech','0');
INSERT INTO `glpi_configs` VALUES ('110','core','allow_search_view','2');
INSERT INTO `glpi_configs` VALUES ('111','core','allow_search_all','1');
INSERT INTO `glpi_configs` VALUES ('112','core','allow_search_global','1');
INSERT INTO `glpi_configs` VALUES ('113','core','display_count_on_home','5');
INSERT INTO `glpi_configs` VALUES ('114','core','use_password_security','0');
INSERT INTO `glpi_configs` VALUES ('115','core','password_min_length','8');
INSERT INTO `glpi_configs` VALUES ('116','core','password_need_number','1');
INSERT INTO `glpi_configs` VALUES ('117','core','password_need_letter','1');
INSERT INTO `glpi_configs` VALUES ('118','core','password_need_caps','1');
INSERT INTO `glpi_configs` VALUES ('119','core','password_need_symbol','1');
INSERT INTO `glpi_configs` VALUES ('120','core','use_check_pref','0');
INSERT INTO `glpi_configs` VALUES ('121','core','notification_to_myself','1');
INSERT INTO `glpi_configs` VALUES ('122','core','duedateok_color','#06ff00');
INSERT INTO `glpi_configs` VALUES ('123','core','duedatewarning_color','#ffb800');
INSERT INTO `glpi_configs` VALUES ('124','core','duedatecritical_color','#ff0000');
INSERT INTO `glpi_configs` VALUES ('125','core','duedatewarning_less','20');
INSERT INTO `glpi_configs` VALUES ('126','core','duedatecritical_less','5');
INSERT INTO `glpi_configs` VALUES ('127','core','duedatewarning_unit','%');
INSERT INTO `glpi_configs` VALUES ('128','core','duedatecritical_unit','%');
INSERT INTO `glpi_configs` VALUES ('129','core','realname_ssofield','');
INSERT INTO `glpi_configs` VALUES ('130','core','firstname_ssofield','');
INSERT INTO `glpi_configs` VALUES ('131','core','email1_ssofield','');
INSERT INTO `glpi_configs` VALUES ('132','core','email2_ssofield','');
INSERT INTO `glpi_configs` VALUES ('133','core','email3_ssofield','');
INSERT INTO `glpi_configs` VALUES ('134','core','email4_ssofield','');
INSERT INTO `glpi_configs` VALUES ('135','core','phone_ssofield','');
INSERT INTO `glpi_configs` VALUES ('136','core','phone2_ssofield','');
INSERT INTO `glpi_configs` VALUES ('137','core','mobile_ssofield','');
INSERT INTO `glpi_configs` VALUES ('138','core','comment_ssofield','');
INSERT INTO `glpi_configs` VALUES ('139','core','title_ssofield','');
INSERT INTO `glpi_configs` VALUES ('140','core','category_ssofield','');
INSERT INTO `glpi_configs` VALUES ('141','core','language_ssofield','');
INSERT INTO `glpi_configs` VALUES ('142','core','entity_ssofield','');
INSERT INTO `glpi_configs` VALUES ('143','core','registration_number_ssofield','');
INSERT INTO `glpi_configs` VALUES ('144','core','ssovariables_id','0');
INSERT INTO `glpi_configs` VALUES ('145','core','translate_kb','0');
INSERT INTO `glpi_configs` VALUES ('146','core','translate_dropdowns','0');
INSERT INTO `glpi_configs` VALUES ('147','core','pdffont','helvetica');
INSERT INTO `glpi_configs` VALUES ('148','core','keep_devices_when_purging_item','0');
INSERT INTO `glpi_configs` VALUES ('149','core','maintenance_mode','0');
INSERT INTO `glpi_configs` VALUES ('150','core','maintenance_text','');
INSERT INTO `glpi_configs` VALUES ('151','core','use_rich_text','1');
INSERT INTO `glpi_configs` VALUES ('152','core','attach_ticket_documents_to_mail','1');
INSERT INTO `glpi_configs` VALUES ('153','core','backcreated','0');
INSERT INTO `glpi_configs` VALUES ('154','core','task_state','1');
INSERT INTO `glpi_configs` VALUES ('155','core','layout','lefttab');
INSERT INTO `glpi_configs` VALUES ('156','core','ticket_timeline','1');
INSERT INTO `glpi_configs` VALUES ('157','core','ticket_timeline_keep_replaced_tabs','0');
INSERT INTO `glpi_configs` VALUES ('158','core','palette','auror');
INSERT INTO `glpi_configs` VALUES ('159','core','lock_use_lock_item','0');
INSERT INTO `glpi_configs` VALUES ('160','core','lock_autolock_mode','1');
INSERT INTO `glpi_configs` VALUES ('161','core','lock_directunlock_notification','0');
INSERT INTO `glpi_configs` VALUES ('162','core','lock_item_list','[]');
INSERT INTO `glpi_configs` VALUES ('163','core','lock_lockprofile_id','8');
INSERT INTO `glpi_configs` VALUES ('164','core','set_default_requester','0');
INSERT INTO `glpi_configs` VALUES ('165','core','highcontrast_css','0');
INSERT INTO `glpi_configs` VALUES ('166','core','smtp_check_certificate','1');
INSERT INTO `glpi_configs` VALUES ('167','core','enable_api','0');
INSERT INTO `glpi_configs` VALUES ('168','core','enable_api_login_credentials','0');
INSERT INTO `glpi_configs` VALUES ('169','core','enable_api_login_external_token','1');
INSERT INTO `glpi_configs` VALUES ('170','core','url_base_api','http://localhost/sist_inc/apirest.php/');
INSERT INTO `glpi_configs` VALUES ('171','core','_no_history','');
INSERT INTO `glpi_configs` VALUES ('172','core','_date_tax','02-01');
INSERT INTO `glpi_configs` VALUES ('173','core','_matrix','1');
INSERT INTO `glpi_configs` VALUES ('174','core','_impact_5','1');
INSERT INTO `glpi_configs` VALUES ('175','core','_impact_4','1');
INSERT INTO `glpi_configs` VALUES ('176','core','_impact_3','1');
INSERT INTO `glpi_configs` VALUES ('177','core','_impact_2','1');
INSERT INTO `glpi_configs` VALUES ('178','core','_impact_1','1');
INSERT INTO `glpi_configs` VALUES ('179','core','_urgency_5','1');
INSERT INTO `glpi_configs` VALUES ('180','core','_matrix_5_5','5');
INSERT INTO `glpi_configs` VALUES ('181','core','_matrix_5_4','5');
INSERT INTO `glpi_configs` VALUES ('182','core','_matrix_5_3','4');
INSERT INTO `glpi_configs` VALUES ('183','core','_matrix_5_2','3');
INSERT INTO `glpi_configs` VALUES ('184','core','_matrix_5_1','2');
INSERT INTO `glpi_configs` VALUES ('185','core','_urgency_4','1');
INSERT INTO `glpi_configs` VALUES ('186','core','_matrix_4_5','5');
INSERT INTO `glpi_configs` VALUES ('187','core','_matrix_4_4','4');
INSERT INTO `glpi_configs` VALUES ('188','core','_matrix_4_3','4');
INSERT INTO `glpi_configs` VALUES ('189','core','_matrix_4_2','3');
INSERT INTO `glpi_configs` VALUES ('190','core','_matrix_4_1','2');
INSERT INTO `glpi_configs` VALUES ('191','core','_urgency_3','1');
INSERT INTO `glpi_configs` VALUES ('192','core','_matrix_3_5','4');
INSERT INTO `glpi_configs` VALUES ('193','core','_matrix_3_4','4');
INSERT INTO `glpi_configs` VALUES ('194','core','_matrix_3_3','3');
INSERT INTO `glpi_configs` VALUES ('195','core','_matrix_3_2','2');
INSERT INTO `glpi_configs` VALUES ('196','core','_matrix_3_1','2');
INSERT INTO `glpi_configs` VALUES ('197','core','_urgency_2','1');
INSERT INTO `glpi_configs` VALUES ('198','core','_matrix_2_5','3');
INSERT INTO `glpi_configs` VALUES ('199','core','_matrix_2_4','3');
INSERT INTO `glpi_configs` VALUES ('200','core','_matrix_2_3','2');
INSERT INTO `glpi_configs` VALUES ('201','core','_matrix_2_2','2');
INSERT INTO `glpi_configs` VALUES ('202','core','_matrix_2_1','1');
INSERT INTO `glpi_configs` VALUES ('203','core','_urgency_1','1');
INSERT INTO `glpi_configs` VALUES ('204','core','_matrix_1_5','2');
INSERT INTO `glpi_configs` VALUES ('205','core','_matrix_1_4','2');
INSERT INTO `glpi_configs` VALUES ('206','core','_matrix_1_3','2');
INSERT INTO `glpi_configs` VALUES ('207','core','_matrix_1_2','1');
INSERT INTO `glpi_configs` VALUES ('208','core','_matrix_1_1','1');
INSERT INTO `glpi_configs` VALUES ('209','core','update_auth','Registrar');

### Dump table glpi_consumableitems

DROP TABLE IF EXISTS `glpi_consumableitems`;
CREATE TABLE `glpi_consumableitems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ref` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `consumableitemtypes_id` int(11) NOT NULL DEFAULT '0',
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `alarm_threshold` int(11) NOT NULL DEFAULT '10',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `locations_id` (`locations_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `consumableitemtypes_id` (`consumableitemtypes_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `alarm_threshold` (`alarm_threshold`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_consumableitemtypes

DROP TABLE IF EXISTS `glpi_consumableitemtypes`;
CREATE TABLE `glpi_consumableitemtypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_consumables

DROP TABLE IF EXISTS `glpi_consumables`;
CREATE TABLE `glpi_consumables` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `consumableitems_id` int(11) NOT NULL DEFAULT '0',
  `date_in` date DEFAULT NULL,
  `date_out` date DEFAULT NULL,
  `itemtype` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_in` (`date_in`),
  KEY `date_out` (`date_out`),
  KEY `consumableitems_id` (`consumableitems_id`),
  KEY `entities_id` (`entities_id`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_contacts

DROP TABLE IF EXISTS `glpi_contacts`;
CREATE TABLE `glpi_contacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `firstname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fax` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contacttypes_id` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `usertitles_id` int(11) NOT NULL DEFAULT '0',
  `address` text COLLATE utf8_unicode_ci,
  `postcode` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `town` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `contacttypes_id` (`contacttypes_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `usertitles_id` (`usertitles_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_contacts_suppliers

DROP TABLE IF EXISTS `glpi_contacts_suppliers`;
CREATE TABLE `glpi_contacts_suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `suppliers_id` int(11) NOT NULL DEFAULT '0',
  `contacts_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`suppliers_id`,`contacts_id`),
  KEY `contacts_id` (`contacts_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_contacttypes

DROP TABLE IF EXISTS `glpi_contacttypes`;
CREATE TABLE `glpi_contacttypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_contractcosts

DROP TABLE IF EXISTS `glpi_contractcosts`;
CREATE TABLE `glpi_contractcosts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contracts_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `begin_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `cost` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `budgets_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `contracts_id` (`contracts_id`),
  KEY `begin_date` (`begin_date`),
  KEY `end_date` (`end_date`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `budgets_id` (`budgets_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_contracts

DROP TABLE IF EXISTS `glpi_contracts`;
CREATE TABLE `glpi_contracts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `num` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contracttypes_id` int(11) NOT NULL DEFAULT '0',
  `begin_date` date DEFAULT NULL,
  `duration` int(11) NOT NULL DEFAULT '0',
  `notice` int(11) NOT NULL DEFAULT '0',
  `periodicity` int(11) NOT NULL DEFAULT '0',
  `billing` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `accounting_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `week_begin_hour` time NOT NULL DEFAULT '00:00:00',
  `week_end_hour` time NOT NULL DEFAULT '00:00:00',
  `saturday_begin_hour` time NOT NULL DEFAULT '00:00:00',
  `saturday_end_hour` time NOT NULL DEFAULT '00:00:00',
  `use_saturday` tinyint(1) NOT NULL DEFAULT '0',
  `monday_begin_hour` time NOT NULL DEFAULT '00:00:00',
  `monday_end_hour` time NOT NULL DEFAULT '00:00:00',
  `use_monday` tinyint(1) NOT NULL DEFAULT '0',
  `max_links_allowed` int(11) NOT NULL DEFAULT '0',
  `alert` int(11) NOT NULL DEFAULT '0',
  `renewal` int(11) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `begin_date` (`begin_date`),
  KEY `name` (`name`),
  KEY `contracttypes_id` (`contracttypes_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `use_monday` (`use_monday`),
  KEY `use_saturday` (`use_saturday`),
  KEY `alert` (`alert`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_contracts_items

DROP TABLE IF EXISTS `glpi_contracts_items`;
CREATE TABLE `glpi_contracts_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contracts_id` int(11) NOT NULL DEFAULT '0',
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`contracts_id`,`itemtype`,`items_id`),
  KEY `FK_device` (`items_id`,`itemtype`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_contracts_suppliers

DROP TABLE IF EXISTS `glpi_contracts_suppliers`;
CREATE TABLE `glpi_contracts_suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `suppliers_id` int(11) NOT NULL DEFAULT '0',
  `contracts_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`suppliers_id`,`contracts_id`),
  KEY `contracts_id` (`contracts_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_contracttypes

DROP TABLE IF EXISTS `glpi_contracttypes`;
CREATE TABLE `glpi_contracttypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_crontasklogs

DROP TABLE IF EXISTS `glpi_crontasklogs`;
CREATE TABLE `glpi_crontasklogs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `crontasks_id` int(11) NOT NULL,
  `crontasklogs_id` int(11) NOT NULL COMMENT 'id of ''start'' event',
  `date` datetime NOT NULL,
  `state` int(11) NOT NULL COMMENT '0:start, 1:run, 2:stop',
  `elapsed` float NOT NULL COMMENT 'time elapsed since start',
  `volume` int(11) NOT NULL COMMENT 'for statistics',
  `content` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'message',
  PRIMARY KEY (`id`),
  KEY `date` (`date`),
  KEY `crontasks_id` (`crontasks_id`),
  KEY `crontasklogs_id_state` (`crontasklogs_id`,`state`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_crontasklogs` VALUES ('1','18','0','2017-08-22 17:33:25','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('2','18','1','2017-08-22 17:33:25','2','0.047262','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('3','19','0','2017-08-22 17:35:00','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('4','19','3','2017-08-22 17:35:00','2','0.0180838','0','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('5','20','0','2017-08-22 17:39:07','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('6','20','5','2017-08-22 17:39:07','2','0.0407729','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('7','21','0','2017-08-22 17:59:15','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('8','21','7','2017-08-22 17:59:15','2','0.0796411','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('9','22','0','2017-08-22 18:15:33','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('10','22','9','2017-08-22 18:15:33','2','0.16318','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('11','23','0','2017-08-22 18:16:39','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('12','23','11','2017-08-22 18:16:39','2','0.052875','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('13','24','0','2017-08-22 18:41:29','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('14','24','13','2017-08-22 18:41:29','1','0.021342','1','Clean 1 temporary file created since more than 3600 seconds
');
INSERT INTO `glpi_crontasklogs` VALUES ('15','24','13','2017-08-22 18:41:29','2','0.0219359','1','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('16','25','0','2017-08-22 18:53:05','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('17','25','16','2017-08-22 18:53:05','2','0.0169702','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('18','5','0','2017-08-22 18:54:17','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('19','5','18','2017-08-22 18:54:17','2','0.0245421','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('20','6','0','2017-08-22 18:58:40','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('21','6','20','2017-08-22 18:58:40','2','0.019568','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('22','8','0','2017-08-22 19:00:22','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('23','8','22','2017-08-22 19:00:22','2','3.20933','248','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('24','9','0','2017-08-22 19:04:02','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('25','9','24','2017-08-22 19:04:02','2','0.034961','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('26','12','0','2017-08-22 19:10:58','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('27','12','26','2017-08-22 19:10:58','1','0.036612','5','Limpiar 5 archivos de sesión creados de mas de 1440 segundos
');
INSERT INTO `glpi_crontasklogs` VALUES ('28','12','26','2017-08-22 19:10:58','2','0.037137','5','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('29','13','0','2017-08-22 19:17:42','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('30','13','29','2017-08-22 19:17:42','1','0.020817','1','Limpiar 1 archivo de gráfico creado de mas de 3600 segundos
');
INSERT INTO `glpi_crontasklogs` VALUES ('31','13','29','2017-08-22 19:17:42','2','0.0215039','1','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('32','14','0','2017-08-22 19:18:30','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('33','14','32','2017-08-22 19:18:30','2','0.01613','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('34','15','0','2017-08-22 19:24:28','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('35','15','34','2017-08-22 19:24:28','2','0.034445','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('36','16','0','2017-08-22 19:29:16','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('37','16','36','2017-08-22 19:29:16','2','0.0170999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('38','17','0','2017-08-22 19:29:30','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('39','17','38','2017-08-22 19:29:30','2','0.0199411','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('40','21','0','2017-08-22 19:34:51','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('41','21','40','2017-08-22 19:34:51','2','0.0157599','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('42','22','0','2017-08-22 19:40:12','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('43','22','42','2017-08-22 19:40:12','2','0.033833','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('44','20','0','2017-08-22 19:48:31','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('45','20','44','2017-08-22 19:48:31','2','0.0235479','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('46','9','0','2017-08-22 19:52:34','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('47','9','46','2017-08-22 19:52:34','2','0.0750282','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('48','17','0','2017-08-22 19:54:14','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('49','17','48','2017-08-22 19:54:14','2','0.0245888','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('50','21','0','2017-08-22 20:01:12','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('51','21','50','2017-08-22 20:01:12','2','0.0275719','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('52','22','0','2017-08-22 20:06:20','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('53','22','52','2017-08-22 20:06:20','2','0.026814','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('54','24','0','2017-08-22 20:06:22','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('55','24','54','2017-08-22 20:06:22','2','0.019007','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('56','17','0','2017-08-22 21:24:18','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('57','17','56','2017-08-22 21:24:18','2','0.0204029','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('58','9','0','2017-08-22 21:25:51','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('59','9','58','2017-08-22 21:25:51','2','0.0391729','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('60','21','0','2017-08-22 21:28:46','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('61','21','60','2017-08-22 21:28:46','2','0.0202661','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('62','22','0','2017-08-22 21:29:58','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('63','22','62','2017-08-22 21:29:58','2','0.0165701','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('64','13','0','2017-08-22 21:30:01','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('65','13','64','2017-08-22 21:30:01','2','0.015897','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('66','14','0','2017-08-22 21:30:02','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('67','14','66','2017-08-22 21:30:02','2','0.0183551','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('68','20','0','2017-08-22 21:30:13','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('69','20','68','2017-08-22 21:30:13','2','0.0165031','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('70','24','0','2017-08-22 21:37:08','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('71','24','70','2017-08-22 21:37:08','2','0.024261','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('72','17','0','2017-08-22 21:40:01','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('73','17','72','2017-08-22 21:40:01','2','0.0182099','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('74','22','0','2017-08-22 21:47:52','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('75','22','74','2017-08-22 21:47:52','2','0.0244431','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('76','21','0','2017-08-22 21:47:53','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('77','21','76','2017-08-22 21:47:53','2','0.0264621','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('78','9','0','2017-08-22 21:49:24','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('79','9','78','2017-08-22 21:49:24','2','0.027993','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('80','17','0','2017-08-22 21:50:01','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('81','17','80','2017-08-22 21:50:01','2','0.019707','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('82','22','0','2017-08-22 21:50:26','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('83','22','82','2017-08-22 21:50:26','2','0.018131','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('84','22','0','2017-08-22 21:59:38','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('85','22','84','2017-08-22 21:59:38','2','0.015811','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('86','21','0','2017-08-22 22:01:15','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('87','21','86','2017-08-22 22:01:15','2','0.018127','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('88','17','0','2017-08-22 22:01:58','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('89','17','88','2017-08-22 22:01:58','2','0.0162289','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('90','9','0','2017-08-22 22:01:59','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('91','9','90','2017-08-22 22:01:59','2','0.0419099','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('92','22','0','2017-08-22 22:02:01','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('93','22','92','2017-08-22 22:02:01','2','0.0184','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('94','22','0','2017-08-22 22:04:08','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('95','22','94','2017-08-22 22:04:08','2','0.021348','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('96','22','0','2017-08-22 22:05:21','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('97','22','96','2017-08-22 22:05:21','2','0.0210419','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('98','17','0','2017-08-22 22:09:03','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('99','17','98','2017-08-22 22:09:03','2','0.0203519','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('100','21','0','2017-08-22 22:09:20','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('101','21','100','2017-08-22 22:09:20','2','0.0299242','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('102','22','0','2017-08-22 22:10:33','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('103','22','102','2017-08-22 22:10:33','2','0.016561','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('104','22','0','2017-08-22 22:12:29','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('105','22','104','2017-08-22 22:12:29','2','0.0161362','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('106','9','0','2017-08-22 22:12:53','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('107','9','106','2017-08-22 22:12:53','2','0.0410521','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('108','22','0','2017-08-22 22:29:46','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('109','22','108','2017-08-22 22:29:46','2','0.0191171','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('110','17','0','2017-08-22 22:34:49','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('111','17','110','2017-08-22 22:34:49','2','0.0267332','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('112','21','0','2017-08-22 22:45:26','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('113','21','112','2017-08-22 22:45:26','2','0.018724','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('114','9','0','2017-08-22 22:45:27','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('115','9','114','2017-08-22 22:45:27','2','0.024842','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('116','13','0','2017-08-22 22:45:36','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('117','13','116','2017-08-22 22:45:36','2','0.0214','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('118','14','0','2017-08-22 22:51:39','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('119','14','118','2017-08-22 22:51:39','2','0.0206981','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('120','20','0','2017-08-22 22:56:43','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('121','20','120','2017-08-22 22:56:43','2','0.0217991','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('122','22','0','2017-08-22 22:57:37','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('123','22','122','2017-08-22 22:57:37','2','0.0168791','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('124','24','0','2017-08-22 22:57:49','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('125','24','124','2017-08-22 22:57:49','2','0.017307','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('126','17','0','2017-08-22 23:21:46','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('127','17','126','2017-08-22 23:21:46','2','0.0299082','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('128','21','0','2017-08-22 23:43:31','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('129','21','128','2017-08-22 23:43:31','2','0.0177529','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('130','9','0','2017-08-22 23:48:50','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('131','9','130','2017-08-22 23:48:50','2','0.057416','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('132','22','0','2017-08-23 00:04:31','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('133','22','132','2017-08-23 00:04:31','2','0.0186419','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('134','17','0','2017-08-23 00:08:56','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('135','17','134','2017-08-23 00:08:56','2','0.015846','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('136','13','0','2017-08-23 00:08:57','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('137','13','136','2017-08-23 00:08:57','2','0.0160761','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('138','21','0','2017-08-23 00:08:58','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('139','21','138','2017-08-23 00:08:58','2','0.0130589','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('140','14','0','2017-08-23 00:08:58','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('141','14','140','2017-08-23 00:08:58','2','0.0116901','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('142','20','0','2017-08-23 00:08:59','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('143','20','142','2017-08-23 00:08:59','2','0.0150199','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('144','24','0','2017-08-23 00:08:59','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('145','24','144','2017-08-23 00:08:59','2','0.010879','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('146','9','0','2017-08-23 00:09:02','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('147','9','146','2017-08-23 00:09:02','2','0.020334','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('148','22','0','2017-08-23 00:09:04','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('149','22','148','2017-08-23 00:09:04','2','0.0163641','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('150','22','0','2017-08-23 00:12:10','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('151','22','150','2017-08-23 00:12:10','2','0.0169091','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('152','17','0','2017-08-23 00:15:20','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('153','17','152','2017-08-23 00:15:20','2','0.019079','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('154','21','0','2017-08-23 00:20:05','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('155','21','154','2017-08-23 00:20:05','2','0.0218751','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('156','22','0','2017-08-23 00:20:07','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('157','22','156','2017-08-23 00:20:07','2','0.0177372','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('158','9','0','2017-08-23 00:20:26','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('159','9','158','2017-08-23 00:20:26','2','0.022409','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('160','17','0','2017-08-23 00:20:37','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('161','17','160','2017-08-23 00:20:37','2','0.01688','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('162','22','0','2017-08-23 00:29:28','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('163','22','162','2017-08-23 00:29:28','2','0.0220852','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('164','17','0','2017-08-23 00:34:59','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('165','17','164','2017-08-23 00:34:59','2','0.0204911','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('166','21','0','2017-08-23 00:37:05','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('167','21','166','2017-08-23 00:37:05','2','0.013355','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('168','9','0','2017-08-23 00:37:06','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('169','9','168','2017-08-23 00:37:06','2','0.0470159','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('170','22','0','2017-08-23 00:37:07','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('171','22','170','2017-08-23 00:37:07','2','0.019207','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('172','22','0','2017-08-23 00:40:55','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('173','22','172','2017-08-23 00:40:55','2','0.0159562','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('174','17','0','2017-08-23 00:44:38','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('175','17','174','2017-08-23 00:44:38','2','0.0170949','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('176','22','0','2017-08-23 00:49:07','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('177','22','176','2017-08-23 00:49:07','2','0.0167909','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('178','21','0','2017-08-23 00:49:27','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('179','21','178','2017-08-23 00:49:27','2','0.0180039','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('180','9','0','2017-08-23 00:50:33','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('181','9','180','2017-08-23 00:50:33','2','0.0271711','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('182','17','0','2017-08-23 00:52:43','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('183','17','182','2017-08-23 00:52:43','2','0.0187502','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('184','22','0','2017-08-23 15:34:18','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('185','22','184','2017-08-23 15:34:18','2','0.229654','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('186','21','0','2017-08-23 15:42:29','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('187','21','186','2017-08-23 15:42:29','2','0.042084','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('188','17','0','2017-08-23 15:46:17','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('189','17','188','2017-08-23 15:46:17','2','0.0825732','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('190','9','0','2017-08-23 15:46:43','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('191','9','190','2017-08-23 15:46:43','2','0.050674','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('192','13','0','2017-08-23 15:50:46','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('193','13','192','2017-08-23 15:50:46','2','0.017895','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('194','14','0','2017-08-23 15:50:54','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('195','14','194','2017-08-23 15:50:54','2','0.013037','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('196','20','0','2017-08-23 16:01:13','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('197','20','196','2017-08-23 16:01:13','2','0.0167141','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('198','24','0','2017-08-23 16:14:11','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('199','24','198','2017-08-23 16:14:11','2','0.154052','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('200','15','0','2017-08-23 16:14:22','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('201','15','200','2017-08-23 16:14:22','2','0.119916','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('202','16','0','2017-08-23 16:14:25','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('203','16','202','2017-08-23 16:14:25','2','0.015841','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('204','22','0','2017-08-23 16:22:29','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('205','22','204','2017-08-23 16:22:29','2','0.018492','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('206','21','0','2017-08-23 16:27:14','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('207','21','206','2017-08-23 16:27:14','2','0.0135782','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('208','17','0','2017-08-23 16:27:43','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('209','17','208','2017-08-23 16:27:43','2','0.0180709','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('210','9','0','2017-08-23 16:27:47','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('211','9','210','2017-08-23 16:27:47','2','0.158427','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('212','22','0','2017-08-23 16:38:48','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('213','22','212','2017-08-23 16:38:48','2','0.0217102','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('214','17','0','2017-08-23 16:47:24','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('215','17','214','2017-08-23 16:47:24','2','0.310444','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('216','21','0','2017-08-23 17:00:57','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('217','21','216','2017-08-23 17:00:57','2','0.13637','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('218','9','0','2017-08-23 17:23:56','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('219','9','218','2017-08-23 17:23:56','2','0.054997','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('220','22','0','2017-08-23 17:29:17','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('221','22','220','2017-08-23 17:29:17','2','0.0188251','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('222','13','0','2017-08-23 17:32:06','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('223','13','222','2017-08-23 17:32:06','2','0.0179501','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('224','14','0','2017-08-23 17:32:21','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('225','14','224','2017-08-23 17:32:21','2','0.0238538','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('226','17','0','2017-08-23 17:38:18','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('227','17','226','2017-08-23 17:38:18','2','0.0190229','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('228','20','0','2017-08-23 17:51:31','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('229','20','228','2017-08-23 17:51:31','2','0.0188019','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('230','21','0','2017-08-23 17:51:46','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('231','21','230','2017-08-23 17:51:46','2','0.0281849','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('232','24','0','2017-08-23 17:53:17','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('233','24','232','2017-08-23 17:53:17','2','0.016799','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('234','22','0','2017-08-23 17:53:28','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('235','22','234','2017-08-23 17:53:28','2','0.034318','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('236','9','0','2017-08-23 17:53:36','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('237','9','236','2017-08-23 17:53:36','2','0.0190642','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('238','18','0','2017-08-23 17:53:37','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('239','18','238','2017-08-23 17:53:37','2','0.0212479','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('240','19','0','2017-08-23 17:53:38','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('241','19','240','2017-08-23 17:53:38','2','0.0158329','0','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('242','17','0','2017-08-23 17:53:45','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('243','17','242','2017-08-23 17:53:45','2','0.0164011','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('244','22','0','2017-08-23 17:54:03','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('245','22','244','2017-08-23 17:54:03','2','0.0359149','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('246','22','0','2017-08-23 17:58:10','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('247','22','246','2017-08-23 17:58:10','2','0.0403171','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('248','21','0','2017-08-23 17:58:23','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('249','21','248','2017-08-23 17:58:23','2','0.018898','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('250','17','0','2017-08-23 17:59:13','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('251','17','250','2017-08-23 17:59:13','2','0.056236','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('252','22','0','2017-08-23 18:27:57','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('253','22','252','2017-08-23 18:27:57','2','0.104954','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('254','9','0','2017-08-23 18:29:54','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('255','9','254','2017-08-23 18:29:54','2','0.0195239','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('256','21','0','2017-08-23 18:32:59','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('257','21','256','2017-08-23 18:32:59','2','0.015388','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('258','17','0','2017-08-23 18:38:17','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('259','17','258','2017-08-23 18:38:17','2','0.0175989','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('260','23','0','2017-08-23 18:47:08','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('261','23','260','2017-08-23 18:47:08','2','0.0461679','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('262','22','0','2017-08-23 18:52:26','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('263','22','262','2017-08-23 18:52:26','2','0.016','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('264','13','0','2017-08-23 18:59:08','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('265','13','264','2017-08-23 18:59:08','2','0.0507028','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('266','14','0','2017-08-23 19:04:10','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('267','14','266','2017-08-23 19:04:10','2','0.0763969','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('268','21','0','2017-08-23 19:11:35','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('269','21','268','2017-08-23 19:11:35','2','0.026973','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('270','9','0','2017-08-23 19:22:32','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('271','9','270','2017-08-23 19:22:32','2','0.041981','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('272','17','0','2017-08-23 19:27:33','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('273','17','272','2017-08-23 19:27:33','2','0.018146','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('274','20','0','2017-08-23 19:30:03','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('275','20','274','2017-08-23 19:30:03','2','0.0151069','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('276','22','0','2017-08-23 19:31:07','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('277','22','276','2017-08-23 19:31:07','2','0.0145049','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('278','24','0','2017-08-23 19:32:35','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('279','24','278','2017-08-23 19:32:35','2','0.016005','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('280','25','0','2017-08-23 19:33:10','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('281','25','280','2017-08-23 19:33:10','2','0.014554','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('282','5','0','2017-08-23 19:42:41','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('283','5','282','2017-08-23 19:42:41','2','0.015857','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('284','6','0','2017-08-23 19:45:44','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('285','6','284','2017-08-23 19:45:44','2','0.0109248','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('286','12','0','2017-08-23 19:47:21','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('287','12','286','2017-08-23 19:47:21','1','0.023097','20','Limpiar 20 archivos de sesión creados de mas de 1440 segundos
');
INSERT INTO `glpi_crontasklogs` VALUES ('288','12','286','2017-08-23 19:47:21','2','0.023555','20','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('289','21','0','2017-08-23 19:47:23','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('290','21','289','2017-08-23 19:47:23','2','0.018702','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('291','9','0','2017-08-23 19:48:52','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('292','9','291','2017-08-23 19:48:52','2','0.0670729','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('293','17','0','2017-08-23 19:49:16','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('294','17','293','2017-08-23 19:49:16','2','0.0277178','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('295','22','0','2017-08-23 19:49:20','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('296','22','295','2017-08-23 19:49:20','2','0.0164871','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('297','22','0','2017-08-23 19:50:36','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('298','22','297','2017-08-23 19:50:36','2','0.0197051','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('299','22','0','2017-08-23 19:51:04','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('300','22','299','2017-08-23 19:51:04','2','0.0170748','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('301','21','0','2017-08-23 19:52:12','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('302','21','301','2017-08-23 19:52:12','2','0.0259669','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('303','22','0','2017-08-23 19:54:22','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('304','22','303','2017-08-23 19:54:22','2','0.026572','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('305','17','0','2017-08-23 19:59:24','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('306','17','305','2017-08-23 19:59:24','2','0.0187151','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('307','22','0','2017-08-23 21:28:54','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('308','22','307','2017-08-23 21:28:54','2','0.0192049','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('309','21','0','2017-08-23 21:37:47','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('310','21','309','2017-08-23 21:37:47','2','0.017024','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('311','9','0','2017-08-23 21:40:02','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('312','9','311','2017-08-23 21:40:02','2','0.049016','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('313','13','0','2017-08-23 21:43:14','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('314','13','313','2017-08-23 21:43:14','2','0.0173941','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('315','14','0','2017-08-23 21:47:49','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('316','14','315','2017-08-23 21:47:49','2','0.012754','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('317','17','0','2017-08-23 21:48:17','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('318','17','317','2017-08-23 21:48:17','2','0.0197608','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('319','20','0','2017-08-23 21:50:03','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('320','20','319','2017-08-23 21:50:03','2','0.0155239','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('321','24','0','2017-08-23 21:50:59','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('322','24','321','2017-08-23 21:50:59','2','0.018188','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('323','22','0','2017-08-23 21:51:00','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('324','22','323','2017-08-23 21:51:00','2','0.0169451','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('325','21','0','2017-08-23 21:51:10','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('326','21','325','2017-08-23 21:51:10','2','0.014992','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('327','9','0','2017-08-23 21:51:42','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('328','9','327','2017-08-23 21:51:42','2','0.0176451','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('329','22','0','2017-08-23 21:53:09','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('330','22','329','2017-08-23 21:53:09','2','0.0162499','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('331','17','0','2017-08-23 21:53:57','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('332','17','331','2017-08-23 21:53:57','2','0.0242121','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('333','22','0','2017-08-23 21:54:01','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('334','22','333','2017-08-23 21:54:01','2','0.025352','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('335','22','0','2017-08-23 21:55:09','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('336','22','335','2017-08-23 21:55:09','2','0.014611','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('337','21','0','2017-08-23 21:56:18','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('338','21','337','2017-08-23 21:56:18','2','0.014394','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('339','22','0','2017-08-23 21:56:48','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('340','22','339','2017-08-23 21:56:48','2','0.0155349','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('341','22','0','2017-08-23 21:57:07','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('342','22','341','2017-08-23 21:57:07','2','0.0170431','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('343','17','0','2017-08-23 21:58:13','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('344','17','343','2017-08-23 21:58:13','2','0.0149429','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('345','22','0','2017-08-23 21:59:24','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('346','22','345','2017-08-23 21:59:24','2','0.0209169','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('347','22','0','2017-08-23 22:00:51','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('348','22','347','2017-08-23 22:00:51','2','0.016484','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('349','9','0','2017-08-23 22:01:12','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('350','9','349','2017-08-23 22:01:12','2','0.0244191','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('351','21','0','2017-08-23 22:01:57','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('352','21','351','2017-08-23 22:01:57','2','0.0131321','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('353','22','0','2017-08-23 22:02:26','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('354','22','353','2017-08-23 22:02:26','2','0.0149419','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('355','17','0','2017-08-23 22:07:16','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('356','17','355','2017-08-23 22:07:16','2','0.0204949','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('357','22','0','2017-08-23 22:08:19','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('358','22','357','2017-08-23 22:08:19','2','0.0123961','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('359','21','0','2017-08-23 22:09:49','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('360','21','359','2017-08-23 22:09:49','2','0.0127671','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('361','22','0','2017-08-23 22:10:54','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('362','22','361','2017-08-23 22:10:54','2','0.016113','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('363','9','0','2017-08-23 22:15:41','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('364','9','363','2017-08-23 22:15:41','2','0.033129','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('365','22','0','2017-08-23 22:15:46','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('366','22','365','2017-08-23 22:15:46','2','0.0197711','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('367','17','0','2017-08-23 22:18:04','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('368','17','367','2017-08-23 22:18:04','2','0.0164618','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('369','21','0','2017-08-23 22:18:06','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('370','21','369','2017-08-23 22:18:06','2','0.013407','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('371','22','0','2017-08-23 22:21:52','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('372','22','371','2017-08-23 22:21:52','2','0.018059','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('373','22','0','2017-08-23 22:23:15','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('374','22','373','2017-08-23 22:23:15','2','0.0198438','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('375','17','0','2017-08-23 22:51:39','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('376','17','375','2017-08-23 22:51:39','2','0.0445461','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('377','21','0','2017-08-23 22:51:54','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('378','21','377','2017-08-23 22:51:54','2','0.0133488','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('379','22','0','2017-08-23 22:56:11','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('380','22','379','2017-08-23 22:56:11','2','0.01753','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('381','9','0','2017-08-23 22:59:10','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('382','9','381','2017-08-23 22:59:10','2','0.0546391','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('383','13','0','2017-08-23 22:59:25','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('384','13','383','2017-08-23 22:59:25','2','0.0173581','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('385','14','0','2017-08-23 22:59:51','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('386','14','385','2017-08-23 22:59:51','2','0.015506','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('387','20','0','2017-08-23 22:59:57','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('388','20','387','2017-08-23 22:59:57','2','0.0403361','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('389','24','0','2017-08-23 23:00:23','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('390','24','389','2017-08-23 23:00:23','2','0.0158658','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('391','17','0','2017-08-23 23:00:46','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('392','17','391','2017-08-23 23:00:46','2','0.0151801','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('393','21','0','2017-08-23 23:00:47','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('394','21','393','2017-08-23 23:00:47','2','0.013248','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('395','22','0','2017-08-23 23:01:07','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('396','22','395','2017-08-23 23:01:07','2','0.0163422','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('397','22','0','2017-08-23 23:03:29','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('398','22','397','2017-08-23 23:03:29','2','0.0167279','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('399','22','0','2017-08-23 23:04:22','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('400','22','399','2017-08-23 23:04:22','2','0.0166571','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('401','17','0','2017-08-23 23:05:40','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('402','17','401','2017-08-23 23:05:40','2','0.0181329','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('403','21','0','2017-08-23 23:06:09','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('404','21','403','2017-08-23 23:06:09','2','0.0142119','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('405','22','0','2017-08-23 23:07:04','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('406','22','405','2017-08-23 23:07:04','2','0.015208','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('407','22','0','2017-08-23 23:22:36','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('408','22','407','2017-08-23 23:22:36','2','0.0191851','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('409','9','0','2017-08-23 23:24:56','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('410','9','409','2017-08-23 23:24:56','2','0.042932','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('411','17','0','2017-08-23 23:31:12','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('412','17','411','2017-08-23 23:31:12','2','0.0937109','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('413','21','0','2017-08-23 23:31:14','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('414','21','413','2017-08-23 23:31:14','2','0.0152562','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('415','22','0','2017-08-23 23:31:16','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('416','22','415','2017-08-23 23:31:16','2','0.0163181','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('417','22','0','2017-08-23 23:36:03','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('418','22','417','2017-08-23 23:36:03','2','0.0176778','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('419','9','0','2017-08-23 23:36:28','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('420','9','419','2017-08-23 23:36:28','2','0.0206699','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('421','17','0','2017-08-23 23:36:52','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('422','17','421','2017-08-23 23:36:52','2','0.0168459','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('423','21','0','2017-08-23 23:36:59','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('424','21','423','2017-08-23 23:36:59','2','0.0227311','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('425','22','0','2017-08-23 23:37:09','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('426','22','425','2017-08-23 23:37:09','2','0.017854','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('427','22','0','2017-08-23 23:44:00','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('428','22','427','2017-08-23 23:44:00','2','0.0147498','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('429','17','0','2017-08-23 23:44:01','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('430','17','429','2017-08-23 23:44:01','2','0.0941801','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('431','21','0','2017-08-23 23:44:01','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('432','21','431','2017-08-23 23:44:01','2','0.0126328','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('433','22','0','2017-08-23 23:45:08','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('434','22','433','2017-08-23 23:45:08','2','0.0188549','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('435','9','0','2017-08-23 23:46:07','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('436','9','435','2017-08-23 23:46:07','2','0.0234308','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('437','22','0','2017-08-23 23:46:07','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('438','22','437','2017-08-23 23:46:07','2','0.013021','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('439','22','0','2017-08-23 23:53:54','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('440','22','439','2017-08-23 23:53:54','2','0.0179911','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('441','17','0','2017-08-23 16:57:07','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('442','17','441','2017-08-23 16:57:07','2','0.027915','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('443','21','0','2017-08-23 16:57:08','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('444','21','443','2017-08-23 16:57:08','2','0.0163929','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('445','22','0','2017-08-23 16:57:47','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('446','22','445','2017-08-23 16:57:47','2','0.0198171','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('447','9','0','2017-08-23 17:02:26','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('448','9','447','2017-08-23 17:02:26','2','0.018573','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('449','22','0','2017-08-23 17:13:05','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('450','22','449','2017-08-23 17:13:05','2','0.018234','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('451','13','0','2017-08-23 17:13:30','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('452','13','451','2017-08-23 17:13:30','2','0.0181289','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('453','14','0','2017-08-23 17:16:16','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('454','14','453','2017-08-23 17:16:16','2','0.014086','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('455','20','0','2017-08-23 17:16:45','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('456','20','455','2017-08-23 17:16:45','2','0.014966','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('457','24','0','2017-08-23 17:21:02','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('458','24','457','2017-08-23 17:21:02','2','0.0171041','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('459','17','0','2017-08-23 17:22:09','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('460','17','459','2017-08-23 17:22:09','2','0.0169282','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('461','21','0','2017-08-23 17:23:57','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('462','21','461','2017-08-23 17:23:57','2','0.0139489','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('463','9','0','2017-08-23 17:27:49','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('464','9','463','2017-08-23 17:27:49','2','0.023658','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('465','22','0','2017-08-23 17:31:56','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('466','22','465','2017-08-23 17:31:56','2','0.0148611','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('467','17','0','2017-08-23 17:33:18','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('468','17','467','2017-08-23 17:33:18','2','0.017314','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('469','21','0','2017-08-23 17:34:26','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('470','21','469','2017-08-23 17:34:26','2','0.014678','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('471','22','0','2017-08-23 17:35:33','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('472','22','471','2017-08-23 17:35:33','2','0.018008','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('473','22','0','2017-08-23 17:36:39','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('474','22','473','2017-08-23 17:36:39','2','0.016001','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('475','9','0','2017-08-23 17:44:09','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('476','9','475','2017-08-23 17:44:09','2','0.022311','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('477','22','0','2017-08-23 17:44:15','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('478','22','477','2017-08-23 17:44:15','2','0.014497','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('479','17','0','2017-08-23 17:46:59','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('480','17','479','2017-08-23 17:46:59','2','0.0174639','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('481','21','0','2017-08-23 17:48:02','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('482','21','481','2017-08-23 17:48:02','2','0.0143621','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('483','22','0','2017-08-24 08:48:10','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('484','22','483','2017-08-24 08:48:10','2','0.260752','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('485','17','0','2017-08-24 08:48:35','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('486','17','485','2017-08-24 08:48:35','2','0.045907','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('487','21','0','2017-08-24 08:49:11','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('488','21','487','2017-08-24 08:49:11','2','0.0218909','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('489','9','0','2017-08-24 08:49:18','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('490','9','489','2017-08-24 08:49:18','2','0.08922','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('491','13','0','2017-08-24 10:06:24','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('492','13','491','2017-08-24 10:06:24','2','0.030443','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('493','14','0','2017-08-24 10:09:12','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('494','14','493','2017-08-24 10:09:12','2','0.0161929','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('495','20','0','2017-08-24 10:11:40','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('496','20','495','2017-08-24 10:11:40','2','0.0175869','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('497','24','0','2017-08-24 10:37:36','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('498','24','497','2017-08-24 10:37:36','1','0.0186682','1','Clean 1 temporary file created since more than 3600 seconds
');
INSERT INTO `glpi_crontasklogs` VALUES ('499','24','497','2017-08-24 10:37:36','2','0.019572','1','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('500','15','0','2017-08-24 10:39:37','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('501','15','500','2017-08-24 10:39:37','2','0.032172','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('502','16','0','2017-08-24 10:41:32','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('503','16','502','2017-08-24 10:41:32','2','0.0156491','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('504','22','0','2017-08-24 10:41:46','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('505','22','504','2017-08-24 10:41:46','2','0.0157549','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('506','17','0','2017-08-24 10:42:09','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('507','17','506','2017-08-24 10:42:09','2','0.014756','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('508','21','0','2017-08-24 10:42:26','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('509','21','508','2017-08-24 10:42:26','2','0.012614','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('510','9','0','2017-08-24 10:42:59','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('511','9','510','2017-08-24 10:42:59','2','0.0521791','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('512','22','0','2017-08-24 10:43:00','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('513','22','512','2017-08-24 10:43:00','2','0.011831','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('514','22','0','2017-08-24 10:44:01','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('515','22','514','2017-08-24 10:44:01','2','0.036638','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('516','22','0','2017-08-24 11:01:18','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('517','22','516','2017-08-24 11:01:18','2','0.0149488','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('518','17','0','2017-08-24 11:06:22','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('519','17','518','2017-08-24 11:06:22','2','0.017978','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('520','21','0','2017-08-24 11:11:27','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('521','21','520','2017-08-24 11:11:27','2','0.0161002','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('522','9','0','2017-08-24 11:15:43','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('523','9','522','2017-08-24 11:15:43','2','0.0517068','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('524','18','0','2017-08-24 11:17:19','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('525','18','524','2017-08-24 11:17:19','2','0.0482659','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('526','19','0','2017-08-24 11:22:36','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('527','19','526','2017-08-24 11:22:36','2','0.0203261','0','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('528','22','0','2017-08-24 11:27:41','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('529','22','528','2017-08-24 11:27:41','2','0.0162902','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('530','13','0','2017-08-24 11:33:42','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('531','13','530','2017-08-24 11:33:42','2','0.018374','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('532','14','0','2017-08-24 11:38:50','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('533','14','532','2017-08-24 11:38:50','2','0.01385','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('534','17','0','2017-08-24 11:43:08','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('535','17','534','2017-08-24 11:43:08','2','0.0195692','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('536','20','0','2017-08-24 11:44:25','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('537','20','536','2017-08-24 11:44:25','2','0.015254','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('538','21','0','2017-08-24 11:49:46','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('539','21','538','2017-08-24 11:49:46','2','0.0146081','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('540','9','0','2017-08-24 11:55:30','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('541','9','540','2017-08-24 11:55:30','2','0.080596','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('542','22','0','2017-08-24 11:58:26','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('543','22','542','2017-08-24 11:58:26','2','0.03106','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('544','24','0','2017-08-24 11:59:50','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('545','24','544','2017-08-24 11:59:50','2','0.02196','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('546','23','0','2017-08-24 12:05:14','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('547','23','546','2017-08-24 12:05:14','2','0.0355401','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('548','17','0','2017-08-24 12:10:14','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('549','17','548','2017-08-24 12:10:14','2','0.026021','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('550','21','0','2017-08-24 12:16:02','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('551','21','550','2017-08-24 12:16:02','2','0.014931','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('552','22','0','2017-08-24 12:16:41','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('553','22','552','2017-08-24 12:16:41','2','0.0192769','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('554','9','0','2017-08-24 12:17:51','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('555','9','554','2017-08-24 12:17:51','2','0.0226569','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('556','17','0','2017-08-24 12:18:12','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('557','17','556','2017-08-24 12:18:12','2','0.0177741','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('558','22','0','2017-08-24 12:22:34','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('559','22','558','2017-08-24 12:22:34','2','0.0170982','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('560','21','0','2017-08-24 12:23:01','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('561','21','560','2017-08-24 12:23:01','2','0.019449','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('562','17','0','2017-08-24 12:26:01','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('563','17','562','2017-08-24 12:26:01','2','0.0196879','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('564','22','0','2017-08-24 12:35:52','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('565','22','564','2017-08-24 12:35:52','2','0.0136321','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('566','9','0','2017-08-24 12:36:10','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('567','9','566','2017-08-24 12:36:10','2','0.0377181','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('568','21','0','2017-08-24 12:41:06','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('569','21','568','2017-08-24 12:41:06','2','0.0217881','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('570','17','0','2017-08-24 12:42:58','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('571','17','570','2017-08-24 12:42:58','2','0.0229888','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('572','13','0','2017-08-24 12:45:53','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('573','13','572','2017-08-24 12:45:53','2','0.018873','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('574','25','0','2017-08-24 12:48:12','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('575','25','574','2017-08-24 12:48:12','2','0.018163','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('576','22','0','2017-08-24 12:49:15','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('577','22','576','2017-08-24 12:49:15','2','0.017813','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('578','14','0','2017-08-24 12:53:33','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('579','14','578','2017-08-24 12:53:33','2','0.0148931','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('580','5','0','2017-08-24 12:54:28','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('581','5','580','2017-08-24 12:54:28','2','0.01859','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('582','20','0','2017-08-24 12:54:30','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('583','20','582','2017-08-24 12:54:30','2','0.016953','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('584','6','0','2017-08-24 12:55:37','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('585','6','584','2017-08-24 12:55:37','2','0.015419','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('586','9','0','2017-08-24 12:56:23','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('587','9','586','2017-08-24 12:56:23','2','0.032721','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('588','21','0','2017-08-24 12:57:48','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('589','21','588','2017-08-24 12:57:48','2','0.017292','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('590','12','0','2017-08-24 14:20:34','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('591','12','590','2017-08-24 14:20:34','1','0.063658','65','Limpiar 65 archivos de sesión creados de mas de 1440 segundos
');
INSERT INTO `glpi_crontasklogs` VALUES ('592','12','590','2017-08-24 14:20:34','2','0.0642219','65','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('593','17','0','2017-08-24 14:21:46','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('594','17','593','2017-08-24 14:21:46','2','0.019166','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('595','22','0','2017-08-24 14:25:47','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('596','22','595','2017-08-24 14:25:47','2','0.019491','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('597','24','0','2017-08-24 14:28:04','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('598','24','597','2017-08-24 14:28:04','2','0.043164','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('599','21','0','2017-08-24 14:31:45','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('600','21','599','2017-08-24 14:31:45','2','0.051806','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('601','9','0','2017-08-24 14:40:10','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('602','9','601','2017-08-24 14:40:10','2','0.128513','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('603','13','0','2017-08-24 14:48:21','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('604','13','603','2017-08-24 14:48:21','1','0.0422449','8','Limpiar 8 archivos de gráficos creados de mas de 3600 segundos
');
INSERT INTO `glpi_crontasklogs` VALUES ('605','13','603','2017-08-24 14:48:21','2','0.0428939','8','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('606','14','0','2017-08-24 14:48:51','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('607','14','606','2017-08-24 14:48:51','2','0.043256','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('608','20','0','2017-08-24 14:48:54','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('609','20','608','2017-08-24 14:48:54','2','0.024472','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('610','17','0','2017-08-24 14:55:16','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('611','17','610','2017-08-24 14:55:16','2','0.0224199','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('612','22','0','2017-08-24 14:56:59','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('613','22','612','2017-08-24 14:56:59','2','0.0166001','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('614','21','0','2017-08-24 15:16:18','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('615','21','614','2017-08-24 15:16:18','2','0.015862','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('616','9','0','2017-08-24 15:16:33','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('617','9','616','2017-08-24 15:16:33','2','0.0432441','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('618','22','0','2017-08-24 15:17:42','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('619','22','618','2017-08-24 15:17:42','2','0.0151951','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('620','17','0','2017-08-24 15:17:59','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('621','17','620','2017-08-24 15:17:59','2','0.0160389','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('622','22','0','2017-08-24 15:18:09','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('623','22','622','2017-08-24 15:18:09','2','0.0162039','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('624','22','0','2017-08-24 15:19:18','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('625','22','624','2017-08-24 15:19:18','2','0.019594','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('626','22','0','2017-08-24 15:20:37','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('627','22','626','2017-08-24 15:20:37','2','0.0157509','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('628','21','0','2017-08-24 15:36:56','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('629','21','628','2017-08-24 15:36:56','2','0.0192151','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('630','22','0','2017-08-24 15:43:21','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('631','22','630','2017-08-24 15:43:21','2','0.018714','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('632','17','0','2017-08-24 15:43:51','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('633','17','632','2017-08-24 15:43:51','2','0.017669','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('634','9','0','2017-08-24 15:43:52','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('635','9','634','2017-08-24 15:43:52','2','0.0200281','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('636','24','0','2017-08-24 15:43:53','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('637','24','636','2017-08-24 15:43:53','2','0.0597749','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('638','21','0','2017-08-24 15:43:54','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('639','21','638','2017-08-24 15:43:54','2','0.015732','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('640','22','0','2017-08-24 15:51:53','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('641','22','640','2017-08-24 15:51:53','2','0.0160291','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('642','13','0','2017-08-24 15:57:45','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('643','13','642','2017-08-24 15:57:45','2','0.0165651','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('644','14','0','2017-08-24 16:02:55','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('645','14','644','2017-08-24 16:02:55','2','0.0214112','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('646','17','0','2017-08-24 16:04:12','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('647','17','646','2017-08-24 16:04:12','2','0.019146','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('648','20','0','2017-08-24 16:04:38','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('649','20','648','2017-08-24 16:04:38','2','0.0407782','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('650','21','0','2017-08-24 16:15:33','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('651','21','650','2017-08-24 16:15:33','2','0.019506','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('652','22','0','2017-08-24 16:15:51','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('653','22','652','2017-08-24 16:15:51','2','0.072825','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('654','9','0','2017-08-24 16:17:09','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('655','9','654','2017-08-24 16:17:09','2','0.0231042','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('656','17','0','2017-08-24 16:27:12','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('657','17','656','2017-08-24 16:27:12','2','1.17619','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('658','22','0','2017-08-24 16:28:17','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('659','22','658','2017-08-24 16:28:17','2','0.023566','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('660','21','0','2017-08-24 16:30:21','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('661','21','660','2017-08-24 16:30:21','2','0.0751381','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('662','9','0','2017-08-24 16:31:13','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('663','9','662','2017-08-24 16:31:13','2','0.101915','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('664','22','0','2017-08-24 16:35:59','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('665','22','664','2017-08-24 16:35:59','2','0.0495348','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('666','17','0','2017-08-24 16:36:18','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('667','17','666','2017-08-24 16:36:18','2','0.0163989','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('668','21','0','2017-08-24 16:36:34','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('669','21','668','2017-08-24 16:36:34','2','0.0208981','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('670','22','0','2017-08-24 16:37:51','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('671','22','670','2017-08-24 16:37:51','2','0.0193739','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('672','22','0','2017-08-24 16:38:02','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('673','22','672','2017-08-24 16:38:02','2','0.0520861','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('674','22','0','2017-08-24 16:39:00','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('675','22','674','2017-08-24 16:39:00','2','0.016773','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('676','22','0','2017-08-24 16:41:25','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('677','22','676','2017-08-24 16:41:25','2','0.063642','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('678','9','0','2017-08-24 16:41:43','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('679','9','678','2017-08-24 16:41:43','2','0.0666242','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('680','17','0','2017-08-24 16:42:05','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('681','17','680','2017-08-24 16:42:05','2','0.047852','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('682','21','0','2017-08-24 16:42:06','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('683','21','682','2017-08-24 16:42:06','2','0.022095','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('684','22','0','2017-08-24 16:42:43','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('685','22','684','2017-08-24 16:42:43','2','0.0660851','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('686','22','0','2017-08-24 16:47:10','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('687','22','686','2017-08-24 16:47:10','2','0.0218229','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('688','24','0','2017-08-24 16:54:00','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('689','24','688','2017-08-24 16:54:00','2','0.106669','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('690','17','0','2017-08-24 17:10:04','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('691','17','690','2017-08-24 17:10:04','2','0.022501','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('692','21','0','2017-08-24 17:21:20','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('693','21','692','2017-08-24 17:21:20','2','0.024092','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('694','22','0','2017-08-24 17:22:31','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('695','22','694','2017-08-24 17:22:31','2','0.033006','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('696','9','0','2017-08-24 17:28:01','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('697','9','696','2017-08-24 17:28:01','2','0.0394058','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('698','13','0','2017-08-24 17:32:13','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('699','13','698','2017-08-24 17:32:13','2','0.0382261','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('700','14','0','2017-08-24 17:40:53','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('701','14','700','2017-08-24 17:40:53','2','0.0193839','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('702','20','0','2017-08-24 17:49:59','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('703','20','702','2017-08-24 17:49:59','2','0.101856','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('704','17','0','2017-08-24 17:50:13','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('705','17','704','2017-08-24 17:50:13','2','0.018713','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('706','22','0','2017-08-24 17:59:51','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('707','22','706','2017-08-24 17:59:51','2','0.0186589','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('708','21','0','2017-08-24 18:01:22','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('709','21','708','2017-08-24 18:01:22','2','0.0163331','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('710','9','0','2017-08-24 18:17:01','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('711','9','710','2017-08-24 18:17:01','2','0.0849159','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('712','24','0','2017-08-24 18:17:03','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('713','24','712','2017-08-24 18:17:03','2','0.0208991','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('714','17','0','2017-08-24 18:17:20','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('715','17','714','2017-08-24 18:17:20','2','0.0269918','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('716','22','0','2017-08-24 18:34:26','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('717','22','716','2017-08-24 18:34:26','2','0.246402','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('718','21','0','2017-08-24 18:34:43','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('719','21','718','2017-08-24 18:34:43','2','0.0924132','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('720','17','0','2017-08-24 18:35:04','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('721','17','720','2017-08-24 18:35:04','2','0.0450969','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('722','9','0','2017-08-24 18:37:11','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('723','9','722','2017-08-24 18:37:11','2','0.0472159','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('724','13','0','2017-08-25 09:26:22','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('725','13','724','2017-08-25 09:26:22','2','0.22427','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('726','22','0','2017-08-25 11:10:43','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('727','22','726','2017-08-25 11:10:43','2','0.11034','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('728','21','0','2017-08-25 11:42:01','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('729','21','728','2017-08-25 11:42:01','2','0.112204','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('730','14','0','2017-08-25 11:46:17','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('731','14','730','2017-08-25 11:46:17','2','0.0186839','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('732','17','0','2017-08-25 12:05:24','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('733','17','732','2017-08-25 12:05:24','2','0.211929','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('734','9','0','2017-08-25 12:08:46','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('735','9','734','2017-08-25 12:08:46','2','0.0527461','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('736','20','0','2017-08-25 12:19:24','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('737','20','736','2017-08-25 12:19:24','2','0.109929','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('738','24','0','2017-08-25 12:28:21','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('739','24','738','2017-08-25 12:28:21','2','0.0149','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('740','15','0','2017-08-25 12:37:53','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('741','15','740','2017-08-25 12:37:53','2','0.0265949','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('742','16','0','2017-08-25 12:41:49','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('743','16','742','2017-08-25 12:41:49','2','0.0224741','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('744','13','0','2017-08-25 14:16:13','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('745','13','744','2017-08-25 14:16:13','2','0.026737','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('746','22','0','2017-08-25 14:19:13','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('747','22','746','2017-08-25 14:19:13','2','0.0167439','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('748','18','0','2017-08-25 14:21:16','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('749','18','748','2017-08-25 14:21:16','2','0.025857','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('750','19','0','2017-08-25 14:26:17','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('751','19','750','2017-08-25 14:26:17','2','0.01649','0','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('752','21','0','2017-08-25 14:30:53','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('753','21','752','2017-08-25 14:30:53','2','0.0375509','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('754','23','0','2017-08-25 14:32:55','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('755','23','754','2017-08-25 14:32:55','2','0.041419','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('756','17','0','2017-08-25 14:37:44','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('757','17','756','2017-08-25 14:37:44','2','0.0140209','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('758','9','0','2017-08-25 14:51:05','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('759','9','758','2017-08-25 14:51:05','2','0.029042','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('760','14','0','2017-08-25 15:15:04','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('761','14','760','2017-08-25 15:15:04','2','0.021039','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('762','25','0','2017-08-25 15:21:27','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('763','25','762','2017-08-25 15:21:27','2','0.018842','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('764','5','0','2017-08-25 16:07:50','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('765','5','764','2017-08-25 16:07:50','2','0.0268121','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('766','6','0','2017-08-25 16:12:47','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('767','6','766','2017-08-25 16:12:47','2','0.0154371','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('768','20','0','2017-08-25 16:13:41','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('769','20','768','2017-08-25 16:13:41','2','0.020102','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('770','24','0','2017-08-25 16:15:52','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('771','24','770','2017-08-25 16:15:52','2','0.0491579','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('772','12','0','2017-08-25 16:26:21','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('773','12','772','2017-08-25 16:26:21','1','0.017621','3','Limpiar 3 archivos de sesión creados de mas de 1440 segundos
');
INSERT INTO `glpi_crontasklogs` VALUES ('774','12','772','2017-08-25 16:26:21','2','0.0182371','3','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('775','22','0','2017-08-25 16:33:01','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('776','22','775','2017-08-25 16:33:01','2','0.0186999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('777','21','0','2017-08-25 16:40:06','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('778','21','777','2017-08-25 16:40:06','2','0.020153','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('779','17','0','2017-08-25 17:04:44','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('780','17','779','2017-08-25 17:04:44','2','0.108718','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('781','9','0','2017-08-25 17:04:47','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('782','9','781','2017-08-25 17:04:47','2','0.037416','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('783','13','0','2017-08-25 17:04:50','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('784','13','783','2017-08-25 17:04:50','2','0.0157528','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('785','14','0','2017-08-25 17:06:37','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('786','14','785','2017-08-25 17:06:37','2','0.061759','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('787','22','0','2017-08-25 17:09:27','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('788','22','787','2017-08-25 17:09:27','2','0.0148828','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('789','21','0','2017-08-25 17:10:15','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('790','21','789','2017-08-25 17:10:15','2','0.0298121','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('791','17','0','2017-08-25 17:10:49','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('792','17','791','2017-08-25 17:10:49','2','0.015718','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('793','22','0','2017-08-25 17:10:51','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('794','22','793','2017-08-25 17:10:51','2','0.0242379','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('795','22','0','2017-08-25 17:11:34','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('796','22','795','2017-08-25 17:11:34','2','0.018085','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('797','22','0','2017-08-25 17:12:13','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('798','22','797','2017-08-25 17:12:13','2','0.0167699','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('799','20','0','2017-08-25 17:54:46','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('800','20','799','2017-08-25 17:54:46','2','0.0687199','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('801','22','0','2017-08-25 18:03:05','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('802','22','801','2017-08-25 18:03:05','2','0.019412','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('803','9','0','2017-08-25 18:04:22','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('804','9','803','2017-08-25 18:04:22','2','0.0355909','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('805','17','0','2017-08-25 18:29:00','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('806','17','805','2017-08-25 18:29:00','2','0.0554991','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('807','21','0','2017-08-25 18:39:31','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('808','21','807','2017-08-25 18:39:31','2','0.0614202','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('809','24','0','2017-08-25 18:40:24','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('810','24','809','2017-08-25 18:40:24','2','0.0208008','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('811','13','0','2017-08-25 18:52:02','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('812','13','811','2017-08-25 18:52:02','2','0.0817719','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('813','22','0','2017-08-25 19:03:39','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('814','22','813','2017-08-25 19:03:39','2','0.0238302','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('815','14','0','2017-08-25 19:13:07','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('816','14','815','2017-08-25 19:13:07','2','0.023819','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('817','9','0','2017-08-25 19:18:34','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('818','9','817','2017-08-25 19:18:34','2','0.115507','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('819','17','0','2017-08-25 19:19:28','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('820','17','819','2017-08-25 19:19:28','2','0.0186269','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('821','21','0','2017-08-25 19:19:34','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('822','21','821','2017-08-25 19:19:34','2','0.0225129','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('823','20','0','2017-08-25 19:19:35','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('824','20','823','2017-08-25 19:19:35','2','0.019973','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('825','22','0','2017-08-25 19:19:36','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('826','22','825','2017-08-25 19:19:36','2','0.178683','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('827','22','0','2017-08-25 19:26:47','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('828','22','827','2017-08-25 19:26:47','2','0.0454309','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('829','17','0','2017-08-28 08:34:06','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('830','17','829','2017-08-28 08:34:06','2','0.349788','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('831','21','0','2017-08-28 08:34:17','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('832','21','831','2017-08-28 08:34:17','2','0.115929','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('833','22','0','2017-08-28 08:49:25','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('834','22','833','2017-08-28 08:49:25','2','0.148676','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('835','9','0','2017-08-28 10:57:44','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('836','9','835','2017-08-28 10:57:44','2','0.146114','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('837','24','0','2017-08-28 11:01:08','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('838','24','837','2017-08-28 11:01:08','2','0.0340149','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('839','13','0','2017-08-28 11:17:33','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('840','13','839','2017-08-28 11:17:33','2','0.045018','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('841','14','0','2017-08-29 23:00:27','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('842','14','841','2017-08-29 23:00:27','2','0.153691','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('843','20','0','2017-08-29 23:03:24','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('844','20','843','2017-08-29 23:03:24','2','0.024791','0','Action completed, no processing required');

### Dump table glpi_crontasks

DROP TABLE IF EXISTS `glpi_crontasks`;
CREATE TABLE `glpi_crontasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(150) COLLATE utf8_unicode_ci NOT NULL COMMENT 'task name',
  `frequency` int(11) NOT NULL COMMENT 'second between launch',
  `param` int(11) DEFAULT NULL COMMENT 'task specify parameter',
  `state` int(11) NOT NULL DEFAULT '1' COMMENT '0:disabled, 1:waiting, 2:running',
  `mode` int(11) NOT NULL DEFAULT '1' COMMENT '1:internal, 2:external',
  `allowmode` int(11) NOT NULL DEFAULT '3' COMMENT '1:internal, 2:external, 3:both',
  `hourmin` int(11) NOT NULL DEFAULT '0',
  `hourmax` int(11) NOT NULL DEFAULT '24',
  `logs_lifetime` int(11) NOT NULL DEFAULT '30' COMMENT 'number of days',
  `lastrun` datetime DEFAULT NULL COMMENT 'last run date',
  `lastcode` int(11) DEFAULT NULL COMMENT 'last run return code',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`itemtype`,`name`),
  KEY `mode` (`mode`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Task run by internal / external cron.';

INSERT INTO `glpi_crontasks` VALUES ('2','CartridgeItem','cartridge','86400','10','0','1','3','0','24','30',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('3','ConsumableItem','consumable','86400','10','0','1','3','0','24','30',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('4','SoftwareLicense','software','86400',NULL,'0','1','3','0','24','30',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('5','Contract','contract','86400',NULL,'1','1','3','0','24','30','2017-08-25 16:07:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('6','InfoCom','infocom','86400',NULL,'1','1','3','0','24','30','2017-08-25 16:12:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('7','CronTask','logs','86400','30','0','1','3','0','24','30',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('8','CronTask','optimize','604800',NULL,'1','1','3','0','24','30','2017-08-22 12:00:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('9','MailCollector','mailgate','600','10','1','1','3','0','24','30','2017-08-28 10:57:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('10','DBconnection','checkdbreplicate','300',NULL,'0','1','3','0','24','30',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('11','CronTask','checkupdate','604800',NULL,'0','1','3','0','24','30',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('12','CronTask','session','86400',NULL,'1','1','3','0','24','30','2017-08-25 16:26:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('13','CronTask','graph','3600',NULL,'1','1','3','0','24','30','2017-08-28 11:17:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('14','ReservationItem','reservation','3600',NULL,'1','1','3','0','24','30','2017-08-29 16:00:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('15','Ticket','closeticket','43200',NULL,'1','1','3','0','24','30','2017-08-25 12:37:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('16','Ticket','alertnotclosed','43200',NULL,'1','1','3','0','24','30','2017-08-25 12:41:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('17','SlaLevel_Ticket','slaticket','300',NULL,'1','1','3','0','24','30','2017-08-28 08:34:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('18','Ticket','createinquest','86400',NULL,'1','1','3','0','24','30','2017-08-25 14:21:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('19','Crontask','watcher','86400',NULL,'1','1','3','0','24','30','2017-08-25 14:26:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('20','TicketRecurrent','ticketrecurrent','3600',NULL,'1','1','3','0','24','30','2017-08-29 16:03:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('21','PlanningRecall','planningrecall','300',NULL,'1','1','3','0','24','30','2017-08-28 08:34:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('22','QueuedMail','queuedmail','60','50','1','1','3','0','24','30','2017-08-28 08:49:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('23','QueuedMail','queuedmailclean','86400','30','1','1','3','0','24','30','2017-08-25 14:32:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('24','Crontask','temp','3600',NULL,'1','1','3','0','24','30','2017-08-28 11:01:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('25','MailCollector','mailgateerror','86400',NULL,'1','1','3','0','24','30','2017-08-25 15:21:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('26','Crontask','circularlogs','86400','4','0','1','3','0','24','30',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('27','ObjectLock','unlockobject','86400','4','0','1','3','0','24','30',NULL,NULL,NULL,NULL,NULL);

### Dump table glpi_devicecases

DROP TABLE IF EXISTS `glpi_devicecases`;
CREATE TABLE `glpi_devicecases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicecasetypes_id` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `devicecasetypes_id` (`devicecasetypes_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicecasetypes

DROP TABLE IF EXISTS `glpi_devicecasetypes`;
CREATE TABLE `glpi_devicecasetypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicecontrols

DROP TABLE IF EXISTS `glpi_devicecontrols`;
CREATE TABLE `glpi_devicecontrols` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_raid` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `interfacetypes_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `interfacetypes_id` (`interfacetypes_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicedrives

DROP TABLE IF EXISTS `glpi_devicedrives`;
CREATE TABLE `glpi_devicedrives` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_writer` tinyint(1) NOT NULL DEFAULT '1',
  `speed` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `interfacetypes_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `interfacetypes_id` (`interfacetypes_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicegraphiccards

DROP TABLE IF EXISTS `glpi_devicegraphiccards`;
CREATE TABLE `glpi_devicegraphiccards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `interfacetypes_id` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `memory_default` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `chipset` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `interfacetypes_id` (`interfacetypes_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `chipset` (`chipset`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_deviceharddrives

DROP TABLE IF EXISTS `glpi_deviceharddrives`;
CREATE TABLE `glpi_deviceharddrives` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rpm` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `interfacetypes_id` int(11) NOT NULL DEFAULT '0',
  `cache` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `capacity_default` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `interfacetypes_id` (`interfacetypes_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicememories

DROP TABLE IF EXISTS `glpi_devicememories`;
CREATE TABLE `glpi_devicememories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `frequence` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `size_default` int(11) NOT NULL DEFAULT '0',
  `devicememorytypes_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `devicememorytypes_id` (`devicememorytypes_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicememorytypes

DROP TABLE IF EXISTS `glpi_devicememorytypes`;
CREATE TABLE `glpi_devicememorytypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_devicememorytypes` VALUES ('1','EDO',NULL,NULL,NULL);
INSERT INTO `glpi_devicememorytypes` VALUES ('2','DDR',NULL,NULL,NULL);
INSERT INTO `glpi_devicememorytypes` VALUES ('3','SDRAM',NULL,NULL,NULL);
INSERT INTO `glpi_devicememorytypes` VALUES ('4','SDRAM-2',NULL,NULL,NULL);

### Dump table glpi_devicemotherboards

DROP TABLE IF EXISTS `glpi_devicemotherboards`;
CREATE TABLE `glpi_devicemotherboards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `chipset` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicenetworkcards

DROP TABLE IF EXISTS `glpi_devicenetworkcards`;
CREATE TABLE `glpi_devicenetworkcards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bandwidth` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `mac_default` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicepcis

DROP TABLE IF EXISTS `glpi_devicepcis`;
CREATE TABLE `glpi_devicepcis` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicepowersupplies

DROP TABLE IF EXISTS `glpi_devicepowersupplies`;
CREATE TABLE `glpi_devicepowersupplies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `power` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_atx` tinyint(1) NOT NULL DEFAULT '1',
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_deviceprocessors

DROP TABLE IF EXISTS `glpi_deviceprocessors`;
CREATE TABLE `glpi_deviceprocessors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `frequence` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `frequency_default` int(11) NOT NULL DEFAULT '0',
  `nbcores_default` int(11) DEFAULT NULL,
  `nbthreads_default` int(11) DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicesoundcards

DROP TABLE IF EXISTS `glpi_devicesoundcards`;
CREATE TABLE `glpi_devicesoundcards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_displaypreferences

DROP TABLE IF EXISTS `glpi_displaypreferences`;
CREATE TABLE `glpi_displaypreferences` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `num` int(11) NOT NULL DEFAULT '0',
  `rank` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`users_id`,`itemtype`,`num`),
  KEY `rank` (`rank`),
  KEY `num` (`num`),
  KEY `itemtype` (`itemtype`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_displaypreferences` VALUES ('32','Computer','4','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('34','Computer','45','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('33','Computer','40','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('31','Computer','5','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('30','Computer','23','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('86','DocumentType','3','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('49','Monitor','31','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('50','Monitor','23','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('51','Monitor','3','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('52','Monitor','4','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('44','Printer','31','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('38','NetworkEquipment','31','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('39','NetworkEquipment','23','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('45','Printer','23','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('46','Printer','3','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('63','Software','4','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('62','Software','5','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('61','Software','23','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('83','CartridgeItem','4','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('82','CartridgeItem','34','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('57','Peripheral','3','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('56','Peripheral','23','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('55','Peripheral','31','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('29','Computer','31','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('35','Computer','3','7','0');
INSERT INTO `glpi_displaypreferences` VALUES ('36','Computer','19','8','0');
INSERT INTO `glpi_displaypreferences` VALUES ('37','Computer','17','9','0');
INSERT INTO `glpi_displaypreferences` VALUES ('40','NetworkEquipment','3','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('41','NetworkEquipment','4','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('42','NetworkEquipment','11','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('43','NetworkEquipment','19','7','0');
INSERT INTO `glpi_displaypreferences` VALUES ('47','Printer','4','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('48','Printer','19','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('53','Monitor','19','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('54','Monitor','7','7','0');
INSERT INTO `glpi_displaypreferences` VALUES ('58','Peripheral','4','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('59','Peripheral','19','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('60','Peripheral','7','7','0');
INSERT INTO `glpi_displaypreferences` VALUES ('64','Contact','3','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('65','Contact','4','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('66','Contact','5','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('67','Contact','6','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('68','Contact','9','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('69','Supplier','9','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('70','Supplier','3','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('71','Supplier','4','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('72','Supplier','5','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('73','Supplier','10','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('74','Supplier','6','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('75','Contract','4','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('76','Contract','3','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('77','Contract','5','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('78','Contract','6','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('79','Contract','7','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('80','Contract','11','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('84','CartridgeItem','23','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('85','CartridgeItem','3','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('88','DocumentType','6','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('89','DocumentType','4','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('90','DocumentType','5','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('91','Document','3','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('92','Document','4','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('93','Document','7','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('94','Document','5','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('95','Document','16','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('96','User','34','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('98','User','5','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('99','User','6','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('100','User','3','7','0');
INSERT INTO `glpi_displaypreferences` VALUES ('101','ConsumableItem','34','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('102','ConsumableItem','4','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('103','ConsumableItem','23','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('104','ConsumableItem','3','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('105','NetworkEquipment','40','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('106','Printer','40','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('107','Monitor','40','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('108','Peripheral','40','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('109','User','8','8','0');
INSERT INTO `glpi_displaypreferences` VALUES ('110','Phone','31','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('111','Phone','23','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('112','Phone','3','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('113','Phone','4','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('114','Phone','40','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('115','Phone','19','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('116','Phone','7','7','0');
INSERT INTO `glpi_displaypreferences` VALUES ('117','Group','16','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('118','AllAssets','31','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('119','ReservationItem','4','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('120','ReservationItem','3','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('125','Budget','3','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('122','Software','72','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('123','Software','163','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('124','Budget','5','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('126','Budget','4','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('127','Budget','19','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('128','Crontask','8','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('129','Crontask','3','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('130','Crontask','4','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('131','Crontask','7','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('132','RequestType','14','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('133','RequestType','15','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('134','NotificationTemplate','4','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('135','NotificationTemplate','16','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('136','Notification','5','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('137','Notification','6','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('138','Notification','2','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('139','Notification','4','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('140','Notification','80','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('141','Notification','86','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('142','MailCollector','2','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('143','MailCollector','19','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('144','AuthLDAP','3','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('145','AuthLDAP','19','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('146','AuthMail','3','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('147','AuthMail','19','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('210','IPNetwork','18','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('209','WifiNetwork','10','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('150','Profile','2','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('151','Profile','3','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('152','Profile','19','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('153','Transfer','19','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('154','TicketValidation','3','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('155','TicketValidation','2','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('156','TicketValidation','8','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('157','TicketValidation','4','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('158','TicketValidation','9','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('159','TicketValidation','7','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('160','NotImportedEmail','2','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('161','NotImportedEmail','5','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('162','NotImportedEmail','4','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('163','NotImportedEmail','6','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('164','NotImportedEmail','16','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('165','NotImportedEmail','19','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('166','RuleRightParameter','11','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('167','Ticket','12','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('168','Ticket','19','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('169','Ticket','15','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('170','Ticket','3','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('171','Ticket','4','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('172','Ticket','5','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('173','Ticket','7','7','0');
INSERT INTO `glpi_displaypreferences` VALUES ('174','Calendar','19','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('175','Holiday','11','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('176','Holiday','12','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('177','Holiday','13','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('178','SLA','4','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('179','Ticket','18','8','0');
INSERT INTO `glpi_displaypreferences` VALUES ('180','AuthLdap','30','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('181','AuthMail','6','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('208','FQDN','11','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('183','FieldUnicity','1','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('184','FieldUnicity','80','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('185','FieldUnicity','4','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('186','FieldUnicity','3','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('187','FieldUnicity','86','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('188','FieldUnicity','30','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('189','Problem','21','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('190','Problem','12','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('191','Problem','19','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('192','Problem','15','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('193','Problem','3','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('194','Problem','7','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('195','Problem','18','7','0');
INSERT INTO `glpi_displaypreferences` VALUES ('196','Vlan','11','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('197','TicketRecurrent','11','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('198','TicketRecurrent','12','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('199','TicketRecurrent','13','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('200','TicketRecurrent','15','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('201','TicketRecurrent','14','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('202','Reminder','2','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('203','Reminder','3','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('204','Reminder','4','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('205','Reminder','5','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('206','Reminder','6','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('207','Reminder','7','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('211','IPNetwork','10','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('212','IPNetwork','11','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('213','IPNetwork','12','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('214','IPNetwork','17','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('215','NetworkName','12','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('216','NetworkName','13','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('217','RSSFeed','2','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('218','RSSFeed','4','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('219','RSSFeed','5','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('220','RSSFeed','19','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('221','RSSFeed','6','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('222','RSSFeed','7','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('223','Blacklist','12','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('224','Blacklist','11','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('225','ReservationItem','5','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('226','QueueMail','16','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('227','QueueMail','7','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('228','QueueMail','20','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('229','QueueMail','21','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('230','QueueMail','22','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('231','QueueMail','15','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('232','Change','12','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('233','Change','19','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('234','Change','15','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('235','Change','7','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('236','Change','18','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('237','Project','3','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('238','Project','4','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('239','Project','12','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('240','Project','5','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('241','Project','15','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('242','Project','21','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('243','ProjectState','12','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('244','ProjectState','11','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('245','ProjectTask','2','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('246','ProjectTask','12','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('247','ProjectTask','14','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('248','ProjectTask','5','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('249','ProjectTask','7','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('250','ProjectTask','8','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('251','ProjectTask','13','7','0');
INSERT INTO `glpi_displaypreferences` VALUES ('252','CartridgeItem','9','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('253','ConsumableItem','9','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('254','ReservationItem','9','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('255','SoftwareLicense','1','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('256','SoftwareLicense','3','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('257','SoftwareLicense','10','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('258','SoftwareLicense','162','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('259','SoftwareLicense','5','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('260','User','9','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('261','User','2','9','0');
INSERT INTO `glpi_displaypreferences` VALUES ('262','User','13','4','0');

### Dump table glpi_documentcategories

DROP TABLE IF EXISTS `glpi_documentcategories`;
CREATE TABLE `glpi_documentcategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `documentcategories_id` int(11) NOT NULL DEFAULT '0',
  `completename` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  `ancestors_cache` longtext COLLATE utf8_unicode_ci,
  `sons_cache` longtext COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `unicity` (`documentcategories_id`,`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_documents

DROP TABLE IF EXISTS `glpi_documents`;
CREATE TABLE `glpi_documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `filename` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'for display and transfert',
  `filepath` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'file storage path',
  `documentcategories_id` int(11) NOT NULL DEFAULT '0',
  `mime` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `link` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  `sha1sum` char(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_blacklisted` tinyint(1) NOT NULL DEFAULT '0',
  `tag` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `tickets_id` (`tickets_id`),
  KEY `users_id` (`users_id`),
  KEY `documentcategories_id` (`documentcategories_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `sha1sum` (`sha1sum`),
  KEY `tag` (`tag`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_documents` VALUES ('1','0','0','Incidente del Documento 1','tbl_oficinas.xlsx','XLSX/d1/0fc8947860d15927b064afc261a7712cc2e0e0.XLSX','0','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','2017-08-22 19:53:30',NULL,'0',NULL,'6','1','d10fc8947860d15927b064afc261a7712cc2e0e0','0','bfa3b1af-b9238559-599c6f9370f1c6.63085778','2017-08-22 19:53:30');
INSERT INTO `glpi_documents` VALUES ('2','0','0','Incidente del Documento 2','PANTALLA ERROR.jpg','JPG/b0/e57f4350f11b0a13f4c3dddf9b98dc70dfd2bc.JPG','0','image/jpeg','2017-08-23 22:09:49',NULL,'0',NULL,'177','2','b0e57f4350f11b0a13f4c3dddf9b98dc70dfd2bc','0','bfa3b1af-b9238559-599de104c54611.17739463','2017-08-23 22:09:49');
INSERT INTO `glpi_documents` VALUES ('3','0','0','Incidente del Documento 10','Formatos.xlsx','XLSX/7f/0f310a83093484a749cfe798e78af462051fcb.XLSX','0','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','2017-08-24 18:05:14',NULL,'0',NULL,'184','10','7f0f310a83093484a749cfe798e78af462051fcb','0','bfa3b1af-b9238559-599f5b9ca86dc1.48932912','2017-08-24 18:05:14');

### Dump table glpi_documents_items

DROP TABLE IF EXISTS `glpi_documents_items`;
CREATE TABLE `glpi_documents_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `documents_id` int(11) NOT NULL DEFAULT '0',
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`documents_id`,`itemtype`,`items_id`),
  KEY `item` (`itemtype`,`items_id`,`entities_id`,`is_recursive`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_documents_items` VALUES ('1','1','1','Ticket','0','0','2017-08-22 19:53:30');
INSERT INTO `glpi_documents_items` VALUES ('2','2','2','Ticket','0','0','2017-08-23 22:09:49');
INSERT INTO `glpi_documents_items` VALUES ('3','1','4','Ticket','0','0','2017-08-23 16:59:54');
INSERT INTO `glpi_documents_items` VALUES ('4','3','10','Ticket','0','0','2017-08-24 18:05:14');

### Dump table glpi_documenttypes

DROP TABLE IF EXISTS `glpi_documenttypes`;
CREATE TABLE `glpi_documenttypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ext` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `icon` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mime` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_uploadable` tinyint(1) NOT NULL DEFAULT '1',
  `date_mod` datetime DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`ext`),
  KEY `name` (`name`),
  KEY `is_uploadable` (`is_uploadable`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_documenttypes` VALUES ('1','JPEG','jpg','jpg-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('2','PNG','png','png-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('3','GIF','gif','gif-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('4','BMP','bmp','bmp-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('5','Photoshop','psd','psd-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('6','TIFF','tif','tif-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('7','AIFF','aiff','aiff-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('8','Windows Media','asf','asf-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('9','Windows Media','avi','avi-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('44','C source','c','c-dist.png','','1','2011-12-06 09:48:34',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('27','RealAudio','rm','rm-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('16','Midi','mid','mid-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('17','QuickTime','mov','mov-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('18','MP3','mp3','mp3-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('19','MPEG','mpg','mpg-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('20','Ogg Vorbis','ogg','ogg-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('24','QuickTime','qt','qt-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('10','BZip','bz2','bz2-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('25','RealAudio','ra','ra-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('26','RealAudio','ram','ram-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('11','Word','doc','doc-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('12','DjVu','djvu','','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('42','MNG','mng','','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('13','PostScript','eps','ps-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('14','GZ','gz','gz-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('37','WAV','wav','wav-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('15','HTML','html','html-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('34','Flash','swf','swf-dist.png','','1','2011-12-06 09:48:34',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('21','PDF','pdf','pdf-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('22','PowerPoint','ppt','ppt-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('23','PostScript','ps','ps-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('40','Windows Media','wmv','wmv-dist.png','','1','2011-12-06 09:48:34',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('28','RTF','rtf','rtf-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('29','StarOffice','sdd','sdd-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('30','StarOffice','sdw','sdw-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('31','Stuffit','sit','sit-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('43','Adobe Illustrator','ai','ai-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('32','OpenOffice Impress','sxi','sxi-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('33','OpenOffice','sxw','sxw-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('46','DVI','dvi','dvi-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('35','TGZ','tgz','tgz-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('36','texte','txt','txt-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('49','RedHat/Mandrake/SuSE','rpm','rpm-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('38','Excel','xls','xls-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('39','XML','xml','xml-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('41','Zip','zip','zip-dist.png','','1','2011-12-06 09:48:34',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('45','Debian','deb','deb-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('47','C header','h','h-dist.png','','1','2011-12-06 09:48:34',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('48','Pascal','pas','pas-dist.png','','1','2011-12-06 09:48:34',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('50','OpenOffice Calc','sxc','sxc-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('51','LaTeX','tex','tex-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('52','GIMP multi-layer','xcf','xcf-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('53','JPEG','jpeg','jpg-dist.png','','1','2005-03-07 22:23:17',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('54','Oasis Open Office Writer','odt','odt-dist.png','','1','2006-01-21 17:41:13',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('55','Oasis Open Office Calc','ods','ods-dist.png','','1','2006-01-21 17:41:31',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('56','Oasis Open Office Impress','odp','odp-dist.png','','1','2006-01-21 17:42:54',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('57','Oasis Open Office Impress Template','otp','odp-dist.png','','1','2006-01-21 17:43:58',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('58','Oasis Open Office Writer Template','ott','odt-dist.png','','1','2006-01-21 17:44:41',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('59','Oasis Open Office Calc Template','ots','ods-dist.png','','1','2006-01-21 17:45:30',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('60','Oasis Open Office Math','odf','odf-dist.png','','1','2006-01-21 17:48:05',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('61','Oasis Open Office Draw','odg','odg-dist.png','','1','2006-01-21 17:48:31',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('62','Oasis Open Office Draw Template','otg','odg-dist.png','','1','2006-01-21 17:49:46',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('63','Oasis Open Office Base','odb','odb-dist.png','','1','2006-01-21 18:03:34',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('64','Oasis Open Office HTML','oth','oth-dist.png','','1','2006-01-21 18:05:27',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('65','Oasis Open Office Writer Master','odm','odm-dist.png','','1','2006-01-21 18:06:34',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('66','Oasis Open Office Chart','odc','','','1','2006-01-21 18:07:48',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('67','Oasis Open Office Image','odi','','','1','2006-01-21 18:08:18',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('68','Word XML','docx','doc-dist.png',NULL,'1','2011-01-18 11:40:42',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('69','Excel XML','xlsx','xls-dist.png',NULL,'1','2011-01-18 11:40:42',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('70','PowerPoint XML','pptx','ppt-dist.png',NULL,'1','2011-01-18 11:40:42',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('71','Comma-Separated Values','csv','csv-dist.png',NULL,'1','2011-12-06 09:48:34',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('72','Scalable Vector Graphics','svg','svg-dist.png',NULL,'1','2011-12-06 09:48:34',NULL,NULL);

### Dump table glpi_domains

DROP TABLE IF EXISTS `glpi_domains`;
CREATE TABLE `glpi_domains` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_dropdowntranslations

DROP TABLE IF EXISTS `glpi_dropdowntranslations`;
CREATE TABLE `glpi_dropdowntranslations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `field` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`itemtype`,`items_id`,`language`,`field`),
  KEY `typeid` (`itemtype`,`items_id`),
  KEY `language` (`language`),
  KEY `field` (`field`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_entities

DROP TABLE IF EXISTS `glpi_entities`;
CREATE TABLE `glpi_entities` (
  `id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `completename` text COLLATE utf8_unicode_ci,
  `comment` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  `sons_cache` longtext COLLATE utf8_unicode_ci,
  `ancestors_cache` longtext COLLATE utf8_unicode_ci,
  `address` text COLLATE utf8_unicode_ci,
  `postcode` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `town` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `website` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phonenumber` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fax` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `admin_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `admin_email_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `admin_reply` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `admin_reply_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `notification_subject_tag` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ldap_dn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tag` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `authldaps_id` int(11) NOT NULL DEFAULT '0',
  `mail_domain` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entity_ldapfilter` text COLLATE utf8_unicode_ci,
  `mailing_signature` text COLLATE utf8_unicode_ci,
  `cartridges_alert_repeat` int(11) NOT NULL DEFAULT '-2',
  `consumables_alert_repeat` int(11) NOT NULL DEFAULT '-2',
  `use_licenses_alert` int(11) NOT NULL DEFAULT '-2',
  `send_licenses_alert_before_delay` int(11) NOT NULL DEFAULT '-2',
  `use_contracts_alert` int(11) NOT NULL DEFAULT '-2',
  `send_contracts_alert_before_delay` int(11) NOT NULL DEFAULT '-2',
  `use_infocoms_alert` int(11) NOT NULL DEFAULT '-2',
  `send_infocoms_alert_before_delay` int(11) NOT NULL DEFAULT '-2',
  `use_reservations_alert` int(11) NOT NULL DEFAULT '-2',
  `autoclose_delay` int(11) NOT NULL DEFAULT '-2',
  `notclosed_delay` int(11) NOT NULL DEFAULT '-2',
  `calendars_id` int(11) NOT NULL DEFAULT '-2',
  `auto_assign_mode` int(11) NOT NULL DEFAULT '-2',
  `tickettype` int(11) NOT NULL DEFAULT '-2',
  `max_closedate` datetime DEFAULT NULL,
  `inquest_config` int(11) NOT NULL DEFAULT '-2',
  `inquest_rate` int(11) NOT NULL DEFAULT '0',
  `inquest_delay` int(11) NOT NULL DEFAULT '-10',
  `inquest_URL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `autofill_warranty_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '-2',
  `autofill_use_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '-2',
  `autofill_buy_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '-2',
  `autofill_delivery_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '-2',
  `autofill_order_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '-2',
  `tickettemplates_id` int(11) NOT NULL DEFAULT '-2',
  `entities_id_software` int(11) NOT NULL DEFAULT '-2',
  `default_contract_alert` int(11) NOT NULL DEFAULT '-2',
  `default_infocom_alert` int(11) NOT NULL DEFAULT '-2',
  `default_cartridges_alarm_threshold` int(11) NOT NULL DEFAULT '-2',
  `default_consumables_alarm_threshold` int(11) NOT NULL DEFAULT '-2',
  `delay_send_emails` int(11) NOT NULL DEFAULT '-2',
  `is_notif_enable_default` int(11) NOT NULL DEFAULT '-2',
  `inquest_duration` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  `autofill_decommission_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '-2',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`entities_id`,`name`),
  KEY `entities_id` (`entities_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_entities` VALUES ('0','Saludpol','-1','Saludpol',NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,'0','0','0','0','0','0','0','0','0','0','0','0','-10','1',NULL,'1','0','0',NULL,'0','0','0','0','0','1','-10','0','0','10','10','0','1','0','2017-08-23 16:25:54',NULL,'0');

### Dump table glpi_entities_knowbaseitems

DROP TABLE IF EXISTS `glpi_entities_knowbaseitems`;
CREATE TABLE `glpi_entities_knowbaseitems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `knowbaseitems_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `knowbaseitems_id` (`knowbaseitems_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_entities_reminders

DROP TABLE IF EXISTS `glpi_entities_reminders`;
CREATE TABLE `glpi_entities_reminders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reminders_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `reminders_id` (`reminders_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_entities_rssfeeds

DROP TABLE IF EXISTS `glpi_entities_rssfeeds`;
CREATE TABLE `glpi_entities_rssfeeds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rssfeeds_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `rssfeeds_id` (`rssfeeds_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_events

DROP TABLE IF EXISTS `glpi_events`;
CREATE TABLE `glpi_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `service` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `level` int(11) NOT NULL DEFAULT '0',
  `message` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `date` (`date`),
  KEY `level` (`level`),
  KEY `item` (`type`,`items_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_events` VALUES ('1','-1','system','2017-08-22 17:33:37','login','3','Inicio de sesión fallido para post-only desde la IP ::1');
INSERT INTO `glpi_events` VALUES ('2','-1','system','2017-08-22 17:35:15','login','3','post-only inicia sesión desde la IP ::1');
INSERT INTO `glpi_events` VALUES ('3','-1','system','2017-08-22 17:50:38','login','3','glpi inicia sesión desde la IP ::1');
INSERT INTO `glpi_events` VALUES ('4','-1','system','2017-08-22 18:15:42','login','3','post-only inicia sesión desde la IP 127.0.0.1');
INSERT INTO `glpi_events` VALUES ('5','1','UserCategory','2017-08-22 18:51:26','setup','4','glpi agrega el elemento Soporte');
INSERT INTO `glpi_events` VALUES ('6','6','users','2017-08-22 18:53:51','setup','4','glpi agrega el elemento fmendoza');
INSERT INTO `glpi_events` VALUES ('7','-1','system','2017-08-22 18:55:46','login','3','fmendoza inicia sesión desde la IP 127.0.0.1');
INSERT INTO `glpi_events` VALUES ('8','6','users','2017-08-22 19:40:12','setup','5','glpi actualiza el elemento');
INSERT INTO `glpi_events` VALUES ('9','1','ticket','2017-08-22 19:53:30','tracking','4','fmendoza agrega el elemento 1');
INSERT INTO `glpi_events` VALUES ('10','-1','system','2017-08-22 20:06:33','login','3','fmendoza inicia sesión desde la IP 127.0.0.1');
INSERT INTO `glpi_events` VALUES ('11','-1','system','2017-08-22 21:25:52','login','3','glpi inicia sesión desde la IP ::1');
INSERT INTO `glpi_events` VALUES ('12','-1','system','2017-08-22 22:10:53','login','3','fmendoza inicia sesión desde la IP 127.0.0.1');
INSERT INTO `glpi_events` VALUES ('13','-1','system','2017-08-22 22:12:39','login','3','fmendoza inicia sesión desde la IP 127.0.0.1');
INSERT INTO `glpi_events` VALUES ('14','-1','system','2017-08-22 22:20:19','login','3','fmendoza inicia sesión desde la IP 127.0.0.1');
INSERT INTO `glpi_events` VALUES ('15','-1','system','2017-08-22 22:45:29','login','3','glpi inicia sesión desde la IP ::1');
INSERT INTO `glpi_events` VALUES ('16','-1','system','2017-08-22 22:57:45','login','3','Inicio de sesión fallido para fmendoza desde la IP 127.0.0.1');
INSERT INTO `glpi_events` VALUES ('17','-1','system','2017-08-22 22:57:55','login','3','fmendoza inicia sesión desde la IP 127.0.0.1');
INSERT INTO `glpi_events` VALUES ('18','6','users','2017-08-23 00:08:47','setup','4','glpi elimina el elemento');
INSERT INTO `glpi_events` VALUES ('19','-1','system','2017-08-23 00:09:16','login','3','Inicio de sesión fallido para fmendoza desde la IP 127.0.0.1');
INSERT INTO `glpi_events` VALUES ('20','-1','system','2017-08-23 00:12:07','login','3','Inicio de sesión fallido para fmendoza@saludpol.gob.pe desde la IP 127.0.0.1');
INSERT INTO `glpi_events` VALUES ('21','-1','system','2017-08-23 00:20:24','login','3','Inicio de sesión fallido para fmendoza@saludpol.local desde la IP 127.0.0.1');
INSERT INTO `glpi_events` VALUES ('22','-1','system','2017-08-23 00:44:31','login','3','Inicio de sesión fallido para lescalerar desde la IP 127.0.0.1');
INSERT INTO `glpi_events` VALUES ('23','-1','system','2017-08-23 00:44:55','login','3','lescalerar inicia sesión desde la IP 127.0.0.1');
INSERT INTO `glpi_events` VALUES ('24','-1','system','2017-08-23 00:49:25','login','3','fmendoza inicia sesión desde la IP 127.0.0.1');
INSERT INTO `glpi_events` VALUES ('25','-1','system','2017-08-23 00:50:01','login','3','dalvarezc inicia sesión desde la IP 127.0.0.1');
INSERT INTO `glpi_events` VALUES ('26','-1','system','2017-08-23 15:34:20','login','3','glpi inicia sesión desde la IP ::1');
INSERT INTO `glpi_events` VALUES ('27','5','users','2017-08-23 15:35:26','setup','5','glpi actualiza el elemento');
INSERT INTO `glpi_events` VALUES ('28','3','users','2017-08-23 15:35:50','setup','5','glpi actualiza el elemento');
INSERT INTO `glpi_events` VALUES ('29','2','users','2017-08-23 15:42:41','setup','5','glpi actualiza el elemento');
INSERT INTO `glpi_events` VALUES ('30','4','users','2017-08-23 15:42:59','setup','5','glpi actualiza el elemento');
INSERT INTO `glpi_events` VALUES ('31','-1','system','2017-08-23 15:46:39','login','3','Inicio de sesión fallido para fmendoza desde la IP 127.0.0.1');
INSERT INTO `glpi_events` VALUES ('32','-1','system','2017-08-23 15:50:40','login','3','fmendoza inicia sesión desde la IP 127.0.0.1');
INSERT INTO `glpi_events` VALUES ('33','-1','system','2017-08-23 16:17:38','login','3','post-only inicia sesión desde la IP 127.0.0.1');
INSERT INTO `glpi_events` VALUES ('34','0','Entity','2017-08-23 16:25:54','setup','4','glpi actualiza el elemento');
INSERT INTO `glpi_events` VALUES ('35','-1','system','2017-08-23 17:23:51','login','3','Inicio de sesión fallido para post-only desde la IP 127.0.0.1');
INSERT INTO `glpi_events` VALUES ('36','-1','system','2017-08-23 17:24:03','login','3','post-only inicia sesión desde la IP 127.0.0.1');
INSERT INTO `glpi_events` VALUES ('37','-1','system','2017-08-23 17:32:18','login','3','Inicio de sesión fallido para post-only desde la IP 127.0.0.1');
INSERT INTO `glpi_events` VALUES ('38','-1','system','2017-08-23 17:32:52','login','3','post-only inicia sesión desde la IP 127.0.0.1');
INSERT INTO `glpi_events` VALUES ('39','-1','system','2017-08-23 17:57:55','login','3','post-only inicia sesión desde la IP 127.0.0.1');
INSERT INTO `glpi_events` VALUES ('40','-1','system','2017-08-23 17:59:29','login','3','Post-only inicia sesión desde la IP 192.168.1.253');
INSERT INTO `glpi_events` VALUES ('41','-1','system','2017-08-23 19:15:35','login','3','fmendoza inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('42','-1','system','2017-08-23 19:31:23','login','3','lescalerar inicia sesión desde la IP 192.168.1.85');
INSERT INTO `glpi_events` VALUES ('43','-1','system','2017-08-23 19:45:11','login','3','fmendoza inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('44','-1','system','2017-08-23 19:45:48','login','3','fmendoza inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('45','436','users','2017-08-23 19:46:12','setup','5','fmendoza actualiza el elemento');
INSERT INTO `glpi_events` VALUES ('46','436','users','2017-08-23 19:46:19','setup','5','fmendoza actualiza el elemento');
INSERT INTO `glpi_events` VALUES ('47','-1','system','2017-08-23 19:53:05','login','3','fmendoza inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('48','-1','system','2017-08-23 21:40:12','login','3','fmendoza inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('49','-1','system','2017-08-23 21:50:19','login','3','Inicio de sesión fallido para lescalerar@saludpol.gob.pe desde la IP 192.168.1.85');
INSERT INTO `glpi_events` VALUES ('50','-1','system','2017-08-23 21:51:08','login','3','Inicio de sesión fallido para fmendoza desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('51','-1','system','2017-08-23 21:52:15','login','3','Inicio de sesión fallido para lescalerar@saludpol.gob.pe desde la IP 192.168.1.85');
INSERT INTO `glpi_events` VALUES ('52','-1','system','2017-08-23 21:53:21','login','3','Inicio de sesión fallido para lescalerar@saludpol.gob.pe desde la IP 192.168.1.85');
INSERT INTO `glpi_events` VALUES ('53','-1','system','2017-08-23 21:53:59','login','3','Inicio de sesión fallido para json@json.com desde la IP ::1');
INSERT INTO `glpi_events` VALUES ('54','-1','system','2017-08-23 21:54:04','login','3','Inicio de sesión fallido para json@json.com desde la IP ::1');
INSERT INTO `glpi_events` VALUES ('55','-1','system','2017-08-23 21:54:31','login','3','Inicio de sesión fallido para gwgwgw desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('56','-1','system','2017-08-23 21:55:29','login','3','Inicio de sesión fallido para lescalerar@saludpol.gob.pe desde la IP 192.168.0.242');
INSERT INTO `glpi_events` VALUES ('57','-1','system','2017-08-23 21:56:06','login','3','Inicio de sesión fallido para fjewfjkljfdlk desde la IP 192.168.0.242');
INSERT INTO `glpi_events` VALUES ('58','-1','system','2017-08-23 21:56:38','login','3','Inicio de sesión fallido para lescalerar@saludpol.gob.pe desde la IP 192.168.1.85');
INSERT INTO `glpi_events` VALUES ('59','-1','system','2017-08-23 21:58:09','login','3','Inicio de sesión fallido para rrodriguez desde la IP 192.168.0.242');
INSERT INTO `glpi_events` VALUES ('60','-1','system','2017-08-23 21:59:46','login','3','glpi inicia sesión desde la IP ::1');
INSERT INTO `glpi_events` VALUES ('61','-1','system','2017-08-23 22:00:08','login','3','fmendoza inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('62','-1','system','2017-08-23 22:01:10','login','3','Inicio de sesión fallido para lescalerar@saludpol.gob.pe desde la IP 192.168.1.85');
INSERT INTO `glpi_events` VALUES ('63','-1','system','2017-08-23 22:02:22','login','3','Inicio de sesión fallido para lescalerar desde la IP 192.168.1.85');
INSERT INTO `glpi_events` VALUES ('64','-1','system','2017-08-23 22:02:34','login','3','lescalerar inicia sesión desde la IP 192.168.1.85');
INSERT INTO `glpi_events` VALUES ('65','2','ticket','2017-08-23 22:09:49','tracking','4','lescalerar agrega el elemento 2');
INSERT INTO `glpi_events` VALUES ('66','-1','system','2017-08-23 22:18:27','login','3','fmendoza inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('67','3','ticket','2017-08-23 22:21:36','tracking','4','fmendoza agrega el elemento 3');
INSERT INTO `glpi_events` VALUES ('68','438','users','2017-08-23 22:23:10','setup','4','glpi agrega el elemento Administrador');
INSERT INTO `glpi_events` VALUES ('69','-1','system','2017-08-23 22:23:25','login','3','administrador inicia sesión desde la IP ::1');
INSERT INTO `glpi_events` VALUES ('70','-1','system','2017-08-23 22:51:44','login','3','Inicio de sesión fallido para fsdfsdfsdfsdfs desde la IP 192.168.1.85');
INSERT INTO `glpi_events` VALUES ('71','-1','system','2017-08-23 22:58:31','login','3','Inicio de sesión fallido para  desde la IP 192.168.1.85');
INSERT INTO `glpi_events` VALUES ('72','-1','system','2017-08-23 22:59:16','login','3','Inicio de sesión fallido para werwrwerwer desde la IP 192.168.1.85');
INSERT INTO `glpi_events` VALUES ('73','-1','system','2017-08-23 22:59:36','login','3','Inicio de sesión fallido para  desde la IP 192.168.1.85');
INSERT INTO `glpi_events` VALUES ('74','-1','system','2017-08-23 22:59:57','login','3','Inicio de sesión fallido para yttertewqttwtewrter desde la IP 192.168.1.85');
INSERT INTO `glpi_events` VALUES ('75','-1','system','2017-08-23 23:00:26','login','3','Inicio de sesión fallido para werwrwer desde la IP 192.168.1.85');
INSERT INTO `glpi_events` VALUES ('76','-1','system','2017-08-23 23:00:56','login','3','Inicio de sesión fallido para yjgjhgjh desde la IP 192.168.0.242');
INSERT INTO `glpi_events` VALUES ('77','-1','system','2017-08-23 23:01:13','login','3','Inicio de sesión fallido para flsdñ{flsdñflsdf desde la IP 192.168.1.85');
INSERT INTO `glpi_events` VALUES ('78','-1','system','2017-08-23 23:01:33','login','3','Inicio de sesión fallido para dasd desde la IP 192.168.0.242');
INSERT INTO `glpi_events` VALUES ('79','-1','system','2017-08-23 23:01:40','login','3','Inicio de sesión fallido para sdfsdfsdfsdfsfd desde la IP 192.168.1.85');
INSERT INTO `glpi_events` VALUES ('80','-1','system','2017-08-23 23:03:47','login','3','Inicio de sesión fallido para ffasf desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('81','-1','system','2017-08-23 23:04:28','login','3','Inicio de sesión fallido para ggfgg desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('82','-1','system','2017-08-23 23:06:37','login','3','Inicio de sesión fallido para fmendoza desde la IP 192.168.1.85');
INSERT INTO `glpi_events` VALUES ('83','-1','system','2017-08-23 23:06:56','login','3','Inicio de sesión fallido para fmendoza desde la IP 192.168.1.85');
INSERT INTO `glpi_events` VALUES ('84','-1','system','2017-08-23 23:07:13','login','3','Inicio de sesión fallido para dfwssdfdff desde la IP 192.168.1.85');
INSERT INTO `glpi_events` VALUES ('85','-1','system','2017-08-23 23:07:40','login','3','Inicio de sesión fallido para lescalerar desde la IP 192.168.1.85');
INSERT INTO `glpi_events` VALUES ('86','-1','system','2017-08-23 23:07:52','login','3','lescalerar inicia sesión desde la IP 192.168.1.85');
INSERT INTO `glpi_events` VALUES ('87','-1','system','2017-08-23 23:46:22','login','3','Inicio de sesión fallido para dasdsa desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('88','-1','system','2017-08-23 16:57:12','login','3','fmendoza inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('89','4','ticket','2017-08-23 16:59:54','tracking','4','fmendoza agrega el elemento 4');
INSERT INTO `glpi_events` VALUES ('90','-1','system','2017-08-23 17:02:34','login','3','lescalerar inicia sesión desde la IP 192.168.1.85');
INSERT INTO `glpi_events` VALUES ('91','2','ticket','2017-08-23 17:04:36','tracking','4','lescalerar actualiza el elemento');
INSERT INTO `glpi_events` VALUES ('92','2','ticket','2017-08-23 17:06:08','tracking','4','lescalerar actualiza el elemento');
INSERT INTO `glpi_events` VALUES ('93','-1','system','2017-08-23 17:13:09','login','3','fmendoza inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('94','177','users','2017-08-23 17:13:37','setup','5','Administrador actualiza el elemento');
INSERT INTO `glpi_events` VALUES ('95','-1','system','2017-08-23 17:16:20','login','3','fmendoza inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('96','436','users','2017-08-23 17:16:38','setup','5','Administrador actualiza el elemento');
INSERT INTO `glpi_events` VALUES ('97','-1','system','2017-08-23 17:22:13','login','3','glpi inicia sesión desde la IP ::1');
INSERT INTO `glpi_events` VALUES ('98','436','users','2017-08-23 17:23:09','setup','5','glpi actualiza el elemento');
INSERT INTO `glpi_events` VALUES ('99','-1','system','2017-08-23 17:23:45','login','3','fmendoza inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('100','-1','system','2017-08-23 17:27:10','login','3','fmendoza inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('101','4','users','2017-08-23 17:30:26','setup','5','glpi actualiza el elemento');
INSERT INTO `glpi_events` VALUES ('102','4','users','2017-08-23 17:31:33','setup','5','glpi actualiza el elemento');
INSERT INTO `glpi_events` VALUES ('103','4','users','2017-08-23 17:31:50','setup','5','glpi actualiza el elemento');
INSERT INTO `glpi_events` VALUES ('104','-1','system','2017-08-23 17:32:03','login','3','tech1 inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('105','3','ticket','2017-08-23 17:33:00','tracking','4','tech1 actualiza el elemento');
INSERT INTO `glpi_events` VALUES ('106','-1','system','2017-08-23 17:33:21','login','3','fmendoza inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('107','3','ticket','2017-08-23 17:34:11','tracking','4','fmendoza actualiza el elemento');
INSERT INTO `glpi_events` VALUES ('108','-1','system','2017-08-23 17:34:31','login','3','tech1 inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('109','3','ticket','2017-08-23 17:35:26','tracking','4','tech1 actualiza el elemento');
INSERT INTO `glpi_events` VALUES ('110','-1','system','2017-08-23 17:35:37','login','3','FMENDOZA inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('111','-1','system','2017-08-23 17:44:21','login','3','tech1 inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('112','1','ticket','2017-08-23 17:46:48','tracking','4','tech1 actualiza el elemento');
INSERT INTO `glpi_events` VALUES ('113','-1','system','2017-08-23 17:48:06','login','3','FMENDOZA inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('114','4','ticket','2017-08-23 17:48:44','tracking','4','glpi actualiza el elemento');
INSERT INTO `glpi_events` VALUES ('115','-1','system','2017-08-24 08:49:22','login','3','fmendoza inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('116','-1','system','2017-08-24 08:49:48','login','3','administrador inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('117','40','groups','2017-08-24 10:07:40','setup','4','Administrador agrega el elemento Soporte Técnico');
INSERT INTO `glpi_events` VALUES ('118','1','ITILCategory','2017-08-24 10:08:11','setup','4','Administrador agrega el elemento Hardware');
INSERT INTO `glpi_events` VALUES ('119','2','ITILCategory','2017-08-24 10:08:41','setup','4','Administrador agrega el elemento Software');
INSERT INTO `glpi_events` VALUES ('120','3','ITILCategory','2017-08-24 10:09:02','setup','4','Administrador agrega el elemento Redes / Servicios');
INSERT INTO `glpi_events` VALUES ('121','-1','system','2017-08-24 10:40:32','login','3','Inicio de sesión fallido para dasdsadad desde la IP 192.168.1.85');
INSERT INTO `glpi_events` VALUES ('122','-1','system','2017-08-24 10:40:35','login','3','Inicio de sesión fallido para  desde la IP 192.168.1.85');
INSERT INTO `glpi_events` VALUES ('123','-1','system','2017-08-24 10:40:44','login','3','Inicio de sesión fallido para  desde la IP 192.168.1.85');
INSERT INTO `glpi_events` VALUES ('124','-1','system','2017-08-24 10:40:46','login','3','Inicio de sesión fallido para  desde la IP 192.168.1.85');
INSERT INTO `glpi_events` VALUES ('125','-1','system','2017-08-24 10:40:46','login','3','Inicio de sesión fallido para  desde la IP 192.168.1.85');
INSERT INTO `glpi_events` VALUES ('126','-1','system','2017-08-24 10:40:48','login','3','Inicio de sesión fallido para  desde la IP 192.168.1.85');
INSERT INTO `glpi_events` VALUES ('127','-1','system','2017-08-24 10:40:49','login','3','Inicio de sesión fallido para  desde la IP 192.168.1.85');
INSERT INTO `glpi_events` VALUES ('128','-1','system','2017-08-24 10:40:50','login','3','Inicio de sesión fallido para  desde la IP 192.168.1.85');
INSERT INTO `glpi_events` VALUES ('129','-1','system','2017-08-24 10:40:54','login','3','Inicio de sesión fallido para  desde la IP 192.168.1.85');
INSERT INTO `glpi_events` VALUES ('130','-1','system','2017-08-24 10:41:04','login','3','Inicio de sesión fallido para  desde la IP 192.168.1.85');
INSERT INTO `glpi_events` VALUES ('131','-1','system','2017-08-24 10:41:05','login','3','Inicio de sesión fallido para  desde la IP 192.168.1.85');
INSERT INTO `glpi_events` VALUES ('132','-1','system','2017-08-24 10:41:05','login','3','Inicio de sesión fallido para  desde la IP 192.168.1.85');
INSERT INTO `glpi_events` VALUES ('133','-1','system','2017-08-24 10:41:14','login','3','Inicio de sesión fallido para  desde la IP 192.168.1.85');
INSERT INTO `glpi_events` VALUES ('134','-1','system','2017-08-24 10:41:16','login','3','Inicio de sesión fallido para  desde la IP 192.168.1.85');
INSERT INTO `glpi_events` VALUES ('135','-1','system','2017-08-24 10:41:17','login','3','Inicio de sesión fallido para  desde la IP 192.168.1.85');
INSERT INTO `glpi_events` VALUES ('136','-1','system','2017-08-24 10:41:18','login','3','Inicio de sesión fallido para  desde la IP 192.168.1.85');
INSERT INTO `glpi_events` VALUES ('137','-1','system','2017-08-24 10:41:18','login','3','Inicio de sesión fallido para  desde la IP 192.168.1.85');
INSERT INTO `glpi_events` VALUES ('138','-1','system','2017-08-24 10:41:40','login','3','Inicio de sesión fallido para dfsdfsdfsdf desde la IP 192.168.1.85');
INSERT INTO `glpi_events` VALUES ('139','-1','system','2017-08-24 10:41:42','login','3','Inicio de sesión fallido para  desde la IP 192.168.1.85');
INSERT INTO `glpi_events` VALUES ('140','-1','system','2017-08-24 10:41:51','login','3','Inicio de sesión fallido para  desde la IP 192.168.1.85');
INSERT INTO `glpi_events` VALUES ('141','-1','system','2017-08-24 10:42:18','login','3','Inicio de sesión fallido para drsrser desde la IP 192.168.1.85');
INSERT INTO `glpi_events` VALUES ('142','-1','system','2017-08-24 10:42:23','login','3','Inicio de sesión fallido para  desde la IP 192.168.1.85');
INSERT INTO `glpi_events` VALUES ('143','-1','system','2017-08-24 10:44:08','login','3','Inicio de sesión fallido para dasdas desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('144','-1','system','2017-08-24 10:44:21','login','3','Inicio de sesión fallido para dasda desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('145','4','ITILCategory','2017-08-24 11:03:43','setup','4','Administrador agrega el elemento ');
INSERT INTO `glpi_events` VALUES ('146','5','ITILCategory','2017-08-24 11:04:30','setup','4','Administrador agrega el elemento Aplicativos');
INSERT INTO `glpi_events` VALUES ('147','6','ITILCategory','2017-08-24 11:04:39','setup','4','Administrador agrega el elemento Gestión de datos');
INSERT INTO `glpi_events` VALUES ('148','7','ITILCategory','2017-08-24 11:04:48','setup','4','Administrador agrega el elemento Gestión de usuarios');
INSERT INTO `glpi_events` VALUES ('149','8','ITILCategory','2017-08-24 11:04:55','setup','4','Administrador agrega el elemento Correos');
INSERT INTO `glpi_events` VALUES ('150','9','ITILCategory','2017-08-24 11:05:02','setup','4','Administrador agrega el elemento Equipo de cómputo');
INSERT INTO `glpi_events` VALUES ('151','10','ITILCategory','2017-08-24 11:05:19','setup','4','Administrador agrega el elemento Impresoras');
INSERT INTO `glpi_events` VALUES ('152','11','ITILCategory','2017-08-24 11:05:25','setup','4','Administrador agrega el elemento Internet');
INSERT INTO `glpi_events` VALUES ('153','12','ITILCategory','2017-08-24 11:05:29','setup','4','Administrador agrega el elemento Red local');
INSERT INTO `glpi_events` VALUES ('154','13','ITILCategory','2017-08-24 11:05:33','setup','4','Administrador agrega el elemento Sistema operativo');
INSERT INTO `glpi_events` VALUES ('155','14','ITILCategory','2017-08-24 11:05:38','setup','4','Administrador agrega el elemento Telefonía');
INSERT INTO `glpi_events` VALUES ('156','-1','system','2017-08-24 11:05:44','login','3','fmendoza inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('157','4','ITILCategory','2017-08-24 11:06:21','setup','4','Administrador purga el elemento');
INSERT INTO `glpi_events` VALUES ('158','1','ITILCategory','2017-08-24 11:13:31','setup','4','Administrador actualiza el elemento');
INSERT INTO `glpi_events` VALUES ('159','1','ITILCategory','2017-08-24 11:13:43','setup','4','Administrador actualiza el elemento');
INSERT INTO `glpi_events` VALUES ('160','15','ITILCategory','2017-08-24 11:15:24','setup','4','Administrador agrega el elemento ');
INSERT INTO `glpi_events` VALUES ('161','16','ITILCategory','2017-08-24 11:15:28','setup','4','Administrador agrega el elemento Sistema Operativo Windows');
INSERT INTO `glpi_events` VALUES ('162','17','ITILCategory','2017-08-24 11:17:39','setup','4','Administrador agrega el elemento Microsoft Office');
INSERT INTO `glpi_events` VALUES ('163','18','ITILCategory','2017-08-24 11:17:47','setup','4','Administrador agrega el elemento Antivirus');
INSERT INTO `glpi_events` VALUES ('164','19','ITILCategory','2017-08-24 11:18:17','setup','4','Administrador agrega el elemento PDF');
INSERT INTO `glpi_events` VALUES ('165','20','ITILCategory','2017-08-24 11:18:26','setup','4','Administrador agrega el elemento Otros');
INSERT INTO `glpi_events` VALUES ('166','21','ITILCategory','2017-08-24 11:18:52','setup','4','Administrador agrega el elemento Copias de seguridad Usuario PC');
INSERT INTO `glpi_events` VALUES ('167','22','ITILCategory','2017-08-24 11:18:59','setup','4','Administrador agrega el elemento Creación de carpetas compartidas');
INSERT INTO `glpi_events` VALUES ('168','23','ITILCategory','2017-08-24 11:19:05','setup','4','Administrador agrega el elemento Recuperación de archivos borrados');
INSERT INTO `glpi_events` VALUES ('169','24','ITILCategory','2017-08-24 11:20:16','setup','4','Administrador agrega el elemento Usuario de red y clave');
INSERT INTO `glpi_events` VALUES ('170','25','ITILCategory','2017-08-24 11:20:21','setup','4','Administrador agrega el elemento Usuario bloqueado');
INSERT INTO `glpi_events` VALUES ('171','26','ITILCategory','2017-08-24 11:20:26','setup','4','Administrador agrega el elemento Usuario temporal');
INSERT INTO `glpi_events` VALUES ('172','27','ITILCategory','2017-08-24 11:20:31','setup','4','Administrador agrega el elemento Configurar acceso a las carpetas compartidas');
INSERT INTO `glpi_events` VALUES ('173','28','ITILCategory','2017-08-24 11:20:35','setup','4','Administrador agrega el elemento Configurar acceso a las impresoras');
INSERT INTO `glpi_events` VALUES ('174','29','ITILCategory','2017-08-24 11:20:40','setup','4','Administrador agrega el elemento Configurar acceso a Internet');
INSERT INTO `glpi_events` VALUES ('175','30','ITILCategory','2017-08-24 11:20:47','setup','4','Administrador agrega el elemento Configurar carpeta de escaneos');
INSERT INTO `glpi_events` VALUES ('176','31','ITILCategory','2017-08-24 11:21:20','setup','4','Administrador agrega el elemento Microsoft Outlook');
INSERT INTO `glpi_events` VALUES ('177','32','ITILCategory','2017-08-24 11:21:30','setup','4','Administrador agrega el elemento Zimbra web');
INSERT INTO `glpi_events` VALUES ('178','33','ITILCategory','2017-08-24 11:21:39','setup','4','Administrador agrega el elemento Hotmail, Gmail, Yahoo');
INSERT INTO `glpi_events` VALUES ('179','34','ITILCategory','2017-08-24 11:22:45','setup','4','Administrador agrega el elemento CPU');
INSERT INTO `glpi_events` VALUES ('180','35','ITILCategory','2017-08-24 11:22:51','setup','4','Administrador agrega el elemento Monitor');
INSERT INTO `glpi_events` VALUES ('181','36','ITILCategory','2017-08-24 11:22:56','setup','4','Administrador agrega el elemento Teclado y/o mouse');
INSERT INTO `glpi_events` VALUES ('182','37','ITILCategory','2017-08-24 11:23:00','setup','4','Administrador agrega el elemento Disco duro');
INSERT INTO `glpi_events` VALUES ('183','38','ITILCategory','2017-08-24 11:23:04','setup','4','Administrador agrega el elemento Lectora');
INSERT INTO `glpi_events` VALUES ('184','39','ITILCategory','2017-08-24 11:23:08','setup','4','Administrador agrega el elemento Fuente / estabilizador');
INSERT INTO `glpi_events` VALUES ('185','40','ITILCategory','2017-08-24 11:23:12','setup','4','Administrador agrega el elemento Memoria / placa');
INSERT INTO `glpi_events` VALUES ('186','41','ITILCategory','2017-08-24 11:24:02','setup','4','Administrador agrega el elemento Cambio de tóner, tinta o cinta');
INSERT INTO `glpi_events` VALUES ('187','42','ITILCategory','2017-08-24 11:24:13','setup','4','Administrador agrega el elemento Fusor');
INSERT INTO `glpi_events` VALUES ('188','43','ITILCategory','2017-08-24 11:24:16','setup','4','Administrador agrega el elemento Atasco de papel');
INSERT INTO `glpi_events` VALUES ('189','44','ITILCategory','2017-08-24 11:24:23','setup','4','Administrador agrega el elemento No imprime');
INSERT INTO `glpi_events` VALUES ('190','45','ITILCategory','2017-08-24 11:24:28','setup','4','Administrador agrega el elemento Otros');
INSERT INTO `glpi_events` VALUES ('191','46','ITILCategory','2017-08-24 11:24:50','setup','4','Administrador agrega el elemento Otros');
INSERT INTO `glpi_events` VALUES ('192','47','ITILCategory','2017-08-24 11:25:06','setup','4','Administrador agrega el elemento Otros');
INSERT INTO `glpi_events` VALUES ('193','48','ITILCategory','2017-08-24 11:25:19','setup','4','Administrador agrega el elemento Otros');
INSERT INTO `glpi_events` VALUES ('194','49','ITILCategory','2017-08-24 11:25:41','setup','4','Administrador agrega el elemento Otros');
INSERT INTO `glpi_events` VALUES ('195','50','ITILCategory','2017-08-24 11:26:09','setup','4','Administrador agrega el elemento Acceso a páginas bloqueadas por firewall');
INSERT INTO `glpi_events` VALUES ('196','51','ITILCategory','2017-08-24 11:26:16','setup','4','Administrador agrega el elemento Descargas de aplicativos (Sunat, SPIJ, otros)');
INSERT INTO `glpi_events` VALUES ('197','52','ITILCategory','2017-08-24 11:26:22','setup','4','Administrador agrega el elemento Sin servicio');
INSERT INTO `glpi_events` VALUES ('198','53','ITILCategory','2017-08-24 11:26:29','setup','4','Administrador agrega el elemento Otros');
INSERT INTO `glpi_events` VALUES ('199','54','ITILCategory','2017-08-24 11:26:50','setup','4','Administrador agrega el elemento Cableado y conectividad');
INSERT INTO `glpi_events` VALUES ('200','55','ITILCategory','2017-08-24 11:27:01','setup','4','Administrador agrega el elemento Routers, Switches y Access Point');
INSERT INTO `glpi_events` VALUES ('201','56','ITILCategory','2017-08-24 11:27:07','setup','4','Administrador agrega el elemento Nuevos equipos');
INSERT INTO `glpi_events` VALUES ('202','57','ITILCategory','2017-08-24 11:27:12','setup','4','Administrador agrega el elemento Sin servicio');
INSERT INTO `glpi_events` VALUES ('203','58','ITILCategory','2017-08-24 11:27:19','setup','4','Administrador agrega el elemento Otros');
INSERT INTO `glpi_events` VALUES ('204','59','ITILCategory','2017-08-24 11:27:35','setup','4','Administrador agrega el elemento Licencia de software');
INSERT INTO `glpi_events` VALUES ('205','60','ITILCategory','2017-08-24 11:27:41','setup','4','Administrador agrega el elemento Windows no responde');
INSERT INTO `glpi_events` VALUES ('206','61','ITILCategory','2017-08-24 11:27:46','setup','4','Administrador agrega el elemento Actualizaciones automáticas');
INSERT INTO `glpi_events` VALUES ('207','62','ITILCategory','2017-08-24 11:27:51','setup','4','Administrador agrega el elemento Cambio de sistema operativo');
INSERT INTO `glpi_events` VALUES ('208','63','ITILCategory','2017-08-24 11:27:56','setup','4','Administrador agrega el elemento Otros');
INSERT INTO `glpi_events` VALUES ('209','64','ITILCategory','2017-08-24 11:28:07','setup','4','Administrador agrega el elemento Cableado');
INSERT INTO `glpi_events` VALUES ('210','65','ITILCategory','2017-08-24 11:28:12','setup','4','Administrador agrega el elemento Instalación/cambio de equipos');
INSERT INTO `glpi_events` VALUES ('211','66','ITILCategory','2017-08-24 11:28:16','setup','4','Administrador agrega el elemento Sin servicio');
INSERT INTO `glpi_events` VALUES ('212','67','ITILCategory','2017-08-24 11:28:21','setup','4','Administrador agrega el elemento Otros');
INSERT INTO `glpi_events` VALUES ('213','1','ITILCategory','2017-08-24 11:33:55','setup','4','Administrador actualiza el elemento');
INSERT INTO `glpi_events` VALUES ('214','2','ITILCategory','2017-08-24 11:35:06','setup','4','Administrador actualiza el elemento');
INSERT INTO `glpi_events` VALUES ('215','3','ITILCategory','2017-08-24 11:35:38','setup','4','Administrador actualiza el elemento');
INSERT INTO `glpi_events` VALUES ('216','68','ITILCategory','2017-08-24 11:36:20','setup','4','Administrador agrega el elemento Cambios a sistemas');
INSERT INTO `glpi_events` VALUES ('217','69','ITILCategory','2017-08-24 11:36:39','setup','4','Administrador agrega el elemento Creación de usuarios y perfiles');
INSERT INTO `glpi_events` VALUES ('218','70','ITILCategory','2017-08-24 11:37:02','setup','4','Administrador agrega el elemento Desarrollo de nuevas funcionalidades');
INSERT INTO `glpi_events` VALUES ('219','71','ITILCategory','2017-08-24 11:37:27','setup','4','Administrador agrega el elemento Errores en el sistema (bugs)');
INSERT INTO `glpi_events` VALUES ('220','72','ITILCategory','2017-08-24 11:37:46','setup','4','Administrador agrega el elemento Lentitud y caídas del sistema');
INSERT INTO `glpi_events` VALUES ('221','73','ITILCategory','2017-08-24 11:37:51','setup','4','Administrador agrega el elemento Otros');
INSERT INTO `glpi_events` VALUES ('222','74','ITILCategory','2017-08-24 11:38:30','setup','4','Administrador agrega el elemento Creación / modificación de usuarios de red');
INSERT INTO `glpi_events` VALUES ('223','75','ITILCategory','2017-08-24 11:38:50','setup','4','Administrador agrega el elemento Desbloqueo de usuarios de red');
INSERT INTO `glpi_events` VALUES ('224','-1','system','2017-08-24 11:43:14','login','3','fmendoza inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('225','1','ConsumableItemType','2017-08-24 11:45:22','setup','4','Administrador agrega el elemento 651A');
INSERT INTO `glpi_events` VALUES ('226','1','cartridgeitems','2017-08-24 11:51:10','inventory','4','Administrador agrega el elemento CF281X');
INSERT INTO `glpi_events` VALUES ('227','1','infocom','2017-08-24 11:51:26','financial','4','Administrador agrega el elemento 1');
INSERT INTO `glpi_events` VALUES ('228','1','cartridgeitems','2017-08-24 11:51:51','inventory','4','Administrador agrega cartuchos');
INSERT INTO `glpi_events` VALUES ('229','1','cartridgeitems','2017-08-24 11:52:21','inventory','4','Administrador agrega cartuchos');
INSERT INTO `glpi_events` VALUES ('230','1','cartridgeitems','2017-08-24 11:55:32','inventory','4','Administrador agrega cartuchos');
INSERT INTO `glpi_events` VALUES ('231','1','cartridgeitems','2017-08-24 11:55:45','inventory','4','Administrador agrega cartuchos');
INSERT INTO `glpi_events` VALUES ('232','1','cartridgeitems','2017-08-24 11:55:48','inventory','4','Administrador agrega cartuchos');
INSERT INTO `glpi_events` VALUES ('233','-1','system','2017-08-24 11:58:33','login','3','glpi inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('234','438','users','2017-08-24 11:59:31','setup','5','glpi actualiza el elemento');
INSERT INTO `glpi_events` VALUES ('235','-1','system','2017-08-24 12:00:07','login','3','administrador inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('236','40','groups','2017-08-24 12:01:36','setup','4','Administrador agrega un usuario a un grupo');
INSERT INTO `glpi_events` VALUES ('237','40','groups','2017-08-24 12:01:51','setup','4','Administrador agrega un usuario a un grupo');
INSERT INTO `glpi_events` VALUES ('238','40','groups','2017-08-24 12:04:32','setup','4','Administrador agrega un usuario a un grupo');
INSERT INTO `glpi_events` VALUES ('239','40','groups','2017-08-24 12:04:42','setup','4','Administrador agrega un usuario a un grupo');
INSERT INTO `glpi_events` VALUES ('240','40','groups','2017-08-24 12:05:13','setup','4','Administrador agrega un usuario a un grupo');
INSERT INTO `glpi_events` VALUES ('241','41','groups','2017-08-24 12:10:07','setup','4','Administrador agrega el elemento Desarrollo');
INSERT INTO `glpi_events` VALUES ('242','41','groups','2017-08-24 12:11:06','setup','4','Administrador agrega un usuario a un grupo');
INSERT INTO `glpi_events` VALUES ('243','1','ITILCategory','2017-08-24 12:17:12','setup','4','Administrador actualiza el elemento');
INSERT INTO `glpi_events` VALUES ('244','-1','system','2017-08-24 12:17:55','login','3','fmendoza inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('245','-1','system','2017-08-24 12:21:09','login','3','post-only inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('246','5','ticket','2017-08-24 12:22:25','tracking','4','post-only agrega el elemento 5');
INSERT INTO `glpi_events` VALUES ('247','-1','system','2017-08-24 12:22:41','login','3','fmendoza inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('248','-1','system','2017-08-24 12:23:07','login','3','tech1 inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('249','435','users','2017-08-24 12:41:16','setup','5','tech1 actualiza el elemento');
INSERT INTO `glpi_events` VALUES ('250','-1','system','2017-08-24 12:45:59','login','3','tech1 inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('251','-1','system','2017-08-24 12:48:16','login','3','tech1 inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('252','-1','system','2017-08-24 12:53:40','login','3','post-only inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('253','-1','system','2017-08-24 12:54:39','login','3','post-only inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('254','-1','system','2017-08-24 12:55:44','login','3','post-only inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('255','-1','system','2017-08-24 12:56:29','login','3','post-only inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('256','-1','system','2017-08-24 12:57:55','login','3','post-only inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('257','-1','system','2017-08-24 14:22:11','login','3','administrador inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('258','-1','system','2017-08-24 14:49:04','login','3','post-only inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('259','3','users','2017-08-24 15:00:05','setup','5','Administrador actualiza el elemento');
INSERT INTO `glpi_events` VALUES ('260','-1','system','2017-08-24 15:16:29','login','3','Inicio de sesión fallido para ebricenov desde la IP 192.168.0.162');
INSERT INTO `glpi_events` VALUES ('261','-1','system','2017-08-24 15:18:18','login','3','post-only inicia sesión desde la IP 192.168.0.162');
INSERT INTO `glpi_events` VALUES ('262','-1','system','2017-08-24 15:19:26','login','3','fmendoza inicia sesión desde la IP 192.168.0.162');
INSERT INTO `glpi_events` VALUES ('263','3','users','2017-08-24 15:36:55','setup','5','Administrador actualiza el elemento');
INSERT INTO `glpi_events` VALUES ('264','-1','system','2017-08-24 15:43:59','login','3','fmendoza inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('265','-1','system','2017-08-24 15:51:59','login','3','fmendoza inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('266','436','users','2017-08-24 15:56:24','setup','5','fmendoza actualiza el elemento');
INSERT INTO `glpi_events` VALUES ('267','6','ticket','2017-08-24 15:58:16','tracking','4','fmendoza agrega el elemento 6');
INSERT INTO `glpi_events` VALUES ('268','-1','system','2017-08-24 16:04:35','login','3','Inicio de sesión fallido para administrador desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('269','-1','system','2017-08-24 16:04:49','login','3','Administrador inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('270','438','users','2017-08-24 16:05:29','setup','5','Administrador actualiza el elemento');
INSERT INTO `glpi_events` VALUES ('271','-1','system','2017-08-24 16:17:13','login','3','fmendoza inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('272','-1','system','2017-08-24 16:27:48','login','3','fmendoza inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('273','-1','system','2017-08-24 16:30:28','login','3','prueba inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('274','-1','system','2017-08-24 16:36:32','login','3','Inicio de sesión fallido para prueba desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('275','-1','system','2017-08-24 16:36:38','login','3','prueba inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('276','7','ticket','2017-08-24 16:37:19','tracking','4','prueba agrega el elemento 7');
INSERT INTO `glpi_events` VALUES ('277','-1','system','2017-08-24 16:39:23','login','3','jsantistebanv inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('278','8','ticket','2017-08-24 16:47:35','tracking','4','prueba agrega el elemento 8');
INSERT INTO `glpi_events` VALUES ('279','-1','system','2017-08-24 16:48:18','login','3','administrador inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('280','9','ticket','2017-08-24 17:23:39','tracking','4','prueba agrega el elemento 9');
INSERT INTO `glpi_events` VALUES ('281','-1','system','2017-08-24 17:25:26','login','3','fmendoza inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('282','1','RequestType','2017-08-24 17:28:51','setup','4','Administrador actualiza el elemento');
INSERT INTO `glpi_events` VALUES ('283','6','ticket','2017-08-24 17:31:36','tracking','4','Administrador actualiza el elemento');
INSERT INTO `glpi_events` VALUES ('284','-1','system','2017-08-24 17:41:02','login','3','tech1 inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('285','2','ticket','2017-08-24 17:41:59','tracking','4','tech1 actualiza el elemento');
INSERT INTO `glpi_events` VALUES ('286','9','ticket','2017-08-24 18:00:24','tracking','4','tech1 agrega un actor');
INSERT INTO `glpi_events` VALUES ('287','-1','system','2017-08-24 18:01:44','login','3','jsantistebanv inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('288','10','ticket','2017-08-24 18:05:14','tracking','4','jsantistebanv agrega el elemento 10');
INSERT INTO `glpi_events` VALUES ('289','-1','system','2017-08-24 18:17:15','login','3','Inicio de sesión fallido para fmendoza desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('290','-1','system','2017-08-24 18:17:28','login','3','fmendoza inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('291','-1','system','2017-08-24 18:34:39','login','3','Inicio de sesión fallido para fmendoza desde la IP 192.168.1.93');
INSERT INTO `glpi_events` VALUES ('292','-1','system','2017-08-24 18:34:55','login','3','fmendoza inicia sesión desde la IP 192.168.1.93');
INSERT INTO `glpi_events` VALUES ('293','-1','system','2017-08-25 09:47:20','login','3','administrador inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('294','-1','system','2017-08-25 11:42:10','login','3','Prueba inicia sesión desde la IP 192.168.1.251');
INSERT INTO `glpi_events` VALUES ('295','-1','system','2017-08-25 12:05:34','login','3','prueba inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('296','11','ticket','2017-08-25 12:06:16','tracking','4','prueba agrega el elemento 11');
INSERT INTO `glpi_events` VALUES ('297','-1','system','2017-08-25 12:08:55','login','3','Prueba inicia sesión desde la IP 192.168.1.251');
INSERT INTO `glpi_events` VALUES ('298','1','Location','2017-08-25 14:19:56','setup','4','Administrador agrega el elemento GERENCIA GENERAL');
INSERT INTO `glpi_events` VALUES ('299','2','Location','2017-08-25 14:20:09','setup','4','Administrador agrega el elemento EQUIPO FUNCIONAL DE PLANEAMIENTO, PRESUPUESTO Y MODERNIZACIÓN');
INSERT INTO `glpi_events` VALUES ('300','3','Location','2017-08-25 14:20:15','setup','4','Administrador agrega el elemento EQUIPO FUNCIONAL DE ASESORÍA JURÍDICA');
INSERT INTO `glpi_events` VALUES ('301','4','Location','2017-08-25 14:21:03','setup','4','Administrador agrega el elemento EQUIPO FUNCIONAL DE ADMINISTRACIÓN');
INSERT INTO `glpi_events` VALUES ('302','5','Location','2017-08-25 14:21:10','setup','4','Administrador agrega el elemento EQUIPO FUNCIONAL DE GESTIÓN Y DESARROLLO DE RECURSOS HUMANOS');
INSERT INTO `glpi_events` VALUES ('303','6','Location','2017-08-25 14:21:15','setup','4','Administrador agrega el elemento EQUIPO FUNCIONAL DE ESTADÍSTICA, TECNOLOGÍA DE LA INFORMACIÓN Y COMUNICACIONES');
INSERT INTO `glpi_events` VALUES ('304','7','Location','2017-08-25 14:21:20','setup','4','Administrador agrega el elemento 	EQUIPO FUNCIONAL DE GESTIÓN DEL ASEGURADO');
INSERT INTO `glpi_events` VALUES ('305','8','Location','2017-08-25 14:21:24','setup','4','Administrador agrega el elemento EQUIPO FUNCIONAL DE FINANCIAMIENTO');
INSERT INTO `glpi_events` VALUES ('306','9','Location','2017-08-25 14:21:29','setup','4','Administrador agrega el elemento EQUIPO FUNCIONAL DE PRESTACIONES DE SALUD');
INSERT INTO `glpi_events` VALUES ('307','10','Location','2017-08-25 14:21:34','setup','4','Administrador agrega el elemento OFICINAS DE SEGUROS');
INSERT INTO `glpi_events` VALUES ('308','11','Location','2017-08-25 14:21:41','setup','4','Administrador agrega el elemento UNIDAD SALUDPOL CHIMBOTE');
INSERT INTO `glpi_events` VALUES ('309','12','Location','2017-08-25 14:22:06','setup','4','Administrador agrega el elemento GERENCIA GENERAL');
INSERT INTO `glpi_events` VALUES ('310','13','Location','2017-08-25 14:23:07','setup','4','Administrador agrega el elemento EQUIPO FUNCIONAL DE PLANEAMIENTO, PRESUPUESTO Y MODERNIZACIÓN');
INSERT INTO `glpi_events` VALUES ('311','14','Location','2017-08-25 14:23:12','setup','4','Administrador agrega el elemento OFICINA DE PLANEAMIENTO');
INSERT INTO `glpi_events` VALUES ('312','15','Location','2017-08-25 14:23:18','setup','4','Administrador agrega el elemento OFICINA DE PRESUPUESTO');
INSERT INTO `glpi_events` VALUES ('313','16','Location','2017-08-25 14:23:23','setup','4','Administrador agrega el elemento OFICINA DE MODERNIZACIÓN');
INSERT INTO `glpi_events` VALUES ('314','17','Location','2017-08-25 14:23:52','setup','4','Administrador agrega el elemento 	EQUIPO FUNCIONAL DE ASESORÍA JURÍDICA');
INSERT INTO `glpi_events` VALUES ('315','18','Location','2017-08-25 14:24:39','setup','4','Administrador agrega el elemento EQUIPO FUNCIONAL DE ADMINISTRACIÓN');
INSERT INTO `glpi_events` VALUES ('316','19','Location','2017-08-25 14:24:43','setup','4','Administrador agrega el elemento OFICINA DE ECONOMÍA');
INSERT INTO `glpi_events` VALUES ('317','20','Location','2017-08-25 14:24:48','setup','4','Administrador agrega el elemento OFICINA DE LOGÍSTICA Y PATRIMONIO');
INSERT INTO `glpi_events` VALUES ('318','21','Location','2017-08-25 14:24:53','setup','4','Administrador agrega el elemento GESTIÓN DOCUMENTARIA Y ARCHIVO');
INSERT INTO `glpi_events` VALUES ('319','22','Location','2017-08-25 14:25:20','setup','4','Administrador agrega el elemento GESTIÓN DOCUMENTARIA Y ARCHIVO - HLNS');
INSERT INTO `glpi_events` VALUES ('320','23','Location','2017-08-25 14:25:32','setup','4','Administrador agrega el elemento AREA DE TESORERIA');
INSERT INTO `glpi_events` VALUES ('321','24','Location','2017-08-25 14:25:38','setup','4','Administrador agrega el elemento AREA DE CONTABILIDAD');
INSERT INTO `glpi_events` VALUES ('322','25','Location','2017-08-25 14:25:46','setup','4','Administrador agrega el elemento AREA DE CONTROL PREVIO');
INSERT INTO `glpi_events` VALUES ('323','26','Location','2017-08-25 14:25:51','setup','4','Administrador agrega el elemento AREA DE CAJA CHICA');
INSERT INTO `glpi_events` VALUES ('324','27','Location','2017-08-25 14:26:05','setup','4','Administrador agrega el elemento AREA DE CAJA CHICA - HLNS');
INSERT INTO `glpi_events` VALUES ('325','28','Location','2017-08-25 14:26:35','setup','4','Administrador agrega el elemento EQUIPO FUNCIONAL DE GESTIÓN Y DESARROLLO DE RECURSOS HUMANOS');
INSERT INTO `glpi_events` VALUES ('326','29','Location','2017-08-25 14:27:10','setup','4','Administrador agrega el elemento EQUIPO FUNCIONAL DE GESTIÓN DEL ASEGURADO');
INSERT INTO `glpi_events` VALUES ('327','30','Location','2017-08-25 14:27:14','setup','4','Administrador agrega el elemento 	OFICINA DE PROMOCION Y VIGILANCIA DE LOS DERECHOS DEL ASEGURADO');
INSERT INTO `glpi_events` VALUES ('328','31','Location','2017-08-25 14:27:19','setup','4','Administrador agrega el elemento 	OFICINA DE GESTION DEL ASEGURAMIENTO');
INSERT INTO `glpi_events` VALUES ('329','32','Location','2017-08-25 14:27:23','setup','4','Administrador agrega el elemento OFICINA DE SEGUROS LIMA');
INSERT INTO `glpi_events` VALUES ('330','33','Location','2017-08-25 14:27:41','setup','4','Administrador agrega el elemento 	EQUIPO FUNCIONAL DE FINANCIAMIENTO');
INSERT INTO `glpi_events` VALUES ('331','34','Location','2017-08-25 14:27:49','setup','4','Administrador agrega el elemento 	OFICINA DE CARTAS DE GARANTÍA');
INSERT INTO `glpi_events` VALUES ('332','35','Location','2017-08-25 14:28:26','setup','4','Administrador agrega el elemento EQUIPO FUNCIONAL DE PRESTACIONES DE SALUD');
INSERT INTO `glpi_events` VALUES ('333','36','Location','2017-08-25 14:28:42','setup','4','Administrador agrega el elemento OFICINAS DE SEGUROS');
INSERT INTO `glpi_events` VALUES ('334','37','Location','2017-08-25 14:28:49','setup','4','Administrador agrega el elemento UNIDAD SALUDPOL LIMA');
INSERT INTO `glpi_events` VALUES ('335','38','Location','2017-08-25 14:29:01','setup','4','Administrador agrega el elemento UNIDAD SALUDPOL LAMBAYEQUE');
INSERT INTO `glpi_events` VALUES ('336','39','Location','2017-08-25 14:29:06','setup','4','Administrador agrega el elemento UNIDAD SALUDPOL TUMBES');
INSERT INTO `glpi_events` VALUES ('337','40','Location','2017-08-25 14:29:11','setup','4','Administrador agrega el elemento 	UNIDAD SALUDPOL PIURA');
INSERT INTO `glpi_events` VALUES ('338','41','Location','2017-08-25 14:29:15','setup','4','Administrador agrega el elemento UNIDAD SALUDPOL SAN MARTIN');
INSERT INTO `glpi_events` VALUES ('339','42','Location','2017-08-25 14:29:20','setup','4','Administrador agrega el elemento UNIDAD SALUDPOL HUARAZ');
INSERT INTO `glpi_events` VALUES ('340','43','Location','2017-08-25 14:29:25','setup','4','Administrador agrega el elemento 	UNIDAD SALUDPOL CUSCO');
INSERT INTO `glpi_events` VALUES ('341','44','Location','2017-08-25 14:29:29','setup','4','Administrador agrega el elemento 	UNIDAD SALUDPOL CAJAMARCA');
INSERT INTO `glpi_events` VALUES ('342','45','Location','2017-08-25 14:29:33','setup','4','Administrador agrega el elemento UNIDAD SALUDPOL MADRE DE DIOS');
INSERT INTO `glpi_events` VALUES ('343','46','Location','2017-08-25 14:29:38','setup','4','Administrador agrega el elemento UNIDAD SALUDPOL AMAZONAS');
INSERT INTO `glpi_events` VALUES ('344','47','Location','2017-08-25 14:29:42','setup','4','Administrador agrega el elemento 	UNIDAD SALUDPOL AYACUCHO');
INSERT INTO `glpi_events` VALUES ('345','48','Location','2017-08-25 14:29:46','setup','4','Administrador agrega el elemento UNIDAD SALUDPOL ICA');
INSERT INTO `glpi_events` VALUES ('346','49','Location','2017-08-25 14:29:51','setup','4','Administrador agrega el elemento 	UNIDAD SALUDPOL LORETO');
INSERT INTO `glpi_events` VALUES ('347','50','Location','2017-08-25 14:29:55','setup','4','Administrador agrega el elemento UNIDAD SALUDPOL MOQUEGUA');
INSERT INTO `glpi_events` VALUES ('348','51','Location','2017-08-25 14:30:00','setup','4','Administrador agrega el elemento UNIDAD SALUDPOL TACNA');
INSERT INTO `glpi_events` VALUES ('349','52','Location','2017-08-25 14:30:04','setup','4','Administrador agrega el elemento UNIDAD SALUDPOL PUNO');
INSERT INTO `glpi_events` VALUES ('350','53','Location','2017-08-25 14:30:09','setup','4','Administrador agrega el elemento UNIDAD SALUDPOL AREQUIPA');
INSERT INTO `glpi_events` VALUES ('351','54','Location','2017-08-25 14:30:14','setup','4','Administrador agrega el elemento UNIDAD SALUDPOL LA LIBERTAD');
INSERT INTO `glpi_events` VALUES ('352','55','Location','2017-08-25 14:30:18','setup','4','Administrador agrega el elemento 	UNIDAD SALUDPOL APURIMAC');
INSERT INTO `glpi_events` VALUES ('353','56','Location','2017-08-25 14:30:23','setup','4','Administrador agrega el elemento UNIDAD SALUDPOL JUNIN');
INSERT INTO `glpi_events` VALUES ('354','57','Location','2017-08-25 14:30:27','setup','4','Administrador agrega el elemento UNIDAD SALUDPOL UCAYALI');
INSERT INTO `glpi_events` VALUES ('355','58','Location','2017-08-25 14:30:33','setup','4','Administrador agrega el elemento UNIDAD SALUDPOL PASCO');
INSERT INTO `glpi_events` VALUES ('356','59','Location','2017-08-25 14:30:37','setup','4','Administrador agrega el elemento 	UNIDAD SALUDPOL HUANUCO');
INSERT INTO `glpi_events` VALUES ('357','60','Location','2017-08-25 14:30:42','setup','4','Administrador agrega el elemento 	UNIDAD SALUDPOL HUANCAVELICA');
INSERT INTO `glpi_events` VALUES ('358','9','ticket','2017-08-25 16:27:05','tracking','4','Administrador actualiza el elemento');
INSERT INTO `glpi_events` VALUES ('359','141','users','2017-08-25 16:40:27','setup','5','Administrador actualiza el elemento');
INSERT INTO `glpi_events` VALUES ('360','351','users','2017-08-25 16:41:20','setup','5','Administrador actualiza el elemento');
INSERT INTO `glpi_events` VALUES ('361','184','users','2017-08-25 16:41:44','setup','5','Administrador actualiza el elemento');
INSERT INTO `glpi_events` VALUES ('362','-1','system','2017-08-25 16:42:16','login','3','jsantistebanv inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('363','2','UserCategory','2017-08-25 16:44:05','setup','4','Administrador agrega el elemento Desarrollo');
INSERT INTO `glpi_events` VALUES ('364','-1','system','2017-08-25 17:05:22','login','3','prueba inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('365','-1','system','2017-08-25 17:06:51','login','3','lescalerar inicia sesión desde la IP 192.168.1.85');
INSERT INTO `glpi_events` VALUES ('366','12','ticket','2017-08-25 17:08:09','tracking','4','lescalerar agrega el elemento 12');
INSERT INTO `glpi_events` VALUES ('367','-1','system','2017-08-25 17:11:44','login','3','Inicio de sesión fallido para administrador desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('368','-1','system','2017-08-25 17:11:58','login','3','administrador inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('369','-1','system','2017-08-25 17:53:51','login','3','fmendoza inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('370','13','ticket','2017-08-25 17:54:32','tracking','4','fmendoza agrega el elemento 13');
INSERT INTO `glpi_events` VALUES ('371','14','ticket','2017-08-25 18:39:44','tracking','4','fmendoza agrega el elemento 14');
INSERT INTO `glpi_events` VALUES ('372','15','ticket','2017-08-25 18:42:04','tracking','4','fmendoza agrega el elemento 15');
INSERT INTO `glpi_events` VALUES ('373','16','ticket','2017-08-25 19:13:33','tracking','4','fmendoza agrega el elemento 16');
INSERT INTO `glpi_events` VALUES ('374','-1','system','2017-08-25 19:19:46','login','3','administrador inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('375','-1','system','2017-08-28 08:34:25','login','3','fmendoza inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('376','-1','system','2017-08-28 10:57:56','login','3','administrador inicia sesión desde la IP 192.168.1.96');
INSERT INTO `glpi_events` VALUES ('377','-1','system','2017-08-29 23:00:35','login','3','prueba inicia sesión desde la IP ::1');
INSERT INTO `glpi_events` VALUES ('378','-1','system','2017-08-29 23:03:34','login','3','Administrador inicia sesión desde la IP ::1');

### Dump table glpi_fieldblacklists

DROP TABLE IF EXISTS `glpi_fieldblacklists`;
CREATE TABLE `glpi_fieldblacklists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `field` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `value` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_fieldunicities

DROP TABLE IF EXISTS `glpi_fieldunicities`;
CREATE TABLE `glpi_fieldunicities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entities_id` int(11) NOT NULL DEFAULT '-1',
  `fields` text COLLATE utf8_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `action_refuse` tinyint(1) NOT NULL DEFAULT '0',
  `action_notify` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Stores field unicity criterias';


### Dump table glpi_filesystems

DROP TABLE IF EXISTS `glpi_filesystems`;
CREATE TABLE `glpi_filesystems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_filesystems` VALUES ('1','ext',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('2','ext2',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('3','ext3',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('4','ext4',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('5','FAT',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('6','FAT32',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('7','VFAT',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('8','HFS',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('9','HPFS',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('10','HTFS',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('11','JFS',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('12','JFS2',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('13','NFS',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('14','NTFS',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('15','ReiserFS',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('16','SMBFS',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('17','UDF',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('18','UFS',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('19','XFS',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('20','ZFS',NULL,NULL,NULL);

### Dump table glpi_fqdns

DROP TABLE IF EXISTS `glpi_fqdns`;
CREATE TABLE `glpi_fqdns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fqdn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `name` (`name`),
  KEY `fqdn` (`fqdn`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_groups

DROP TABLE IF EXISTS `glpi_groups`;
CREATE TABLE `glpi_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `ldap_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ldap_value` text COLLATE utf8_unicode_ci,
  `ldap_group_dn` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `completename` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  `ancestors_cache` longtext COLLATE utf8_unicode_ci,
  `sons_cache` longtext COLLATE utf8_unicode_ci,
  `is_requester` tinyint(1) NOT NULL DEFAULT '1',
  `is_assign` tinyint(1) NOT NULL DEFAULT '1',
  `is_notify` tinyint(1) NOT NULL DEFAULT '1',
  `is_itemgroup` tinyint(1) NOT NULL DEFAULT '1',
  `is_usergroup` tinyint(1) NOT NULL DEFAULT '1',
  `is_manager` tinyint(1) NOT NULL DEFAULT '1',
  `date_creation` datetime DEFAULT NULL,
  `is_task` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `ldap_field` (`ldap_field`),
  KEY `entities_id` (`entities_id`),
  KEY `date_mod` (`date_mod`),
  KEY `ldap_value` (`ldap_value`(200)),
  KEY `ldap_group_dn` (`ldap_group_dn`(200)),
  KEY `groups_id` (`groups_id`),
  KEY `is_requester` (`is_requester`),
  KEY `is_assign` (`is_assign`),
  KEY `is_notify` (`is_notify`),
  KEY `is_itemgroup` (`is_itemgroup`),
  KEY `is_usergroup` (`is_usergroup`),
  KEY `is_manager` (`is_manager`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_groups` VALUES ('2','0','0','actos_preparatorios_procedimiento_seleccion_g',NULL,'memberof','CN=actos_preparatorios_procedimiento_seleccion_g,OU=Actos Preparatorios Procedimiento Seleccion,OU=Of. Logistica y Patrimonio,OU=EF Administracion,OU=SaludPol,DC=saludpol,DC=local',NULL,'2017-08-23 00:32:09','0','actos_preparatorios_procedimiento_seleccion_g','1',NULL,NULL,'1','1','1','1','1','1','2017-08-23 00:32:09','1');
INSERT INTO `glpi_groups` VALUES ('3','0','0','almacen_central_g',NULL,'memberof','CN=almacen_central_g,OU=Almacen Central,OU=Of. Logistica y Patrimonio,OU=EF Administracion,OU=SaludPol,DC=saludpol,DC=local',NULL,'2017-08-23 00:32:09','0','almacen_central_g','1',NULL,NULL,'1','1','1','1','1','1','2017-08-23 00:32:09','1');
INSERT INTO `glpi_groups` VALUES ('4','0','0','contabilidad_g',NULL,'memberof','CN=contabilidad_g,OU=Contabilidad,OU=Of. Economia,OU=EF Administracion,OU=SaludPol,DC=saludpol,DC=local',NULL,'2017-08-23 00:32:09','0','contabilidad_g','1',NULL,NULL,'1','1','1','1','1','1','2017-08-23 00:32:09','1');
INSERT INTO `glpi_groups` VALUES ('5','0','0','control_previo_g',NULL,'memberof','CN=control_previo_g,OU=Control Previo,OU=Of. Economia,OU=EF Administracion,OU=SaludPol,DC=saludpol,DC=local',NULL,'2017-08-23 00:32:09','0','control_previo_g','1',NULL,NULL,'1','1','1','1','1','1','2017-08-23 00:32:09','1');
INSERT INTO `glpi_groups` VALUES ('6','0','0','coordinaciones_gg',NULL,'memberof','CN=coordinaciones_gg,OU=Gerencia General,OU=SaludPol,DC=saludpol,DC=local',NULL,'2017-08-23 00:32:09','0','coordinaciones_gg','1',NULL,NULL,'1','1','1','1','1','1','2017-08-23 00:32:09','1');
INSERT INTO `glpi_groups` VALUES ('8','0','0','efaj_g',NULL,'memberof','CN=efaj_g,OU=EF Asesoria Juridica,OU=SaludPol,DC=saludpol,DC=local',NULL,'2017-08-23 00:32:09','0','efaj_g','1',NULL,NULL,'1','1','1','1','1','1','2017-08-23 00:32:09','1');
INSERT INTO `glpi_groups` VALUES ('9','0','0','efcp_g',NULL,'memberof','CN=efcp_g,OU=EF Prestaciones de Salud,OU=SaludPol,DC=saludpol,DC=local',NULL,'2017-08-23 00:32:09','0','efcp_g','1',NULL,NULL,'1','1','1','1','1','1','2017-08-23 00:32:09','1');
INSERT INTO `glpi_groups` VALUES ('10','0','0','efcp_gj_g',NULL,'memberof','CN=efcp_gj_g,OU=EF Prestaciones de Salud,OU=SaludPol,DC=saludpol,DC=local',NULL,'2017-08-23 00:32:09','0','efcp_gj_g','1',NULL,NULL,'1','1','1','1','1','1','2017-08-23 00:32:09','1');
INSERT INTO `glpi_groups` VALUES ('11','0','0','efcp_of_aud_med_g',NULL,'memberof','CN=efcp_of_aud_med_g,OU=Of. Auditoria Medica,OU=EF Prestaciones de Salud,OU=SaludPol,DC=saludpol,DC=local',NULL,'2017-08-23 00:32:09','0','efcp_of_aud_med_g','1',NULL,NULL,'1','1','1','1','1','1','2017-08-23 00:32:09','1');
INSERT INTO `glpi_groups` VALUES ('12','0','0','efcp_of_con_pre_g',NULL,'memberof','CN=efcp_of_con_pre_g,OU=Of. Control Prestacional,OU=EF Prestaciones de Salud,OU=SaludPol,DC=saludpol,DC=local',NULL,'2017-08-23 00:32:09','0','efcp_of_con_pre_g','1',NULL,NULL,'1','1','1','1','1','1','2017-08-23 00:32:09','1');
INSERT INTO `glpi_groups` VALUES ('13','0','0','efcp_of_pre_liq_g',NULL,'memberof','CN=efcp_of_pre_liq_g,OU=Of. Pre-Liquidacion,OU=EF Prestaciones de Salud,OU=SaludPol,DC=saludpol,DC=local',NULL,'2017-08-23 00:32:09','0','efcp_of_pre_liq_g','1',NULL,NULL,'1','1','1','1','1','1','2017-08-23 00:32:09','1');
INSERT INTO `glpi_groups` VALUES ('16','0','0','eff_g',NULL,'memberof','CN=eff_g,OU=EF Financiamiento,OU=SaludPol,DC=saludpol,DC=local',NULL,'2017-08-23 00:32:09','0','eff_g','1',NULL,NULL,'1','1','1','1','1','1','2017-08-23 00:32:09','1');
INSERT INTO `glpi_groups` VALUES ('17','0','0','efga_w',NULL,'memberof','CN=efga_w,OU=EF Gestion del Asegurado,OU=SaludPol,DC=saludpol,DC=local',NULL,'2017-08-23 00:32:09','0','efga_w','1',NULL,NULL,'1','1','1','1','1','1','2017-08-23 00:32:09','1');
INSERT INTO `glpi_groups` VALUES ('20','0','0','efrh_assist_control_g',NULL,'memberof','CN=efrh_assist_control_g,OU=EF Gestion y Desarrollo de Recursos Humanos,OU=SaludPol,DC=saludpol,DC=local',NULL,'2017-08-23 00:32:09','0','efrh_assist_control_g','1',NULL,NULL,'1','1','1','1','1','1','2017-08-23 00:32:09','1');
INSERT INTO `glpi_groups` VALUES ('21','0','0','efrh_g',NULL,'memberof','CN=efrh_g,OU=EF Gestion y Desarrollo de Recursos Humanos,OU=SaludPol,DC=saludpol,DC=local',NULL,'2017-08-23 00:32:09','0','efrh_g','1',NULL,NULL,'1','1','1','1','1','1','2017-08-23 00:32:09','1');
INSERT INTO `glpi_groups` VALUES ('41','0','0','Desarrollo','',NULL,NULL,NULL,'2017-08-24 12:10:07','0','Desarrollo','1',NULL,'{\"41\":\"41\"}','1','1','1','1','1','1','2017-08-24 12:10:07','0');
INSERT INTO `glpi_groups` VALUES ('24','0','0','ejecucion_contractual_g',NULL,'memberof','CN=ejecucion_contractual_g,OU=Ejecucion Contractual,OU=Of. Logistica y Patrimonio,OU=EF Administracion,OU=SaludPol,DC=saludpol,DC=local',NULL,'2017-08-23 00:32:09','0','ejecucion_contractual_g','1',NULL,NULL,'1','1','1','1','1','1','2017-08-23 00:32:09','1');
INSERT INTO `glpi_groups` VALUES ('25','0','0','gg_g',NULL,'memberof','CN=gg_g,OU=Gerencia,OU=Gerencia General,OU=SaludPol,DC=saludpol,DC=local',NULL,'2017-08-23 00:32:09','0','gg_g','1',NULL,NULL,'1','1','1','1','1','1','2017-08-23 00:32:09','1');
INSERT INTO `glpi_groups` VALUES ('26','0','0','gg_of_seguros',NULL,'memberof','CN=gg_of_seguros,OU=Of. Seguros,OU=Gerencia General,OU=SaludPol,DC=saludpol,DC=local',NULL,'2017-08-23 00:32:09','0','gg_of_seguros','1',NULL,NULL,'1','1','1','1','1','1','2017-08-23 00:32:09','1');
INSERT INTO `glpi_groups` VALUES ('27','0','0','Jefatura_g',NULL,'memberof','CN=Jefatura_g,OU=Jefatura,OU=Of. Logistica y Patrimonio,OU=EF Administracion,OU=SaludPol,DC=saludpol,DC=local',NULL,'2017-08-23 00:32:09','0','Jefatura_g','1',NULL,NULL,'1','1','1','1','1','1','2017-08-23 00:32:09','1');
INSERT INTO `glpi_groups` VALUES ('28','0','0','logistic16_p',NULL,'memberof','CN=logistic16_p,OU=Logistic16_RD,OU=SaludPol,DC=saludpol,DC=local',NULL,'2017-08-23 00:32:09','0','logistic16_p','1',NULL,NULL,'1','1','1','1','1','1','2017-08-23 00:32:09','1');
INSERT INTO `glpi_groups` VALUES ('29','0','0','logistica_servicios_generales_g',NULL,'memberof','CN=logistica_servicios_generales_g,OU=Of. Logistica y Patrimonio,OU=EF Administracion,OU=SaludPol,DC=saludpol,DC=local',NULL,'2017-08-23 00:32:09','0','logistica_servicios_generales_g','1',NULL,NULL,'1','1','1','1','1','1','2017-08-23 00:32:09','1');
INSERT INTO `glpi_groups` VALUES ('30','0','0','Operadores de configuración de red',NULL,'memberof','CN=Operadores de configuración de red,CN=Builtin,DC=saludpol,DC=local',NULL,'2017-08-23 00:32:09','0','Operadores de configuración de red','1',NULL,'{\"30\":\"30\"}','1','1','1','1','1','1','2017-08-23 00:32:09','1');
INSERT INTO `glpi_groups` VALUES ('31','0','0','procesos_g',NULL,'memberof','CN=procesos_g,OU=Procesos,OU=Of. Logistica y Patrimonio,OU=EF Administracion,OU=SaludPol,DC=saludpol,DC=local',NULL,'2017-08-23 00:32:09','0','procesos_g','1',NULL,NULL,'1','1','1','1','1','1','2017-08-23 00:32:09','1');
INSERT INTO `glpi_groups` VALUES ('32','0','0','programacion_g',NULL,'memberof','CN=programacion_g,OU=Programacion,OU=Of. Logistica y Patrimonio,OU=EF Administracion,OU=SaludPol,DC=saludpol,DC=local',NULL,'2017-08-23 00:32:09','0','programacion_g','1',NULL,'{\"32\":\"32\"}','1','1','1','1','1','1','2017-08-23 00:32:09','1');
INSERT INTO `glpi_groups` VALUES ('33','0','0','responsables_sp',NULL,'memberof','CN=responsables_sp,OU=SaludPol,DC=saludpol,DC=local',NULL,'2017-08-23 00:32:09','0','responsables_sp','1',NULL,'{\"33\":\"33\"}','1','1','1','1','1','1','2017-08-23 00:32:09','1');
INSERT INTO `glpi_groups` VALUES ('34','0','0','secretarias_sp',NULL,'memberof','CN=secretarias_sp,OU=SaludPol,DC=saludpol,DC=local',NULL,'2017-08-23 00:32:09','0','secretarias_sp','1',NULL,NULL,'1','1','1','1','1','1','2017-08-23 00:32:09','1');
INSERT INTO `glpi_groups` VALUES ('35','0','0','servicios_generales_g',NULL,'memberof','CN=servicios_generales_g,OU=Servicios Generales,OU=Of. Logistica y Patrimonio,OU=EF Administracion,OU=SaludPol,DC=saludpol,DC=local',NULL,'2017-08-23 00:32:09','0','servicios_generales_g','1',NULL,NULL,'1','1','1','1','1','1','2017-08-23 00:32:09','1');
INSERT INTO `glpi_groups` VALUES ('36','0','0','sp_eq_fun_adm_g',NULL,'memberof','CN=sp_eq_fun_adm_g,OU=SaludPol,DC=saludpol,DC=local',NULL,'2017-08-23 00:32:09','0','sp_eq_fun_adm_g','1',NULL,'{\"36\":\"36\"}','1','1','1','1','1','1','2017-08-23 00:32:09','1');
INSERT INTO `glpi_groups` VALUES ('37','0','0','sp_gg_of_macro_regiones_g',NULL,'memberof','CN=sp_gg_of_macro_regiones_g,OU=Of. Macro Regiones,OU=Gerencia General,OU=SaludPol,DC=saludpol,DC=local',NULL,'2017-08-23 00:32:09','0','sp_gg_of_macro_regiones_g','1',NULL,NULL,'1','1','1','1','1','1','2017-08-23 00:32:09','1');
INSERT INTO `glpi_groups` VALUES ('38','0','0','sp_of_eco_con_g',NULL,'memberof','CN=sp_of_eco_con_g,OU=Of. Economia,OU=EF Administracion,OU=SaludPol,DC=saludpol,DC=local',NULL,'2017-08-23 00:32:09','0','sp_of_eco_con_g','1',NULL,NULL,'1','1','1','1','1','1','2017-08-23 00:32:09','1');
INSERT INTO `glpi_groups` VALUES ('40','0','0','Soporte Técnico','',NULL,NULL,NULL,'2017-08-24 10:07:40','0','Soporte Técnico','1',NULL,'{\"40\":\"40\"}','1','1','1','1','1','1','2017-08-24 10:07:40','0');

### Dump table glpi_groups_knowbaseitems

DROP TABLE IF EXISTS `glpi_groups_knowbaseitems`;
CREATE TABLE `glpi_groups_knowbaseitems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `knowbaseitems_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '-1',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `knowbaseitems_id` (`knowbaseitems_id`),
  KEY `groups_id` (`groups_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_groups_problems

DROP TABLE IF EXISTS `glpi_groups_problems`;
CREATE TABLE `glpi_groups_problems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `problems_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`problems_id`,`type`,`groups_id`),
  KEY `group` (`groups_id`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_groups_reminders

DROP TABLE IF EXISTS `glpi_groups_reminders`;
CREATE TABLE `glpi_groups_reminders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reminders_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '-1',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `reminders_id` (`reminders_id`),
  KEY `groups_id` (`groups_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_groups_rssfeeds

DROP TABLE IF EXISTS `glpi_groups_rssfeeds`;
CREATE TABLE `glpi_groups_rssfeeds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rssfeeds_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '-1',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `rssfeeds_id` (`rssfeeds_id`),
  KEY `groups_id` (`groups_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_groups_tickets

DROP TABLE IF EXISTS `glpi_groups_tickets`;
CREATE TABLE `glpi_groups_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`tickets_id`,`type`,`groups_id`),
  KEY `group` (`groups_id`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_groups_users

DROP TABLE IF EXISTS `glpi_groups_users`;
CREATE TABLE `glpi_groups_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `is_manager` tinyint(1) NOT NULL DEFAULT '0',
  `is_userdelegate` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`users_id`,`groups_id`),
  KEY `groups_id` (`groups_id`),
  KEY `is_manager` (`is_manager`),
  KEY `is_userdelegate` (`is_userdelegate`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_groups_users` VALUES ('1','287','36','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('2','288','20','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('3','288','21','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('4','290','4','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('5','290','38','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('6','291','16','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('7','293','20','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('8','293','21','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('9','294','3','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('10','294','28','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('11','296','6','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('12','296','26','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('13','296','34','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('14','299','28','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('15','301','6','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('16','301','34','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('17','301','36','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('18','302','5','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('19','302','38','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('20','304','5','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('21','304','38','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('22','306','36','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('23','307','25','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('24','308','31','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('25','309','36','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('26','310','26','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('27','310','33','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('28','311','21','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('29','314','28','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('30','314','32','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('31','315','28','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('32','315','32','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('33','316','35','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('34','317','24','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('35','318','31','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('36','319','2','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('37','320','5','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('38','320','38','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('39','321','5','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('40','321','38','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('41','335','5','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('42','335','38','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('43','337','12','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('44','339','12','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('45','340','12','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('46','345','20','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('47','345','21','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('48','346','3','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('49','346','28','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('50','347','11','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('51','348','25','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('52','349','3','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('53','349','28','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('54','350','5','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('55','350','38','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('56','351','6','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('57','351','33','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('58','351','36','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('59','354','20','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('60','354','21','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('61','354','33','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('62','355','11','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('63','356','11','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('64','357','11','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('65','358','11','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('66','359','11','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('67','360','11','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('68','361','11','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('69','362','11','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('70','363','11','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('71','364','11','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('72','365','11','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('73','366','11','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('74','367','11','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('75','368','28','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('76','370','17','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('77','372','6','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('78','374','6','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('79','376','6','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('80','378','6','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('81','378','11','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('82','378','34','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('83','379','11','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('84','380','21','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('85','382','35','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('86','383','35','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('87','384','20','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('88','384','21','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('89','385','20','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('90','385','21','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('91','386','20','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('92','386','21','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('93','387','20','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('94','387','21','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('95','388','6','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('96','388','26','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('97','389','6','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('98','389','26','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('99','390','6','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('100','390','25','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('101','391','11','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('102','392','11','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('103','393','11','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('104','395','6','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('105','395','36','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('106','396','36','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('107','407','33','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('108','410','3','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('109','410','28','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('110','411','3','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('111','411','28','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('112','412','3','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('113','412','28','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('114','413','3','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('115','413','28','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('116','414','3','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('117','414','28','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('118','415','3','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('119','415','28','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('120','416','16','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('121','417','28','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('122','418','26','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('123','126','5','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('124','126','38','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('125','134','5','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('126','134','38','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('127','136','5','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('128','136','38','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('129','174','17','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('130','174','33','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('131','7','28','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('132','8','20','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('133','8','21','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('134','12','8','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('135','13','8','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('136','14','8','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('137','15','8','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('138','20','11','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('139','22','16','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('140','23','16','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('141','24','16','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('142','25','16','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('143','32','20','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('144','32','21','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('145','33','30','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('146','35','28','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('147','39','6','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('148','39','27','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('149','39','29','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('150','40','6','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('151','40','38','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('152','41','11','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('153','42','26','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('154','43','8','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('155','45','3','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('156','45','28','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('157','46','3','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('158','46','28','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('159','48','25','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('160','48','33','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('161','50','38','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('162','53','28','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('163','54','28','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('164','55','28','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('165','56','28','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('166','57','28','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('167','58','28','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('168','59','28','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('169','60','28','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('170','62','13','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('171','64','28','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('172','65','16','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('173','66','16','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('174','67','16','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('175','68','16','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('176','69','16','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('177','70','16','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('178','71','16','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('179','72','28','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('180','76','13','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('181','77','9','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('182','77','13','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('183','78','13','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('184','79','13','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('185','83','11','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('186','84','8','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('187','84','33','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('188','86','35','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('189','87','35','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('190','90','24','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('191','92','24','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('192','93','24','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('193','94','2','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('194','95','2','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('195','96','24','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('196','98','24','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('197','99','24','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('198','100','24','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('199','101','2','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('200','102','24','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('201','102','28','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('202','103','24','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('203','104','28','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('204','104','32','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('205','105','24','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('206','106','24','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('207','107','24','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('208','108','24','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('209','109','24','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('210','110','24','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('211','110','28','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('212','111','24','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('213','111','28','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('214','112','24','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('215','113','27','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('216','113','29','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('217','114','24','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('218','115','31','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('219','116','31','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('220','117','31','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('221','118','2','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('222','119','2','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('223','120','2','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('224','121','24','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('225','121','28','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('226','123','27','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('227','123','29','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('228','124','5','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('229','124','38','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('230','125','5','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('231','125','38','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('232','127','5','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('233','127','38','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('234','128','5','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('235','128','38','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('236','129','5','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('237','129','38','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('238','130','5','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('239','130','38','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('240','131','5','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('241','131','38','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('242','132','5','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('243','132','38','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('244','133','5','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('245','133','38','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('246','135','5','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('247','135','38','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('248','138','5','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('249','138','38','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('250','139','5','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('251','139','38','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('252','140','5','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('253','140','38','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('254','141','4','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('255','141','38','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('256','142','4','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('257','142','38','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('258','143','4','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('259','143','38','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('260','145','17','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('261','146','33','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('262','147','3','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('263','147','28','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('264','150','38','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('265','151','37','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('266','153','33','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('267','153','36','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('268','157','11','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('269','159','13','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('270','160','36','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('271','163','21','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('272','164','24','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('273','164','28','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('274','165','17','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('275','166','26','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('276','167','8','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('277','169','31','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('278','173','34','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('279','175','4','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('280','175','38','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('281','176','8','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('282','180','11','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('283','181','6','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('284','181','17','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('285','181','34','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('286','182','32','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('287','183','28','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('288','185','10','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('289','185','33','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('290','186','16','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('291','186','33','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('292','187','5','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('293','187','38','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('294','188','26','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('295','188','37','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('296','189','5','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('297','189','38','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('298','190','3','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('299','190','28','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('300','192','36','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('301','193','3','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('302','193','28','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('303','194','26','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('304','195','6','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('305','195','26','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('306','196','27','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('307','196','29','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('308','197','26','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('309','198','6','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('310','198','20','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('311','198','21','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('312','198','34','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('313','199','20','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('314','199','21','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('315','200','6','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('316','200','25','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('317','200','34','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('318','201','16','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('319','201','33','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('320','203','6','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('321','203','26','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('322','212','6','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('323','212','16','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('324','213','6','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('325','213','16','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('326','219','21','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('327','220','6','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('328','220','34','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('329','221','3','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('330','221','28','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('331','225','6','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('332','225','16','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('333','225','34','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('334','226','6','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('335','226','8','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('336','227','8','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('337','228','11','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('338','229','6','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('339','229','11','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('340','229','34','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('341','231','28','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('342','232','38','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('343','244','9','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('344','245','9','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('345','246','9','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('346','247','9','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('347','437','24','1','0','0');
INSERT INTO `glpi_groups_users` VALUES ('348','177','40','0','1','1');
INSERT INTO `glpi_groups_users` VALUES ('349','303','40','0','1','1');
INSERT INTO `glpi_groups_users` VALUES ('350','422','40','0','0','0');
INSERT INTO `glpi_groups_users` VALUES ('351','436','40','0','1','1');
INSERT INTO `glpi_groups_users` VALUES ('352','343','40','0','0','0');
INSERT INTO `glpi_groups_users` VALUES ('353','184','41','0','0','0');

### Dump table glpi_holidays

DROP TABLE IF EXISTS `glpi_holidays`;
CREATE TABLE `glpi_holidays` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `begin_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `is_perpetual` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `begin_date` (`begin_date`),
  KEY `end_date` (`end_date`),
  KEY `is_perpetual` (`is_perpetual`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_infocoms

DROP TABLE IF EXISTS `glpi_infocoms`;
CREATE TABLE `glpi_infocoms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `buy_date` date DEFAULT NULL,
  `use_date` date DEFAULT NULL,
  `warranty_duration` int(11) NOT NULL DEFAULT '0',
  `warranty_info` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `suppliers_id` int(11) NOT NULL DEFAULT '0',
  `order_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `delivery_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `immo_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `warranty_value` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `sink_time` int(11) NOT NULL DEFAULT '0',
  `sink_type` int(11) NOT NULL DEFAULT '0',
  `sink_coeff` float NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `bill` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `budgets_id` int(11) NOT NULL DEFAULT '0',
  `alert` int(11) NOT NULL DEFAULT '0',
  `order_date` date DEFAULT NULL,
  `delivery_date` date DEFAULT NULL,
  `inventory_date` date DEFAULT NULL,
  `warranty_date` date DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  `decommission_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`itemtype`,`items_id`),
  KEY `buy_date` (`buy_date`),
  KEY `alert` (`alert`),
  KEY `budgets_id` (`budgets_id`),
  KEY `suppliers_id` (`suppliers_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_infocoms` VALUES ('1','1','CartridgeItem','0','0',NULL,NULL,'0',NULL,'0',NULL,NULL,NULL,'0.0000','0.0000','0','0','0',NULL,NULL,'0','0',NULL,NULL,NULL,NULL,'2017-08-24 11:51:26','2017-08-24 11:51:26',NULL);

### Dump table glpi_interfacetypes

DROP TABLE IF EXISTS `glpi_interfacetypes`;
CREATE TABLE `glpi_interfacetypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_interfacetypes` VALUES ('1','IDE',NULL,NULL,NULL);
INSERT INTO `glpi_interfacetypes` VALUES ('2','SATA',NULL,NULL,NULL);
INSERT INTO `glpi_interfacetypes` VALUES ('3','SCSI',NULL,NULL,NULL);
INSERT INTO `glpi_interfacetypes` VALUES ('4','USB',NULL,NULL,NULL);
INSERT INTO `glpi_interfacetypes` VALUES ('5','AGP','',NULL,NULL);
INSERT INTO `glpi_interfacetypes` VALUES ('6','PCI','',NULL,NULL);
INSERT INTO `glpi_interfacetypes` VALUES ('7','PCIe','',NULL,NULL);
INSERT INTO `glpi_interfacetypes` VALUES ('8','PCI-X','',NULL,NULL);

### Dump table glpi_ipaddresses

DROP TABLE IF EXISTS `glpi_ipaddresses`;
CREATE TABLE `glpi_ipaddresses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `version` tinyint(3) unsigned DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `binary_0` int(10) unsigned NOT NULL DEFAULT '0',
  `binary_1` int(10) unsigned NOT NULL DEFAULT '0',
  `binary_2` int(10) unsigned NOT NULL DEFAULT '0',
  `binary_3` int(10) unsigned NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `mainitems_id` int(11) NOT NULL DEFAULT '0',
  `mainitemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `textual` (`name`),
  KEY `binary` (`binary_0`,`binary_1`,`binary_2`,`binary_3`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `item` (`itemtype`,`items_id`,`is_deleted`),
  KEY `mainitem` (`mainitemtype`,`mainitems_id`,`is_deleted`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_ipaddresses_ipnetworks

DROP TABLE IF EXISTS `glpi_ipaddresses_ipnetworks`;
CREATE TABLE `glpi_ipaddresses_ipnetworks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ipaddresses_id` int(11) NOT NULL DEFAULT '0',
  `ipnetworks_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`ipaddresses_id`,`ipnetworks_id`),
  KEY `ipnetworks_id` (`ipnetworks_id`),
  KEY `ipaddresses_id` (`ipaddresses_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_ipnetworks

DROP TABLE IF EXISTS `glpi_ipnetworks`;
CREATE TABLE `glpi_ipnetworks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `ipnetworks_id` int(11) NOT NULL DEFAULT '0',
  `completename` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  `ancestors_cache` longtext COLLATE utf8_unicode_ci,
  `sons_cache` longtext COLLATE utf8_unicode_ci,
  `addressable` tinyint(1) NOT NULL DEFAULT '0',
  `version` tinyint(3) unsigned DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address_0` int(10) unsigned NOT NULL DEFAULT '0',
  `address_1` int(10) unsigned NOT NULL DEFAULT '0',
  `address_2` int(10) unsigned NOT NULL DEFAULT '0',
  `address_3` int(10) unsigned NOT NULL DEFAULT '0',
  `netmask` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `netmask_0` int(10) unsigned NOT NULL DEFAULT '0',
  `netmask_1` int(10) unsigned NOT NULL DEFAULT '0',
  `netmask_2` int(10) unsigned NOT NULL DEFAULT '0',
  `netmask_3` int(10) unsigned NOT NULL DEFAULT '0',
  `gateway` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gateway_0` int(10) unsigned NOT NULL DEFAULT '0',
  `gateway_1` int(10) unsigned NOT NULL DEFAULT '0',
  `gateway_2` int(10) unsigned NOT NULL DEFAULT '0',
  `gateway_3` int(10) unsigned NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `network_definition` (`entities_id`,`address`,`netmask`),
  KEY `address` (`address_0`,`address_1`,`address_2`,`address_3`),
  KEY `netmask` (`netmask_0`,`netmask_1`,`netmask_2`,`netmask_3`),
  KEY `gateway` (`gateway_0`,`gateway_1`,`gateway_2`,`gateway_3`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_ipnetworks_vlans

DROP TABLE IF EXISTS `glpi_ipnetworks_vlans`;
CREATE TABLE `glpi_ipnetworks_vlans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ipnetworks_id` int(11) NOT NULL DEFAULT '0',
  `vlans_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `link` (`ipnetworks_id`,`vlans_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_devicecases

DROP TABLE IF EXISTS `glpi_items_devicecases`;
CREATE TABLE `glpi_items_devicecases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicecases_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicecases_id` (`devicecases_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `serial` (`serial`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_devicecontrols

DROP TABLE IF EXISTS `glpi_items_devicecontrols`;
CREATE TABLE `glpi_items_devicecontrols` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicecontrols_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `busID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicecontrols_id` (`devicecontrols_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `serial` (`serial`),
  KEY `busID` (`busID`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_devicedrives

DROP TABLE IF EXISTS `glpi_items_devicedrives`;
CREATE TABLE `glpi_items_devicedrives` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicedrives_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `busID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicedrives_id` (`devicedrives_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `serial` (`serial`),
  KEY `busID` (`busID`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_devicegraphiccards

DROP TABLE IF EXISTS `glpi_items_devicegraphiccards`;
CREATE TABLE `glpi_items_devicegraphiccards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicegraphiccards_id` int(11) NOT NULL DEFAULT '0',
  `memory` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `busID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicegraphiccards_id` (`devicegraphiccards_id`),
  KEY `specificity` (`memory`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `serial` (`serial`),
  KEY `busID` (`busID`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_deviceharddrives

DROP TABLE IF EXISTS `glpi_items_deviceharddrives`;
CREATE TABLE `glpi_items_deviceharddrives` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `deviceharddrives_id` int(11) NOT NULL DEFAULT '0',
  `capacity` int(11) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `busID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `deviceharddrives_id` (`deviceharddrives_id`),
  KEY `specificity` (`capacity`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `serial` (`serial`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `busID` (`busID`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_devicememories

DROP TABLE IF EXISTS `glpi_items_devicememories`;
CREATE TABLE `glpi_items_devicememories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicememories_id` int(11) NOT NULL DEFAULT '0',
  `size` int(11) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `busID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicememories_id` (`devicememories_id`),
  KEY `specificity` (`size`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `serial` (`serial`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `busID` (`busID`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_devicemotherboards

DROP TABLE IF EXISTS `glpi_items_devicemotherboards`;
CREATE TABLE `glpi_items_devicemotherboards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicemotherboards_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicemotherboards_id` (`devicemotherboards_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `serial` (`serial`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_devicenetworkcards

DROP TABLE IF EXISTS `glpi_items_devicenetworkcards`;
CREATE TABLE `glpi_items_devicenetworkcards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicenetworkcards_id` int(11) NOT NULL DEFAULT '0',
  `mac` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `busID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicenetworkcards_id` (`devicenetworkcards_id`),
  KEY `specificity` (`mac`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `serial` (`serial`),
  KEY `busID` (`busID`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_devicepcis

DROP TABLE IF EXISTS `glpi_items_devicepcis`;
CREATE TABLE `glpi_items_devicepcis` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicepcis_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `busID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicepcis_id` (`devicepcis_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `serial` (`serial`),
  KEY `busID` (`busID`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_devicepowersupplies

DROP TABLE IF EXISTS `glpi_items_devicepowersupplies`;
CREATE TABLE `glpi_items_devicepowersupplies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicepowersupplies_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicepowersupplies_id` (`devicepowersupplies_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `serial` (`serial`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_deviceprocessors

DROP TABLE IF EXISTS `glpi_items_deviceprocessors`;
CREATE TABLE `glpi_items_deviceprocessors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `deviceprocessors_id` int(11) NOT NULL DEFAULT '0',
  `frequency` int(11) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `nbcores` int(11) DEFAULT NULL,
  `nbthreads` int(11) DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `busID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `deviceprocessors_id` (`deviceprocessors_id`),
  KEY `specificity` (`frequency`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `serial` (`serial`),
  KEY `nbcores` (`nbcores`),
  KEY `nbthreads` (`nbthreads`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `busID` (`busID`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_devicesoundcards

DROP TABLE IF EXISTS `glpi_items_devicesoundcards`;
CREATE TABLE `glpi_items_devicesoundcards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicesoundcards_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `busID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicesoundcards_id` (`devicesoundcards_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `serial` (`serial`),
  KEY `busID` (`busID`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_problems

DROP TABLE IF EXISTS `glpi_items_problems`;
CREATE TABLE `glpi_items_problems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `problems_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`problems_id`,`itemtype`,`items_id`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_projects

DROP TABLE IF EXISTS `glpi_items_projects`;
CREATE TABLE `glpi_items_projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `projects_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`projects_id`,`itemtype`,`items_id`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_tickets

DROP TABLE IF EXISTS `glpi_items_tickets`;
CREATE TABLE `glpi_items_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`itemtype`,`items_id`,`tickets_id`),
  KEY `tickets_id` (`tickets_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_itilcategories

DROP TABLE IF EXISTS `glpi_itilcategories`;
CREATE TABLE `glpi_itilcategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `itilcategories_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `completename` text COLLATE utf8_unicode_ci,
  `comment` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  `knowbaseitemcategories_id` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `ancestors_cache` longtext COLLATE utf8_unicode_ci,
  `sons_cache` longtext COLLATE utf8_unicode_ci,
  `is_helpdeskvisible` tinyint(1) NOT NULL DEFAULT '1',
  `tickettemplates_id_incident` int(11) NOT NULL DEFAULT '0',
  `tickettemplates_id_demand` int(11) NOT NULL DEFAULT '0',
  `is_incident` int(11) NOT NULL DEFAULT '1',
  `is_request` int(11) NOT NULL DEFAULT '1',
  `is_problem` int(11) NOT NULL DEFAULT '1',
  `is_change` tinyint(1) NOT NULL DEFAULT '1',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `knowbaseitemcategories_id` (`knowbaseitemcategories_id`),
  KEY `users_id` (`users_id`),
  KEY `groups_id` (`groups_id`),
  KEY `is_helpdeskvisible` (`is_helpdeskvisible`),
  KEY `itilcategories_id` (`itilcategories_id`),
  KEY `tickettemplates_id_incident` (`tickettemplates_id_incident`),
  KEY `tickettemplates_id_demand` (`tickettemplates_id_demand`),
  KEY `is_incident` (`is_incident`),
  KEY `is_request` (`is_request`),
  KEY `is_problem` (`is_problem`),
  KEY `is_change` (`is_change`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_itilcategories` VALUES ('1','0','0','0','Soporte técnico','Soporte técnico','','1','0','0','40',NULL,'{\"1\":\"1\",\"5\":\"5\",\"8\":\"8\",\"9\":\"9\",\"6\":\"6\",\"7\":\"7\",\"10\":\"10\",\"11\":\"11\",\"12\":\"12\",\"13\":\"13\",\"14\":\"14\",\"18\":\"18\",\"17\":\"17\",\"16\":\"16\",\"19\":\"19\",\"20\":\"20\",\"22\":\"22\",\"21\":\"21\",\"23\":\"23\",\"24\":\"24\",\"25\":\"25\",\"26\":\"26\",\"27\":\"27\",\"28\":\"28\",\"29\":\"29\",\"30\":\"30\",\"31\":\"31\",\"32\":\"32\",\"33\":\"33\",\"47\":\"47\",\"35\":\"35\",\"34\":\"34\",\"36\":\"36\",\"37\":\"37\",\"38\":\"38\",\"39\":\"39\",\"40\":\"40\",\"41\":\"41\",\"42\":\"42\",\"43\":\"43\",\"44\":\"44\",\"45\":\"45\",\"46\":\"46\",\"48\":\"48\",\"49\":\"49\",\"50\":\"50\",\"51\":\"51\",\"52\":\"52\",\"53\":\"53\",\"54\":\"54\",\"55\":\"55\",\"56\":\"56\",\"57\":\"57\",\"58\":\"58\",\"59\":\"59\",\"60\":\"60\",\"61\":\"61\",\"62\":\"62\",\"63\":\"63\",\"64\":\"64\",\"65\":\"65\",\"66\":\"66\",\"67\":\"67\"}','1','0','0','1','1','1','1','2017-08-24 12:17:12','2017-08-24 10:08:11');
INSERT INTO `glpi_itilcategories` VALUES ('2','0','0','0','Área de desarrollo','Área de desarrollo','','1','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:35:06','2017-08-24 10:08:41');
INSERT INTO `glpi_itilcategories` VALUES ('3','0','0','0','Redes / Servicios','Redes / Servicios','','1','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 10:09:02','2017-08-24 10:09:02');
INSERT INTO `glpi_itilcategories` VALUES ('5','0','0','1','Aplicativos','Soporte técnico > Aplicativos',NULL,'2','0','0','0',NULL,'{\"5\":\"5\",\"18\":\"18\",\"17\":\"17\",\"20\":\"20\",\"19\":\"19\",\"16\":\"16\"}','1','0','0','1','1','1','1','2017-08-24 11:04:30','2017-08-24 11:04:30');
INSERT INTO `glpi_itilcategories` VALUES ('18','0','0','5','Antivirus','Soporte técnico > Aplicativos > Antivirus',NULL,'3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:17:47','2017-08-24 11:17:47');
INSERT INTO `glpi_itilcategories` VALUES ('6','0','0','1','Gestión de datos','Soporte técnico > Gestión de datos',NULL,'2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:04:39','2017-08-24 11:04:39');
INSERT INTO `glpi_itilcategories` VALUES ('7','0','0','1','Gestión de usuarios','Soporte técnico > Gestión de usuarios',NULL,'2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:04:48','2017-08-24 11:04:48');
INSERT INTO `glpi_itilcategories` VALUES ('8','0','0','1','Correos','Soporte técnico > Correos',NULL,'2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:04:55','2017-08-24 11:04:55');
INSERT INTO `glpi_itilcategories` VALUES ('9','0','0','1','Equipo de cómputo','Soporte técnico > Equipo de cómputo',NULL,'2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:05:02','2017-08-24 11:05:02');
INSERT INTO `glpi_itilcategories` VALUES ('10','0','0','1','Impresoras','Soporte técnico > Impresoras',NULL,'2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:05:19','2017-08-24 11:05:19');
INSERT INTO `glpi_itilcategories` VALUES ('11','0','0','1','Internet','Soporte técnico > Internet',NULL,'2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:05:25','2017-08-24 11:05:25');
INSERT INTO `glpi_itilcategories` VALUES ('12','0','0','1','Red local','Soporte técnico > Red local',NULL,'2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:05:29','2017-08-24 11:05:29');
INSERT INTO `glpi_itilcategories` VALUES ('13','0','0','1','Sistema operativo','Soporte técnico > Sistema operativo',NULL,'2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:05:33','2017-08-24 11:05:33');
INSERT INTO `glpi_itilcategories` VALUES ('14','0','0','1','Telefonía','Soporte técnico > Telefonía',NULL,'2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:05:38','2017-08-24 11:05:38');
INSERT INTO `glpi_itilcategories` VALUES ('17','0','0','5','Microsoft Office','Soporte técnico > Aplicativos > Microsoft Office',NULL,'3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:17:39','2017-08-24 11:17:39');
INSERT INTO `glpi_itilcategories` VALUES ('16','0','0','5','Sistema Operativo Windows','Soporte técnico > Aplicativos > Sistema Operativo Windows',NULL,'3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:15:28','2017-08-24 11:15:28');
INSERT INTO `glpi_itilcategories` VALUES ('19','0','0','5','PDF','Soporte técnico > Aplicativos > PDF',NULL,'3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:18:17','2017-08-24 11:18:17');
INSERT INTO `glpi_itilcategories` VALUES ('20','0','0','5','Otros','Soporte técnico > Aplicativos > Otros',NULL,'3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:18:26','2017-08-24 11:18:26');
INSERT INTO `glpi_itilcategories` VALUES ('22','0','0','6','Creación de carpetas compartidas','Soporte técnico > Gestión de datos > Creación de carpetas compartidas',NULL,'3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:18:59','2017-08-24 11:18:59');
INSERT INTO `glpi_itilcategories` VALUES ('21','0','0','6','Copias de seguridad Usuario PC','Soporte técnico > Gestión de datos > Copias de seguridad Usuario PC',NULL,'3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:18:52','2017-08-24 11:18:52');
INSERT INTO `glpi_itilcategories` VALUES ('23','0','0','6','Recuperación de archivos borrados','Soporte técnico > Gestión de datos > Recuperación de archivos borrados',NULL,'3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:19:05','2017-08-24 11:19:05');
INSERT INTO `glpi_itilcategories` VALUES ('24','0','0','7','Usuario de red y clave','Soporte técnico > Gestión de usuarios > Usuario de red y clave',NULL,'3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:20:16','2017-08-24 11:20:16');
INSERT INTO `glpi_itilcategories` VALUES ('25','0','0','7','Usuario bloqueado','Soporte técnico > Gestión de usuarios > Usuario bloqueado',NULL,'3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:20:21','2017-08-24 11:20:21');
INSERT INTO `glpi_itilcategories` VALUES ('26','0','0','7','Usuario temporal','Soporte técnico > Gestión de usuarios > Usuario temporal',NULL,'3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:20:26','2017-08-24 11:20:26');
INSERT INTO `glpi_itilcategories` VALUES ('27','0','0','7','Configurar acceso a las carpetas compartidas','Soporte técnico > Gestión de usuarios > Configurar acceso a las carpetas compartidas',NULL,'3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:20:31','2017-08-24 11:20:31');
INSERT INTO `glpi_itilcategories` VALUES ('28','0','0','7','Configurar acceso a las impresoras','Soporte técnico > Gestión de usuarios > Configurar acceso a las impresoras',NULL,'3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:20:35','2017-08-24 11:20:35');
INSERT INTO `glpi_itilcategories` VALUES ('29','0','0','7','Configurar acceso a Internet','Soporte técnico > Gestión de usuarios > Configurar acceso a Internet',NULL,'3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:20:40','2017-08-24 11:20:40');
INSERT INTO `glpi_itilcategories` VALUES ('30','0','0','7','Configurar carpeta de escaneos','Soporte técnico > Gestión de usuarios > Configurar carpeta de escaneos',NULL,'3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:20:47','2017-08-24 11:20:47');
INSERT INTO `glpi_itilcategories` VALUES ('31','0','0','8','Microsoft Outlook','Soporte técnico > Correos > Microsoft Outlook',NULL,'3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:21:20','2017-08-24 11:21:20');
INSERT INTO `glpi_itilcategories` VALUES ('32','0','0','8','Zimbra web','Soporte técnico > Correos > Zimbra web',NULL,'3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:21:30','2017-08-24 11:21:30');
INSERT INTO `glpi_itilcategories` VALUES ('33','0','0','8','Hotmail, Gmail, Yahoo','Soporte técnico > Correos > Hotmail, Gmail, Yahoo',NULL,'3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:21:39','2017-08-24 11:21:39');
INSERT INTO `glpi_itilcategories` VALUES ('47','0','0','6','Otros','Soporte técnico > Gestión de datos > Otros',NULL,'3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:25:06','2017-08-24 11:25:06');
INSERT INTO `glpi_itilcategories` VALUES ('35','0','0','9','Monitor','Soporte técnico > Equipo de cómputo > Monitor',NULL,'3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:22:51','2017-08-24 11:22:51');
INSERT INTO `glpi_itilcategories` VALUES ('34','0','0','9','CPU','Soporte técnico > Equipo de cómputo > CPU',NULL,'3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:22:45','2017-08-24 11:22:45');
INSERT INTO `glpi_itilcategories` VALUES ('36','0','0','9','Teclado y/o mouse','Soporte técnico > Equipo de cómputo > Teclado y/o mouse',NULL,'3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:22:56','2017-08-24 11:22:56');
INSERT INTO `glpi_itilcategories` VALUES ('37','0','0','9','Disco duro','Soporte técnico > Equipo de cómputo > Disco duro',NULL,'3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:23:00','2017-08-24 11:23:00');
INSERT INTO `glpi_itilcategories` VALUES ('38','0','0','9','Lectora','Soporte técnico > Equipo de cómputo > Lectora',NULL,'3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:23:04','2017-08-24 11:23:04');
INSERT INTO `glpi_itilcategories` VALUES ('39','0','0','9','Fuente / estabilizador','Soporte técnico > Equipo de cómputo > Fuente / estabilizador',NULL,'3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:23:08','2017-08-24 11:23:08');
INSERT INTO `glpi_itilcategories` VALUES ('40','0','0','9','Memoria / placa','Soporte técnico > Equipo de cómputo > Memoria / placa',NULL,'3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:23:12','2017-08-24 11:23:12');
INSERT INTO `glpi_itilcategories` VALUES ('41','0','0','10','Cambio de tóner, tinta o cinta','Soporte técnico > Impresoras > Cambio de tóner, tinta o cinta',NULL,'3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:24:02','2017-08-24 11:24:02');
INSERT INTO `glpi_itilcategories` VALUES ('42','0','0','10','Fusor','Soporte técnico > Impresoras > Fusor',NULL,'3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:24:13','2017-08-24 11:24:13');
INSERT INTO `glpi_itilcategories` VALUES ('43','0','0','10','Atasco de papel','Soporte técnico > Impresoras > Atasco de papel',NULL,'3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:24:16','2017-08-24 11:24:16');
INSERT INTO `glpi_itilcategories` VALUES ('44','0','0','10','No imprime','Soporte técnico > Impresoras > No imprime',NULL,'3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:24:23','2017-08-24 11:24:23');
INSERT INTO `glpi_itilcategories` VALUES ('45','0','0','10','Otros','Soporte técnico > Impresoras > Otros',NULL,'3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:24:28','2017-08-24 11:24:28');
INSERT INTO `glpi_itilcategories` VALUES ('46','0','0','8','Otros','Soporte técnico > Correos > Otros',NULL,'3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:24:50','2017-08-24 11:24:50');
INSERT INTO `glpi_itilcategories` VALUES ('48','0','0','7','Otros','Soporte técnico > Gestión de usuarios > Otros',NULL,'3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:25:19','2017-08-24 11:25:19');
INSERT INTO `glpi_itilcategories` VALUES ('49','0','0','9','Otros','Soporte técnico > Equipo de cómputo > Otros',NULL,'3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:25:41','2017-08-24 11:25:41');
INSERT INTO `glpi_itilcategories` VALUES ('50','0','0','11','Acceso a páginas bloqueadas por firewall','Soporte técnico > Internet > Acceso a páginas bloqueadas por firewall',NULL,'3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:26:09','2017-08-24 11:26:09');
INSERT INTO `glpi_itilcategories` VALUES ('51','0','0','11','Descargas de aplicativos (Sunat, SPIJ, otros)','Soporte técnico > Internet > Descargas de aplicativos (Sunat, SPIJ, otros)',NULL,'3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:26:16','2017-08-24 11:26:16');
INSERT INTO `glpi_itilcategories` VALUES ('52','0','0','11','Sin servicio','Soporte técnico > Internet > Sin servicio',NULL,'3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:26:22','2017-08-24 11:26:22');
INSERT INTO `glpi_itilcategories` VALUES ('53','0','0','11','Otros','Soporte técnico > Internet > Otros',NULL,'3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:26:29','2017-08-24 11:26:29');
INSERT INTO `glpi_itilcategories` VALUES ('54','0','0','12','Cableado y conectividad','Soporte técnico > Red local > Cableado y conectividad',NULL,'3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:26:50','2017-08-24 11:26:50');
INSERT INTO `glpi_itilcategories` VALUES ('55','0','0','12','Routers, Switches y Access Point','Soporte técnico > Red local > Routers, Switches y Access Point',NULL,'3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:27:01','2017-08-24 11:27:01');
INSERT INTO `glpi_itilcategories` VALUES ('56','0','0','12','Nuevos equipos','Soporte técnico > Red local > Nuevos equipos',NULL,'3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:27:07','2017-08-24 11:27:07');
INSERT INTO `glpi_itilcategories` VALUES ('57','0','0','12','Sin servicio','Soporte técnico > Red local > Sin servicio',NULL,'3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:27:12','2017-08-24 11:27:12');
INSERT INTO `glpi_itilcategories` VALUES ('58','0','0','12','Otros','Soporte técnico > Red local > Otros',NULL,'3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:27:19','2017-08-24 11:27:19');
INSERT INTO `glpi_itilcategories` VALUES ('59','0','0','13','Licencia de software','Soporte técnico > Sistema operativo > Licencia de software',NULL,'3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:27:35','2017-08-24 11:27:35');
INSERT INTO `glpi_itilcategories` VALUES ('60','0','0','13','Windows no responde','Soporte técnico > Sistema operativo > Windows no responde',NULL,'3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:27:41','2017-08-24 11:27:41');
INSERT INTO `glpi_itilcategories` VALUES ('61','0','0','13','Actualizaciones automáticas','Soporte técnico > Sistema operativo > Actualizaciones automáticas',NULL,'3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:27:46','2017-08-24 11:27:46');
INSERT INTO `glpi_itilcategories` VALUES ('62','0','0','13','Cambio de sistema operativo','Soporte técnico > Sistema operativo > Cambio de sistema operativo',NULL,'3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:27:51','2017-08-24 11:27:51');
INSERT INTO `glpi_itilcategories` VALUES ('63','0','0','13','Otros','Soporte técnico > Sistema operativo > Otros',NULL,'3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:27:56','2017-08-24 11:27:56');
INSERT INTO `glpi_itilcategories` VALUES ('64','0','0','14','Cableado','Soporte técnico > Telefonía > Cableado',NULL,'3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:28:07','2017-08-24 11:28:07');
INSERT INTO `glpi_itilcategories` VALUES ('65','0','0','14','Instalación/cambio de equipos','Soporte técnico > Telefonía > Instalación/cambio de equipos',NULL,'3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:28:12','2017-08-24 11:28:12');
INSERT INTO `glpi_itilcategories` VALUES ('66','0','0','14','Sin servicio','Soporte técnico > Telefonía > Sin servicio',NULL,'3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:28:16','2017-08-24 11:28:16');
INSERT INTO `glpi_itilcategories` VALUES ('67','0','0','14','Otros','Soporte técnico > Telefonía > Otros',NULL,'3','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:28:21','2017-08-24 11:28:21');
INSERT INTO `glpi_itilcategories` VALUES ('75','0','0','3','Desbloqueo de usuarios de red','Redes / Servicios > Desbloqueo de usuarios de red',NULL,'2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:38:50','2017-08-24 11:38:50');
INSERT INTO `glpi_itilcategories` VALUES ('68','0','0','2','Cambios a sistemas','Área de desarrollo > Cambios a sistemas',NULL,'2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:36:20','2017-08-24 11:36:20');
INSERT INTO `glpi_itilcategories` VALUES ('69','0','0','2','Creación de usuarios y perfiles','Área de desarrollo > Creación de usuarios y perfiles',NULL,'2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:36:39','2017-08-24 11:36:39');
INSERT INTO `glpi_itilcategories` VALUES ('70','0','0','2','Desarrollo de nuevas funcionalidades','Área de desarrollo > Desarrollo de nuevas funcionalidades',NULL,'2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:37:02','2017-08-24 11:37:02');
INSERT INTO `glpi_itilcategories` VALUES ('71','0','0','2','Errores en el sistema (bugs)','Área de desarrollo > Errores en el sistema (bugs)',NULL,'2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:37:27','2017-08-24 11:37:27');
INSERT INTO `glpi_itilcategories` VALUES ('72','0','0','2','Lentitud y caídas del sistema','Área de desarrollo > Lentitud y caídas del sistema',NULL,'2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:37:46','2017-08-24 11:37:46');
INSERT INTO `glpi_itilcategories` VALUES ('73','0','0','2','Otros','Área de desarrollo > Otros',NULL,'2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:37:51','2017-08-24 11:37:51');
INSERT INTO `glpi_itilcategories` VALUES ('74','0','0','3','Creación / modificación de usuarios de red','Redes / Servicios > Creación / modificación de usuarios de red',NULL,'2','0','0','0',NULL,NULL,'1','0','0','1','1','1','1','2017-08-24 11:38:30','2017-08-24 11:38:30');

### Dump table glpi_knowbaseitemcategories

DROP TABLE IF EXISTS `glpi_knowbaseitemcategories`;
CREATE TABLE `glpi_knowbaseitemcategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `knowbaseitemcategories_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `completename` text COLLATE utf8_unicode_ci,
  `comment` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  `sons_cache` longtext COLLATE utf8_unicode_ci,
  `ancestors_cache` longtext COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`entities_id`,`knowbaseitemcategories_id`,`name`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_knowbaseitems

DROP TABLE IF EXISTS `glpi_knowbaseitems`;
CREATE TABLE `glpi_knowbaseitems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `knowbaseitemcategories_id` int(11) NOT NULL DEFAULT '0',
  `name` text COLLATE utf8_unicode_ci,
  `answer` longtext COLLATE utf8_unicode_ci,
  `is_faq` tinyint(1) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  `view` int(11) NOT NULL DEFAULT '0',
  `date` datetime DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `begin_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `users_id` (`users_id`),
  KEY `knowbaseitemcategories_id` (`knowbaseitemcategories_id`),
  KEY `is_faq` (`is_faq`),
  KEY `date_mod` (`date_mod`),
  FULLTEXT KEY `fulltext` (`name`,`answer`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_knowbaseitems_profiles

DROP TABLE IF EXISTS `glpi_knowbaseitems_profiles`;
CREATE TABLE `glpi_knowbaseitems_profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `knowbaseitems_id` int(11) NOT NULL DEFAULT '0',
  `profiles_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '-1',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `knowbaseitems_id` (`knowbaseitems_id`),
  KEY `profiles_id` (`profiles_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_knowbaseitems_users

DROP TABLE IF EXISTS `glpi_knowbaseitems_users`;
CREATE TABLE `glpi_knowbaseitems_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `knowbaseitems_id` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `knowbaseitems_id` (`knowbaseitems_id`),
  KEY `users_id` (`users_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_knowbaseitemtranslations

DROP TABLE IF EXISTS `glpi_knowbaseitemtranslations`;
CREATE TABLE `glpi_knowbaseitemtranslations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `knowbaseitems_id` int(11) NOT NULL DEFAULT '0',
  `language` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` text COLLATE utf8_unicode_ci,
  `answer` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `item` (`knowbaseitems_id`,`language`),
  FULLTEXT KEY `fulltext` (`name`,`answer`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_links

DROP TABLE IF EXISTS `glpi_links`;
CREATE TABLE `glpi_links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '1',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `link` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `data` text COLLATE utf8_unicode_ci,
  `open_window` tinyint(1) NOT NULL DEFAULT '1',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_links_itemtypes

DROP TABLE IF EXISTS `glpi_links_itemtypes`;
CREATE TABLE `glpi_links_itemtypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `links_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`itemtype`,`links_id`),
  KEY `links_id` (`links_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_locations

DROP TABLE IF EXISTS `glpi_locations`;
CREATE TABLE `glpi_locations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `completename` text COLLATE utf8_unicode_ci,
  `comment` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  `ancestors_cache` longtext COLLATE utf8_unicode_ci,
  `sons_cache` longtext COLLATE utf8_unicode_ci,
  `building` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `room` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `latitude` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `longitude` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `altitude` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`entities_id`,`locations_id`,`name`),
  KEY `locations_id` (`locations_id`),
  KEY `name` (`name`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_locations` VALUES ('1','0','0','GERENCIA GENERAL','0','GERENCIA GENERAL','','1',NULL,NULL,'','','','','','2017-08-25 14:19:56','2017-08-25 14:19:56');
INSERT INTO `glpi_locations` VALUES ('2','0','0','EQUIPO FUNCIONAL DE PLANEAMIENTO, PRESUPUESTO Y MODERNIZACIÓN','0','EQUIPO FUNCIONAL DE PLANEAMIENTO, PRESUPUESTO Y MODERNIZACIÓN','','1',NULL,NULL,'','','','','','2017-08-25 14:20:09','2017-08-25 14:20:09');
INSERT INTO `glpi_locations` VALUES ('3','0','0','EQUIPO FUNCIONAL DE ASESORÍA JURÍDICA','0','EQUIPO FUNCIONAL DE ASESORÍA JURÍDICA','','1',NULL,NULL,'','','','','','2017-08-25 14:20:15','2017-08-25 14:20:15');
INSERT INTO `glpi_locations` VALUES ('4','0','0','EQUIPO FUNCIONAL DE ADMINISTRACIÓN','0','EQUIPO FUNCIONAL DE ADMINISTRACIÓN','','1',NULL,NULL,'','','','','','2017-08-25 14:21:03','2017-08-25 14:21:03');
INSERT INTO `glpi_locations` VALUES ('5','0','0','EQUIPO FUNCIONAL DE GESTIÓN Y DESARROLLO DE RECURSOS HUMANOS','0','EQUIPO FUNCIONAL DE GESTIÓN Y DESARROLLO DE RECURSOS HUMANOS','','1',NULL,'{\"5\":\"5\",\"28\":\"28\"}','','','','','','2017-08-25 14:21:10','2017-08-25 14:21:10');
INSERT INTO `glpi_locations` VALUES ('6','0','0','EQUIPO FUNCIONAL DE ESTADÍSTICA, TECNOLOGÍA DE LA INFORMACIÓN Y COMUNICACIONES','0','EQUIPO FUNCIONAL DE ESTADÍSTICA, TECNOLOGÍA DE LA INFORMACIÓN Y COMUNICACIONES','','1',NULL,'{\"6\":\"6\"}','','','','','','2017-08-25 14:21:15','2017-08-25 14:21:15');
INSERT INTO `glpi_locations` VALUES ('7','0','0','EQUIPO FUNCIONAL DE GESTIÓN DEL ASEGURADO','0','EQUIPO FUNCIONAL DE GESTIÓN DEL ASEGURADO','','1',NULL,NULL,'','','','','','2017-08-25 14:21:20','2017-08-25 14:21:20');
INSERT INTO `glpi_locations` VALUES ('8','0','0','EQUIPO FUNCIONAL DE FINANCIAMIENTO','0','EQUIPO FUNCIONAL DE FINANCIAMIENTO','','1',NULL,NULL,'','','','','','2017-08-25 14:21:24','2017-08-25 14:21:24');
INSERT INTO `glpi_locations` VALUES ('9','0','0','EQUIPO FUNCIONAL DE PRESTACIONES DE SALUD','0','EQUIPO FUNCIONAL DE PRESTACIONES DE SALUD','','1',NULL,NULL,'','','','','','2017-08-25 14:21:29','2017-08-25 14:21:29');
INSERT INTO `glpi_locations` VALUES ('10','0','0','OFICINAS DE SEGUROS','0','OFICINAS DE SEGUROS','','1',NULL,NULL,'','','','','','2017-08-25 14:21:34','2017-08-25 14:21:34');
INSERT INTO `glpi_locations` VALUES ('11','0','0','UNIDAD SALUDPOL CHIMBOTE','0','UNIDAD SALUDPOL CHIMBOTE','','1',NULL,NULL,'','','','','','2017-08-25 14:21:41','2017-08-25 14:21:41');
INSERT INTO `glpi_locations` VALUES ('13','0','0','EQUIPO FUNCIONAL DE PLANEAMIENTO, PRESUPUESTO Y MODERNIZACIÓN','2','EQUIPO FUNCIONAL DE PLANEAMIENTO, PRESUPUESTO Y MODERNIZACIÓN > EQUIPO FUNCIONAL DE PLANEAMIENTO, PRESUPUESTO Y MODERNIZACIÓN',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-08-25 14:23:07','2017-08-25 14:23:07');
INSERT INTO `glpi_locations` VALUES ('12','0','0','GERENCIA GENERAL','1','GERENCIA GENERAL > GERENCIA GENERAL',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-08-25 14:22:06','2017-08-25 14:22:06');
INSERT INTO `glpi_locations` VALUES ('14','0','0','OFICINA DE PLANEAMIENTO','2','EQUIPO FUNCIONAL DE PLANEAMIENTO, PRESUPUESTO Y MODERNIZACIÓN > OFICINA DE PLANEAMIENTO',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-08-25 14:23:12','2017-08-25 14:23:12');
INSERT INTO `glpi_locations` VALUES ('15','0','0','OFICINA DE PRESUPUESTO','2','EQUIPO FUNCIONAL DE PLANEAMIENTO, PRESUPUESTO Y MODERNIZACIÓN > OFICINA DE PRESUPUESTO',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-08-25 14:23:18','2017-08-25 14:23:18');
INSERT INTO `glpi_locations` VALUES ('16','0','0','OFICINA DE MODERNIZACIÓN','2','EQUIPO FUNCIONAL DE PLANEAMIENTO, PRESUPUESTO Y MODERNIZACIÓN > OFICINA DE MODERNIZACIÓN',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-08-25 14:23:23','2017-08-25 14:23:23');
INSERT INTO `glpi_locations` VALUES ('17','0','0','EQUIPO FUNCIONAL DE ASESORÍA JURÍDICA','3','EQUIPO FUNCIONAL DE ASESORÍA JURÍDICA > EQUIPO FUNCIONAL DE ASESORÍA JURÍDICA',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-08-25 14:23:52','2017-08-25 14:23:52');
INSERT INTO `glpi_locations` VALUES ('18','0','0','EQUIPO FUNCIONAL DE ADMINISTRACIÓN','4','EQUIPO FUNCIONAL DE ADMINISTRACIÓN > EQUIPO FUNCIONAL DE ADMINISTRACIÓN',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-08-25 14:24:39','2017-08-25 14:24:39');
INSERT INTO `glpi_locations` VALUES ('19','0','0','OFICINA DE ECONOMÍA','4','EQUIPO FUNCIONAL DE ADMINISTRACIÓN > OFICINA DE ECONOMÍA',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-08-25 14:24:43','2017-08-25 14:24:43');
INSERT INTO `glpi_locations` VALUES ('20','0','0','OFICINA DE LOGÍSTICA Y PATRIMONIO','4','EQUIPO FUNCIONAL DE ADMINISTRACIÓN > OFICINA DE LOGÍSTICA Y PATRIMONIO',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-08-25 14:24:48','2017-08-25 14:24:48');
INSERT INTO `glpi_locations` VALUES ('21','0','0','GESTIÓN DOCUMENTARIA Y ARCHIVO','4','EQUIPO FUNCIONAL DE ADMINISTRACIÓN > GESTIÓN DOCUMENTARIA Y ARCHIVO',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-08-25 14:24:53','2017-08-25 14:24:53');
INSERT INTO `glpi_locations` VALUES ('22','0','0','GESTIÓN DOCUMENTARIA Y ARCHIVO - HLNS','4','EQUIPO FUNCIONAL DE ADMINISTRACIÓN > GESTIÓN DOCUMENTARIA Y ARCHIVO - HLNS',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-08-25 14:25:20','2017-08-25 14:25:20');
INSERT INTO `glpi_locations` VALUES ('23','0','0','AREA DE TESORERIA','19','EQUIPO FUNCIONAL DE ADMINISTRACIÓN > OFICINA DE ECONOMÍA > AREA DE TESORERIA',NULL,'3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-08-25 14:25:32','2017-08-25 14:25:32');
INSERT INTO `glpi_locations` VALUES ('24','0','0','AREA DE CONTABILIDAD','19','EQUIPO FUNCIONAL DE ADMINISTRACIÓN > OFICINA DE ECONOMÍA > AREA DE CONTABILIDAD',NULL,'3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-08-25 14:25:38','2017-08-25 14:25:38');
INSERT INTO `glpi_locations` VALUES ('25','0','0','AREA DE CONTROL PREVIO','19','EQUIPO FUNCIONAL DE ADMINISTRACIÓN > OFICINA DE ECONOMÍA > AREA DE CONTROL PREVIO',NULL,'3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-08-25 14:25:46','2017-08-25 14:25:46');
INSERT INTO `glpi_locations` VALUES ('26','0','0','AREA DE CAJA CHICA','19','EQUIPO FUNCIONAL DE ADMINISTRACIÓN > OFICINA DE ECONOMÍA > AREA DE CAJA CHICA',NULL,'3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-08-25 14:25:51','2017-08-25 14:25:51');
INSERT INTO `glpi_locations` VALUES ('27','0','0','AREA DE CAJA CHICA - HLNS','19','EQUIPO FUNCIONAL DE ADMINISTRACIÓN > OFICINA DE ECONOMÍA > AREA DE CAJA CHICA - HLNS',NULL,'3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-08-25 14:26:05','2017-08-25 14:26:05');
INSERT INTO `glpi_locations` VALUES ('28','0','0','EQUIPO FUNCIONAL DE GESTIÓN Y DESARROLLO DE RECURSOS HUMANOS','5','EQUIPO FUNCIONAL DE GESTIÓN Y DESARROLLO DE RECURSOS HUMANOS > EQUIPO FUNCIONAL DE GESTIÓN Y DESARROLLO DE RECURSOS HUMANOS',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-08-25 14:26:35','2017-08-25 14:26:35');
INSERT INTO `glpi_locations` VALUES ('30','0','0','OFICINA DE PROMOCION Y VIGILANCIA DE LOS DERECHOS DEL ASEGURADO','7','EQUIPO FUNCIONAL DE GESTIÓN DEL ASEGURADO > OFICINA DE PROMOCION Y VIGILANCIA DE LOS DERECHOS DEL ASEGURADO',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-08-25 14:27:14','2017-08-25 14:27:14');
INSERT INTO `glpi_locations` VALUES ('29','0','0','EQUIPO FUNCIONAL DE GESTIÓN DEL ASEGURADO','7','EQUIPO FUNCIONAL DE GESTIÓN DEL ASEGURADO > EQUIPO FUNCIONAL DE GESTIÓN DEL ASEGURADO',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-08-25 14:27:10','2017-08-25 14:27:10');
INSERT INTO `glpi_locations` VALUES ('31','0','0','OFICINA DE GESTION DEL ASEGURAMIENTO','7','EQUIPO FUNCIONAL DE GESTIÓN DEL ASEGURADO > OFICINA DE GESTION DEL ASEGURAMIENTO',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-08-25 14:27:19','2017-08-25 14:27:19');
INSERT INTO `glpi_locations` VALUES ('32','0','0','OFICINA DE SEGUROS LIMA','7','EQUIPO FUNCIONAL DE GESTIÓN DEL ASEGURADO > OFICINA DE SEGUROS LIMA',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-08-25 14:27:23','2017-08-25 14:27:23');
INSERT INTO `glpi_locations` VALUES ('33','0','0','EQUIPO FUNCIONAL DE FINANCIAMIENTO','8','EQUIPO FUNCIONAL DE FINANCIAMIENTO > EQUIPO FUNCIONAL DE FINANCIAMIENTO',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-08-25 14:27:41','2017-08-25 14:27:41');
INSERT INTO `glpi_locations` VALUES ('34','0','0','OFICINA DE CARTAS DE GARANTÍA','8','EQUIPO FUNCIONAL DE FINANCIAMIENTO > OFICINA DE CARTAS DE GARANTÍA',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-08-25 14:27:49','2017-08-25 14:27:49');
INSERT INTO `glpi_locations` VALUES ('35','0','0','EQUIPO FUNCIONAL DE PRESTACIONES DE SALUD','9','EQUIPO FUNCIONAL DE PRESTACIONES DE SALUD > EQUIPO FUNCIONAL DE PRESTACIONES DE SALUD',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-08-25 14:28:26','2017-08-25 14:28:26');
INSERT INTO `glpi_locations` VALUES ('36','0','0','OFICINAS DE SEGUROS','10','OFICINAS DE SEGUROS > OFICINAS DE SEGUROS',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-08-25 14:28:42','2017-08-25 14:28:42');
INSERT INTO `glpi_locations` VALUES ('37','0','0','UNIDAD SALUDPOL LIMA','10','OFICINAS DE SEGUROS > UNIDAD SALUDPOL LIMA',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-08-25 14:28:49','2017-08-25 14:28:49');
INSERT INTO `glpi_locations` VALUES ('38','0','0','UNIDAD SALUDPOL LAMBAYEQUE','10','OFICINAS DE SEGUROS > UNIDAD SALUDPOL LAMBAYEQUE',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-08-25 14:29:01','2017-08-25 14:29:01');
INSERT INTO `glpi_locations` VALUES ('39','0','0','UNIDAD SALUDPOL TUMBES','10','OFICINAS DE SEGUROS > UNIDAD SALUDPOL TUMBES',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-08-25 14:29:06','2017-08-25 14:29:06');
INSERT INTO `glpi_locations` VALUES ('40','0','0','UNIDAD SALUDPOL PIURA','10','OFICINAS DE SEGUROS > UNIDAD SALUDPOL PIURA',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-08-25 14:29:11','2017-08-25 14:29:11');
INSERT INTO `glpi_locations` VALUES ('41','0','0','UNIDAD SALUDPOL SAN MARTIN','10','OFICINAS DE SEGUROS > UNIDAD SALUDPOL SAN MARTIN',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-08-25 14:29:15','2017-08-25 14:29:15');
INSERT INTO `glpi_locations` VALUES ('42','0','0','UNIDAD SALUDPOL HUARAZ','10','OFICINAS DE SEGUROS > UNIDAD SALUDPOL HUARAZ',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-08-25 14:29:20','2017-08-25 14:29:20');
INSERT INTO `glpi_locations` VALUES ('43','0','0','UNIDAD SALUDPOL CUSCO','10','OFICINAS DE SEGUROS > UNIDAD SALUDPOL CUSCO',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-08-25 14:29:25','2017-08-25 14:29:25');
INSERT INTO `glpi_locations` VALUES ('44','0','0','UNIDAD SALUDPOL CAJAMARCA','10','OFICINAS DE SEGUROS > UNIDAD SALUDPOL CAJAMARCA',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-08-25 14:29:29','2017-08-25 14:29:29');
INSERT INTO `glpi_locations` VALUES ('45','0','0','UNIDAD SALUDPOL MADRE DE DIOS','10','OFICINAS DE SEGUROS > UNIDAD SALUDPOL MADRE DE DIOS',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-08-25 14:29:33','2017-08-25 14:29:33');
INSERT INTO `glpi_locations` VALUES ('46','0','0','UNIDAD SALUDPOL AMAZONAS','10','OFICINAS DE SEGUROS > UNIDAD SALUDPOL AMAZONAS',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-08-25 14:29:38','2017-08-25 14:29:38');
INSERT INTO `glpi_locations` VALUES ('47','0','0','UNIDAD SALUDPOL AYACUCHO','10','OFICINAS DE SEGUROS > UNIDAD SALUDPOL AYACUCHO',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-08-25 14:29:42','2017-08-25 14:29:42');
INSERT INTO `glpi_locations` VALUES ('48','0','0','UNIDAD SALUDPOL ICA','10','OFICINAS DE SEGUROS > UNIDAD SALUDPOL ICA',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-08-25 14:29:46','2017-08-25 14:29:46');
INSERT INTO `glpi_locations` VALUES ('49','0','0','UNIDAD SALUDPOL LORETO','10','OFICINAS DE SEGUROS > UNIDAD SALUDPOL LORETO',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-08-25 14:29:51','2017-08-25 14:29:51');
INSERT INTO `glpi_locations` VALUES ('50','0','0','UNIDAD SALUDPOL MOQUEGUA','10','OFICINAS DE SEGUROS > UNIDAD SALUDPOL MOQUEGUA',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-08-25 14:29:55','2017-08-25 14:29:55');
INSERT INTO `glpi_locations` VALUES ('51','0','0','UNIDAD SALUDPOL TACNA','10','OFICINAS DE SEGUROS > UNIDAD SALUDPOL TACNA',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-08-25 14:30:00','2017-08-25 14:30:00');
INSERT INTO `glpi_locations` VALUES ('52','0','0','UNIDAD SALUDPOL PUNO','10','OFICINAS DE SEGUROS > UNIDAD SALUDPOL PUNO',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-08-25 14:30:04','2017-08-25 14:30:04');
INSERT INTO `glpi_locations` VALUES ('53','0','0','UNIDAD SALUDPOL AREQUIPA','10','OFICINAS DE SEGUROS > UNIDAD SALUDPOL AREQUIPA',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-08-25 14:30:09','2017-08-25 14:30:09');
INSERT INTO `glpi_locations` VALUES ('54','0','0','UNIDAD SALUDPOL LA LIBERTAD','10','OFICINAS DE SEGUROS > UNIDAD SALUDPOL LA LIBERTAD',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-08-25 14:30:14','2017-08-25 14:30:14');
INSERT INTO `glpi_locations` VALUES ('55','0','0','UNIDAD SALUDPOL APURIMAC','10','OFICINAS DE SEGUROS > UNIDAD SALUDPOL APURIMAC',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-08-25 14:30:18','2017-08-25 14:30:18');
INSERT INTO `glpi_locations` VALUES ('56','0','0','UNIDAD SALUDPOL JUNIN','10','OFICINAS DE SEGUROS > UNIDAD SALUDPOL JUNIN',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-08-25 14:30:23','2017-08-25 14:30:23');
INSERT INTO `glpi_locations` VALUES ('57','0','0','UNIDAD SALUDPOL UCAYALI','10','OFICINAS DE SEGUROS > UNIDAD SALUDPOL UCAYALI',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-08-25 14:30:27','2017-08-25 14:30:27');
INSERT INTO `glpi_locations` VALUES ('58','0','0','UNIDAD SALUDPOL PASCO','10','OFICINAS DE SEGUROS > UNIDAD SALUDPOL PASCO',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-08-25 14:30:33','2017-08-25 14:30:33');
INSERT INTO `glpi_locations` VALUES ('59','0','0','UNIDAD SALUDPOL HUANUCO','10','OFICINAS DE SEGUROS > UNIDAD SALUDPOL HUANUCO',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-08-25 14:30:37','2017-08-25 14:30:37');
INSERT INTO `glpi_locations` VALUES ('60','0','0','UNIDAD SALUDPOL HUANCAVELICA','10','OFICINAS DE SEGUROS > UNIDAD SALUDPOL HUANCAVELICA',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-08-25 14:30:42','2017-08-25 14:30:42');

### Dump table glpi_logs

DROP TABLE IF EXISTS `glpi_logs`;
CREATE TABLE `glpi_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype_link` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `linked_action` int(11) NOT NULL DEFAULT '0' COMMENT 'see define.php HISTORY_* constant',
  `user_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `id_search_option` int(11) NOT NULL DEFAULT '0' COMMENT 'see search.constant.php for value',
  `old_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `new_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `itemtype_link` (`itemtype_link`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_logs` VALUES ('1','User','3','','0','post-only (3)','2017-08-22 17:35:15','15','0','1');
INSERT INTO `glpi_logs` VALUES ('2','UserCategory','1','0','20','glpi (2)','2017-08-22 18:51:26','0','','');
INSERT INTO `glpi_logs` VALUES ('3','User','6','UserEmail','17','glpi (2)','2017-08-22 18:53:51','0','','fmendoza@saludpol.gob.pe (1)');
INSERT INTO `glpi_logs` VALUES ('4','UserEmail','1','0','20','glpi (2)','2017-08-22 18:53:51','0','','');
INSERT INTO `glpi_logs` VALUES ('5','User','6','Profile','17','glpi (2)','2017-08-22 18:53:51','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('6','User','6','0','20','glpi (2)','2017-08-22 18:53:51','0','','');
INSERT INTO `glpi_logs` VALUES ('7','User','6','','0','glpi (2)','2017-08-22 19:40:12','62','2017-08-22 00:00:00','NULL');
INSERT INTO `glpi_logs` VALUES ('8','Document','1','0','20','Mendoza Martel Francisco Jesús (6)','2017-08-22 19:53:30','0','','');
INSERT INTO `glpi_logs` VALUES ('9','Document','1','Ticket','15','Mendoza Martel Francisco Jesús (6)','2017-08-22 19:53:30','0','','Problema con mi pc (1)');
INSERT INTO `glpi_logs` VALUES ('10','Ticket','1','Document','15','Mendoza Martel Francisco Jesús (6)','2017-08-22 19:53:30','0','','Incidente del Documento 1 (1)');
INSERT INTO `glpi_logs` VALUES ('11','Ticket','1','User','15','Mendoza Martel Francisco Jesús (6)','2017-08-22 19:53:30','0','','Mendoza Martel Francisco Jesús (6)');
INSERT INTO `glpi_logs` VALUES ('12','Ticket','1','0','20','Mendoza Martel Francisco Jesús (6)','2017-08-22 19:53:30','0','','');
INSERT INTO `glpi_logs` VALUES ('13','AuthLDAP','1','0','20','glpi (2)','2017-08-22 23:43:30','0','','');
INSERT INTO `glpi_logs` VALUES ('14','AuthLDAP','1','','0','glpi (2)','2017-08-22 23:48:49','30','0','1');
INSERT INTO `glpi_logs` VALUES ('15','AuthLDAP','1','','0','glpi (2)','2017-08-23 00:04:30','5','DC=saludpol,DC=local','CN=Usuarios del dominio,CN=Users,DC=saludpol,DC=local');
INSERT INTO `glpi_logs` VALUES ('16','User','6','0','13','glpi (2)','2017-08-23 00:08:47','0','','');
INSERT INTO `glpi_logs` VALUES ('17','AuthLDAP','1','','0','glpi (2)','2017-08-23 00:17:26','6','(&(objectClass=user)(objectCategory=person)(!(userAccountControl:1.2.840.113556.1.4.803:=2)))','');
INSERT INTO `glpi_logs` VALUES ('18','AuthLDAP','1','','0','glpi (2)','2017-08-23 00:19:29','5','CN=Usuarios del dominio,CN=Users,DC=saludpol,DC=local','OU=SaludPol,DC=saludpol,DC=local');
INSERT INTO `glpi_logs` VALUES ('19','User','7','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('20','User','7','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('21','User','8','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('22','User','8','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('23','User','9','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('24','User','9','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('25','User','10','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('26','User','10','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('27','User','11','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('28','User','11','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('29','User','12','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('30','User','12','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('31','User','13','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('32','User','13','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('33','User','14','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('34','User','14','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('35','User','15','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('36','User','15','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('37','User','16','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('38','User','16','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('39','User','17','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('40','User','17','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('41','User','18','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('42','User','18','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('43','User','19','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('44','User','19','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('45','User','20','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('46','User','20','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('47','User','21','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('48','User','21','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('49','User','22','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('50','User','22','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('51','User','23','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('52','User','23','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('53','User','24','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('54','User','24','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('55','User','25','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('56','User','25','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('57','User','26','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('58','User','26','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('59','User','27','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('60','User','27','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('61','User','28','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('62','User','28','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('63','User','29','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('64','User','29','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('65','User','30','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('66','User','30','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('67','User','31','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('68','User','31','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('69','User','32','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('70','User','32','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('71','User','33','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('72','User','33','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('73','User','34','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('74','User','34','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('75','User','35','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('76','User','35','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('77','User','36','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('78','User','36','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('79','User','37','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('80','User','37','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('81','User','38','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('82','User','38','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('83','User','39','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('84','User','39','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('85','User','40','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('86','User','40','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('87','User','41','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('88','User','41','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('89','User','42','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('90','User','42','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('91','User','43','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('92','User','43','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('93','User','44','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('94','User','44','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('95','User','45','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('96','User','45','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('97','User','46','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('98','User','46','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('99','User','47','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('100','User','47','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('101','User','48','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('102','User','48','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('103','User','49','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('104','User','49','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('105','User','50','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('106','User','50','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('107','User','51','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('108','User','51','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('109','User','52','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('110','User','52','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('111','User','53','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('112','User','53','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('113','User','54','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('114','User','54','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('115','User','55','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('116','User','55','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('117','User','56','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('118','User','56','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('119','User','57','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('120','User','57','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('121','User','58','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('122','User','58','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('123','User','59','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('124','User','59','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('125','User','60','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('126','User','60','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('127','User','61','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('128','User','61','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('129','User','62','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('130','User','62','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('131','User','63','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('132','User','63','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('133','User','64','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('134','User','64','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('135','User','65','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('136','User','65','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('137','User','66','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('138','User','66','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('139','User','67','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('140','User','67','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('141','User','68','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('142','User','68','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('143','User','69','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('144','User','69','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('145','User','70','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('146','User','70','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('147','User','71','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('148','User','71','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('149','User','72','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('150','User','72','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('151','User','73','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('152','User','73','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('153','User','74','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('154','User','74','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('155','User','75','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('156','User','75','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('157','User','76','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('158','User','76','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('159','User','77','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('160','User','77','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('161','User','78','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('162','User','78','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('163','User','79','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('164','User','79','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('165','User','80','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('166','User','80','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('167','User','81','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('168','User','81','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('169','User','82','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('170','User','82','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('171','User','83','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('172','User','83','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('173','User','84','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('174','User','84','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('175','User','85','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('176','User','85','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('177','User','86','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('178','User','86','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('179','User','87','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('180','User','87','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('181','User','88','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('182','User','88','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('183','User','89','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('184','User','89','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('185','User','90','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('186','User','90','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('187','User','91','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('188','User','91','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('189','User','92','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('190','User','92','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('191','User','93','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('192','User','93','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('193','User','94','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('194','User','94','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('195','User','95','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('196','User','95','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('197','User','96','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('198','User','96','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('199','User','97','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('200','User','97','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('201','User','98','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('202','User','98','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('203','User','99','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('204','User','99','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('205','User','100','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('206','User','100','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('207','User','101','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('208','User','101','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('209','User','102','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('210','User','102','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('211','User','103','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('212','User','103','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('213','User','104','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('214','User','104','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('215','User','105','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('216','User','105','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('217','User','106','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('218','User','106','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('219','User','107','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('220','User','107','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('221','User','108','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('222','User','108','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('223','User','109','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('224','User','109','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('225','User','110','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('226','User','110','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('227','User','111','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('228','User','111','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('229','User','112','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('230','User','112','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('231','User','113','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('232','User','113','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('233','User','114','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('234','User','114','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('235','User','115','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('236','User','115','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('237','User','116','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('238','User','116','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('239','User','117','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('240','User','117','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('241','User','118','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('242','User','118','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('243','User','119','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('244','User','119','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('245','User','120','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('246','User','120','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('247','User','121','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('248','User','121','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('249','User','122','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('250','User','122','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('251','User','123','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('252','User','123','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('253','User','124','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('254','User','124','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('255','User','125','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('256','User','125','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('257','User','126','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('258','User','126','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('259','User','127','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('260','User','127','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('261','User','128','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('262','User','128','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('263','User','129','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('264','User','129','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('265','User','130','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('266','User','130','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('267','User','131','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('268','User','131','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('269','User','132','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('270','User','132','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('271','User','133','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('272','User','133','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('273','User','134','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('274','User','134','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('275','User','135','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('276','User','135','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('277','User','136','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('278','User','136','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('279','User','137','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('280','User','137','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('281','User','138','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('282','User','138','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('283','User','139','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('284','User','139','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('285','User','140','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('286','User','140','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('287','User','141','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('288','User','141','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('289','User','142','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('290','User','142','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('291','User','143','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('292','User','143','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('293','User','144','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('294','User','144','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('295','User','145','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('296','User','145','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('297','User','146','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('298','User','146','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('299','User','147','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('300','User','147','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('301','User','148','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('302','User','148','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('303','User','149','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('304','User','149','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('305','User','150','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('306','User','150','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('307','User','151','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('308','User','151','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('309','User','152','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('310','User','152','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('311','User','153','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('312','User','153','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('313','User','154','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('314','User','154','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('315','User','155','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('316','User','155','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('317','User','156','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('318','User','156','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('319','User','157','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('320','User','157','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('321','User','158','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('322','User','158','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('323','User','159','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('324','User','159','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('325','User','160','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('326','User','160','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('327','User','161','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('328','User','161','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('329','User','162','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('330','User','162','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('331','User','163','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('332','User','163','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('333','User','164','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('334','User','164','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('335','User','165','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('336','User','165','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('337','User','166','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('338','User','166','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('339','User','167','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('340','User','167','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('341','User','168','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('342','User','168','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('343','User','169','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('344','User','169','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('345','User','170','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('346','User','170','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('347','User','171','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('348','User','171','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('349','User','172','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('350','User','172','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('351','User','173','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('352','User','173','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('353','User','174','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('354','User','174','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('355','User','175','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('356','User','175','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('357','User','176','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('358','User','176','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('359','User','177','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('360','User','177','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('361','User','178','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('362','User','178','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('363','User','179','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('364','User','179','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('365','User','180','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('366','User','180','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('367','User','181','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('368','User','181','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('369','User','182','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('370','User','182','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('371','User','183','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('372','User','183','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('373','User','184','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('374','User','184','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('375','User','185','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('376','User','185','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('377','User','186','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('378','User','186','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('379','User','187','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('380','User','187','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('381','User','188','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('382','User','188','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('383','User','189','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('384','User','189','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('385','User','190','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('386','User','190','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('387','User','191','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('388','User','191','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('389','User','192','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('390','User','192','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('391','User','193','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('392','User','193','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('393','User','194','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('394','User','194','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('395','User','195','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('396','User','195','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('397','User','196','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('398','User','196','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('399','User','197','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('400','User','197','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('401','User','198','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('402','User','198','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('403','User','199','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('404','User','199','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('405','User','200','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('406','User','200','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('407','User','201','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('408','User','201','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('409','User','202','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('410','User','202','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('411','User','203','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('412','User','203','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('413','User','204','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('414','User','204','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('415','User','205','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('416','User','205','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('417','User','206','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('418','User','206','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('419','User','207','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('420','User','207','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('421','User','208','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('422','User','208','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('423','User','209','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('424','User','209','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('425','User','210','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('426','User','210','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('427','User','211','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('428','User','211','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('429','User','212','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('430','User','212','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('431','User','213','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('432','User','213','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('433','User','214','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('434','User','214','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('435','User','215','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('436','User','215','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('437','User','216','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('438','User','216','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('439','User','217','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('440','User','217','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('441','User','218','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('442','User','218','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('443','User','219','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('444','User','219','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('445','User','220','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('446','User','220','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('447','User','221','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('448','User','221','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('449','User','222','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('450','User','222','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('451','User','223','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('452','User','223','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('453','User','224','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('454','User','224','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('455','User','225','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('456','User','225','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('457','User','226','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('458','User','226','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('459','User','227','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('460','User','227','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('461','User','228','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('462','User','228','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('463','User','229','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('464','User','229','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('465','User','230','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('466','User','230','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('467','User','231','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('468','User','231','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('469','User','232','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('470','User','232','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('471','User','233','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('472','User','233','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('473','User','234','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('474','User','234','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('475','User','235','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('476','User','235','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('477','User','236','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('478','User','236','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('479','User','237','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('480','User','237','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('481','User','238','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('482','User','238','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('483','User','239','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('484','User','239','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('485','User','240','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('486','User','240','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('487','User','241','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('488','User','241','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('489','User','242','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('490','User','242','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('491','User','243','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('492','User','243','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('493','User','244','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('494','User','244','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('495','User','245','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('496','User','245','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('497','User','246','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('498','User','246','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('499','User','247','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('500','User','247','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('501','User','248','Profile','17','glpi (2)','2017-08-23 00:25:01','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('502','User','248','0','20','glpi (2)','2017-08-23 00:25:01','0','','');
INSERT INTO `glpi_logs` VALUES ('504','Group','2','0','20','glpi (2)','2017-08-23 00:32:09','0','','');
INSERT INTO `glpi_logs` VALUES ('505','Group','3','0','20','glpi (2)','2017-08-23 00:32:09','0','','');
INSERT INTO `glpi_logs` VALUES ('506','Group','4','0','20','glpi (2)','2017-08-23 00:32:09','0','','');
INSERT INTO `glpi_logs` VALUES ('507','Group','5','0','20','glpi (2)','2017-08-23 00:32:09','0','','');
INSERT INTO `glpi_logs` VALUES ('508','Group','6','0','20','glpi (2)','2017-08-23 00:32:09','0','','');
INSERT INTO `glpi_logs` VALUES ('2759','Group','40','User','15','Administrador Administrador (438)','2017-08-24 12:01:36','0','','Escalera Requejo Luis (177)');
INSERT INTO `glpi_logs` VALUES ('510','Group','8','0','20','glpi (2)','2017-08-23 00:32:09','0','','');
INSERT INTO `glpi_logs` VALUES ('511','Group','9','0','20','glpi (2)','2017-08-23 00:32:09','0','','');
INSERT INTO `glpi_logs` VALUES ('512','Group','10','0','20','glpi (2)','2017-08-23 00:32:09','0','','');
INSERT INTO `glpi_logs` VALUES ('513','Group','11','0','20','glpi (2)','2017-08-23 00:32:09','0','','');
INSERT INTO `glpi_logs` VALUES ('514','Group','12','0','20','glpi (2)','2017-08-23 00:32:09','0','','');
INSERT INTO `glpi_logs` VALUES ('515','Group','13','0','20','glpi (2)','2017-08-23 00:32:09','0','','');
INSERT INTO `glpi_logs` VALUES ('518','Group','16','0','20','glpi (2)','2017-08-23 00:32:09','0','','');
INSERT INTO `glpi_logs` VALUES ('519','Group','17','0','20','glpi (2)','2017-08-23 00:32:09','0','','');
INSERT INTO `glpi_logs` VALUES ('2758','User','177','Group','15','Administrador Administrador (438)','2017-08-24 12:01:36','0','','Soporte Técnico (40)');
INSERT INTO `glpi_logs` VALUES ('522','Group','20','0','20','glpi (2)','2017-08-23 00:32:09','0','','');
INSERT INTO `glpi_logs` VALUES ('523','Group','21','0','20','glpi (2)','2017-08-23 00:32:09','0','','');
INSERT INTO `glpi_logs` VALUES ('2757','User','2','0','13','Administrador Administrador (438)','2017-08-24 12:00:43','0','','');
INSERT INTO `glpi_logs` VALUES ('526','Group','24','0','20','glpi (2)','2017-08-23 00:32:09','0','','');
INSERT INTO `glpi_logs` VALUES ('527','Group','25','0','20','glpi (2)','2017-08-23 00:32:09','0','','');
INSERT INTO `glpi_logs` VALUES ('528','Group','26','0','20','glpi (2)','2017-08-23 00:32:09','0','','');
INSERT INTO `glpi_logs` VALUES ('529','Group','27','0','20','glpi (2)','2017-08-23 00:32:09','0','','');
INSERT INTO `glpi_logs` VALUES ('530','Group','28','0','20','glpi (2)','2017-08-23 00:32:09','0','','');
INSERT INTO `glpi_logs` VALUES ('531','Group','29','0','20','glpi (2)','2017-08-23 00:32:09','0','','');
INSERT INTO `glpi_logs` VALUES ('532','Group','30','0','20','glpi (2)','2017-08-23 00:32:09','0','','');
INSERT INTO `glpi_logs` VALUES ('533','Group','31','0','20','glpi (2)','2017-08-23 00:32:09','0','','');
INSERT INTO `glpi_logs` VALUES ('534','Group','32','0','20','glpi (2)','2017-08-23 00:32:09','0','','');
INSERT INTO `glpi_logs` VALUES ('535','Group','33','0','20','glpi (2)','2017-08-23 00:32:09','0','','');
INSERT INTO `glpi_logs` VALUES ('536','Group','34','0','20','glpi (2)','2017-08-23 00:32:09','0','','');
INSERT INTO `glpi_logs` VALUES ('537','Group','35','0','20','glpi (2)','2017-08-23 00:32:09','0','','');
INSERT INTO `glpi_logs` VALUES ('538','Group','36','0','20','glpi (2)','2017-08-23 00:32:09','0','','');
INSERT INTO `glpi_logs` VALUES ('539','Group','37','0','20','glpi (2)','2017-08-23 00:32:09','0','','');
INSERT INTO `glpi_logs` VALUES ('540','Group','38','0','20','glpi (2)','2017-08-23 00:32:09','0','','');
INSERT INTO `glpi_logs` VALUES ('2756','User','438','','0','glpi (2)','2017-08-24 11:59:31','20','&nbsp; (0)','Super-Admin (4)');
INSERT INTO `glpi_logs` VALUES ('542','User','249','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('543','User','249','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('544','User','250','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('545','User','250','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('546','User','251','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('547','User','251','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('548','User','252','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('549','User','252','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('550','User','253','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('551','User','253','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('552','User','254','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('553','User','254','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('554','User','255','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('555','User','255','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('556','User','256','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('557','User','256','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('558','User','257','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('559','User','257','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('560','User','258','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('561','User','258','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('562','User','259','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('563','User','259','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('564','User','260','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('565','User','260','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('566','User','261','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('567','User','261','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('568','User','262','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('569','User','262','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('570','User','263','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('571','User','263','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('572','User','264','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('573','User','264','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('574','User','265','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('575','User','265','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('576','User','266','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('577','User','266','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('578','User','267','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('579','User','267','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('580','User','268','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('581','User','268','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('582','User','269','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('583','User','269','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('584','User','270','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('585','User','270','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('586','User','271','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('587','User','271','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('588','User','272','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('589','User','272','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('590','User','273','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('591','User','273','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('592','User','274','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('593','User','274','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('594','User','275','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('595','User','275','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('596','User','276','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('597','User','276','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('598','User','277','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('599','User','277','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('600','User','278','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('601','User','278','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('602','User','279','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('603','User','279','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('604','User','280','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('605','User','280','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('606','User','281','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('607','User','281','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('608','User','282','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('609','User','282','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('610','User','283','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('611','User','283','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('612','User','284','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('613','User','284','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('614','User','285','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('615','User','285','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('616','User','286','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('617','User','286','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('618','User','287','Group','15','glpi (2)','2017-08-23 00:34:55','0','','sp_eq_fun_adm_g (36)');
INSERT INTO `glpi_logs` VALUES ('619','Group','36','User','15','glpi (2)','2017-08-23 00:34:55','0','','Castillo Altez Elizabeth (287)');
INSERT INTO `glpi_logs` VALUES ('620','User','287','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('621','User','287','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('622','User','288','Group','15','glpi (2)','2017-08-23 00:34:55','0','','efrh_assist_control_g (20)');
INSERT INTO `glpi_logs` VALUES ('623','Group','20','User','15','glpi (2)','2017-08-23 00:34:55','0','','Burga Vasquez Edward Renan (288)');
INSERT INTO `glpi_logs` VALUES ('624','User','288','Group','15','glpi (2)','2017-08-23 00:34:55','0','','efrh_g (21)');
INSERT INTO `glpi_logs` VALUES ('625','Group','21','User','15','glpi (2)','2017-08-23 00:34:55','0','','Burga Vasquez Edward Renan (288)');
INSERT INTO `glpi_logs` VALUES ('626','User','288','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('627','User','288','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('628','User','289','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('629','User','289','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('630','User','290','Group','15','glpi (2)','2017-08-23 00:34:55','0','','contabilidad_g (4)');
INSERT INTO `glpi_logs` VALUES ('631','Group','4','User','15','glpi (2)','2017-08-23 00:34:55','0','','Atoche Ernesto (290)');
INSERT INTO `glpi_logs` VALUES ('632','User','290','Group','15','glpi (2)','2017-08-23 00:34:55','0','','sp_of_eco_con_g (38)');
INSERT INTO `glpi_logs` VALUES ('633','Group','38','User','15','glpi (2)','2017-08-23 00:34:55','0','','Atoche Ernesto (290)');
INSERT INTO `glpi_logs` VALUES ('634','User','290','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('635','User','290','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('636','User','291','Group','15','glpi (2)','2017-08-23 00:34:55','0','','eff_g (16)');
INSERT INTO `glpi_logs` VALUES ('637','Group','16','User','15','glpi (2)','2017-08-23 00:34:55','0','','Zavala Curzo David Fernando (291)');
INSERT INTO `glpi_logs` VALUES ('638','User','291','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('639','User','291','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('640','User','292','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('641','User','292','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('642','User','293','Group','15','glpi (2)','2017-08-23 00:34:55','0','','efrh_assist_control_g (20)');
INSERT INTO `glpi_logs` VALUES ('643','Group','20','User','15','glpi (2)','2017-08-23 00:34:55','0','','Tomasto Acuña Dina (293)');
INSERT INTO `glpi_logs` VALUES ('644','User','293','Group','15','glpi (2)','2017-08-23 00:34:55','0','','efrh_g (21)');
INSERT INTO `glpi_logs` VALUES ('645','Group','21','User','15','glpi (2)','2017-08-23 00:34:55','0','','Tomasto Acuña Dina (293)');
INSERT INTO `glpi_logs` VALUES ('646','User','293','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('647','User','293','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('648','User','294','Group','15','glpi (2)','2017-08-23 00:34:55','0','','almacen_central_g (3)');
INSERT INTO `glpi_logs` VALUES ('649','Group','3','User','15','glpi (2)','2017-08-23 00:34:55','0','','Marcas Rumay David (294)');
INSERT INTO `glpi_logs` VALUES ('650','User','294','Group','15','glpi (2)','2017-08-23 00:34:55','0','','logistic16_p (28)');
INSERT INTO `glpi_logs` VALUES ('651','Group','28','User','15','glpi (2)','2017-08-23 00:34:55','0','','Marcas Rumay David (294)');
INSERT INTO `glpi_logs` VALUES ('652','User','294','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('653','User','294','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('654','User','295','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('655','User','295','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('656','User','296','Group','15','glpi (2)','2017-08-23 00:34:55','0','','coordinaciones_gg (6)');
INSERT INTO `glpi_logs` VALUES ('657','Group','6','User','15','glpi (2)','2017-08-23 00:34:55','0','','Fuentes Lozano Deny Marilu (296)');
INSERT INTO `glpi_logs` VALUES ('658','User','296','Group','15','glpi (2)','2017-08-23 00:34:55','0','','gg_of_seguros (26)');
INSERT INTO `glpi_logs` VALUES ('659','Group','26','User','15','glpi (2)','2017-08-23 00:34:55','0','','Fuentes Lozano Deny Marilu (296)');
INSERT INTO `glpi_logs` VALUES ('660','User','296','Group','15','glpi (2)','2017-08-23 00:34:55','0','','secretarias_sp (34)');
INSERT INTO `glpi_logs` VALUES ('661','Group','34','User','15','glpi (2)','2017-08-23 00:34:55','0','','Fuentes Lozano Deny Marilu (296)');
INSERT INTO `glpi_logs` VALUES ('662','User','296','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('663','User','296','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('664','User','297','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('665','User','297','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('666','User','298','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('667','User','298','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('668','User','299','Group','15','glpi (2)','2017-08-23 00:34:55','0','','logistic16_p (28)');
INSERT INTO `glpi_logs` VALUES ('669','Group','28','User','15','glpi (2)','2017-08-23 00:34:55','0','','Yamunaque Cruz William (299)');
INSERT INTO `glpi_logs` VALUES ('670','User','299','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('671','User','299','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('672','User','300','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('673','User','300','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('674','User','301','Group','15','glpi (2)','2017-08-23 00:34:55','0','','coordinaciones_gg (6)');
INSERT INTO `glpi_logs` VALUES ('675','Group','6','User','15','glpi (2)','2017-08-23 00:34:55','0','','Chacaliaza Huaman Delia (301)');
INSERT INTO `glpi_logs` VALUES ('676','User','301','Group','15','glpi (2)','2017-08-23 00:34:55','0','','secretarias_sp (34)');
INSERT INTO `glpi_logs` VALUES ('677','Group','34','User','15','glpi (2)','2017-08-23 00:34:55','0','','Chacaliaza Huaman Delia (301)');
INSERT INTO `glpi_logs` VALUES ('678','User','301','Group','15','glpi (2)','2017-08-23 00:34:55','0','','sp_eq_fun_adm_g (36)');
INSERT INTO `glpi_logs` VALUES ('679','Group','36','User','15','glpi (2)','2017-08-23 00:34:55','0','','Chacaliaza Huaman Delia (301)');
INSERT INTO `glpi_logs` VALUES ('680','User','301','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('681','User','301','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('682','User','302','Group','15','glpi (2)','2017-08-23 00:34:55','0','','control_previo_g (5)');
INSERT INTO `glpi_logs` VALUES ('683','Group','5','User','15','glpi (2)','2017-08-23 00:34:55','0','','Bonifacio Nolasco Delis Yolanda (302)');
INSERT INTO `glpi_logs` VALUES ('684','User','302','Group','15','glpi (2)','2017-08-23 00:34:55','0','','sp_of_eco_con_g (38)');
INSERT INTO `glpi_logs` VALUES ('685','Group','38','User','15','glpi (2)','2017-08-23 00:34:55','0','','Bonifacio Nolasco Delis Yolanda (302)');
INSERT INTO `glpi_logs` VALUES ('686','User','302','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('687','User','302','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('688','User','303','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('689','User','303','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('690','User','304','Group','15','glpi (2)','2017-08-23 00:34:55','0','','control_previo_g (5)');
INSERT INTO `glpi_logs` VALUES ('691','Group','5','User','15','glpi (2)','2017-08-23 00:34:55','0','','Trinidad Huaranga Cinthia Sandra (304)');
INSERT INTO `glpi_logs` VALUES ('692','User','304','Group','15','glpi (2)','2017-08-23 00:34:55','0','','sp_of_eco_con_g (38)');
INSERT INTO `glpi_logs` VALUES ('693','Group','38','User','15','glpi (2)','2017-08-23 00:34:55','0','','Trinidad Huaranga Cinthia Sandra (304)');
INSERT INTO `glpi_logs` VALUES ('694','User','304','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('695','User','304','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('696','User','305','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('697','User','305','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('698','User','306','Group','15','glpi (2)','2017-08-23 00:34:55','0','','sp_eq_fun_adm_g (36)');
INSERT INTO `glpi_logs` VALUES ('699','Group','36','User','15','glpi (2)','2017-08-23 00:34:55','0','','Tello Samillan Cesar (306)');
INSERT INTO `glpi_logs` VALUES ('700','User','306','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('701','User','306','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('702','User','307','Group','15','glpi (2)','2017-08-23 00:34:55','0','','gg_g (25)');
INSERT INTO `glpi_logs` VALUES ('703','Group','25','User','15','glpi (2)','2017-08-23 00:34:55','0','','Solar Fulchi Carmen (307)');
INSERT INTO `glpi_logs` VALUES ('704','User','307','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('705','User','307','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('706','User','308','Group','15','glpi (2)','2017-08-23 00:34:55','0','','procesos_g (31)');
INSERT INTO `glpi_logs` VALUES ('707','Group','31','User','15','glpi (2)','2017-08-23 00:34:55','0','','Sanchez Pilares Cesar (308)');
INSERT INTO `glpi_logs` VALUES ('708','User','308','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('709','User','308','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('710','User','309','Group','15','glpi (2)','2017-08-23 00:34:55','0','','sp_eq_fun_adm_g (36)');
INSERT INTO `glpi_logs` VALUES ('711','Group','36','User','15','glpi (2)','2017-08-23 00:34:55','0','','Saldaña Zevallos Carlos (309)');
INSERT INTO `glpi_logs` VALUES ('712','User','309','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('713','User','309','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('714','User','310','Group','15','glpi (2)','2017-08-23 00:34:55','0','','gg_of_seguros (26)');
INSERT INTO `glpi_logs` VALUES ('715','Group','26','User','15','glpi (2)','2017-08-23 00:34:55','0','','Rodriguez Cervantes Carlos Hernando (310)');
INSERT INTO `glpi_logs` VALUES ('716','User','310','Group','15','glpi (2)','2017-08-23 00:34:55','0','','responsables_sp (33)');
INSERT INTO `glpi_logs` VALUES ('717','Group','33','User','15','glpi (2)','2017-08-23 00:34:55','0','','Rodriguez Cervantes Carlos Hernando (310)');
INSERT INTO `glpi_logs` VALUES ('718','User','310','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('719','User','310','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('720','User','311','Group','15','glpi (2)','2017-08-23 00:34:55','0','','efrh_g (21)');
INSERT INTO `glpi_logs` VALUES ('721','Group','21','User','15','glpi (2)','2017-08-23 00:34:55','0','','Quispe Cotrina Cesia Jemina (311)');
INSERT INTO `glpi_logs` VALUES ('722','User','311','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('723','User','311','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('724','User','312','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('725','User','312','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('726','User','313','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('727','User','313','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('728','User','314','Group','15','glpi (2)','2017-08-23 00:34:55','0','','logistic16_p (28)');
INSERT INTO `glpi_logs` VALUES ('729','Group','28','User','15','glpi (2)','2017-08-23 00:34:55','0','','Sabrera Porras Rolando (314)');
INSERT INTO `glpi_logs` VALUES ('730','User','314','Group','15','glpi (2)','2017-08-23 00:34:55','0','','programacion_g (32)');
INSERT INTO `glpi_logs` VALUES ('731','Group','32','User','15','glpi (2)','2017-08-23 00:34:55','0','','Sabrera Porras Rolando (314)');
INSERT INTO `glpi_logs` VALUES ('732','User','314','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('733','User','314','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('734','User','315','Group','15','glpi (2)','2017-08-23 00:34:55','0','','logistic16_p (28)');
INSERT INTO `glpi_logs` VALUES ('735','Group','28','User','15','glpi (2)','2017-08-23 00:34:55','0','','Vegas Carbonel Ernesto (315)');
INSERT INTO `glpi_logs` VALUES ('736','User','315','Group','15','glpi (2)','2017-08-23 00:34:55','0','','programacion_g (32)');
INSERT INTO `glpi_logs` VALUES ('737','Group','32','User','15','glpi (2)','2017-08-23 00:34:55','0','','Vegas Carbonel Ernesto (315)');
INSERT INTO `glpi_logs` VALUES ('738','User','315','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('739','User','315','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('740','User','316','Group','15','glpi (2)','2017-08-23 00:34:55','0','','servicios_generales_g (35)');
INSERT INTO `glpi_logs` VALUES ('741','Group','35','User','15','glpi (2)','2017-08-23 00:34:55','0','','Del Rio Campbell Miriam (316)');
INSERT INTO `glpi_logs` VALUES ('742','User','316','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('743','User','316','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('744','User','317','Group','15','glpi (2)','2017-08-23 00:34:55','0','','ejecucion_contractual_g (24)');
INSERT INTO `glpi_logs` VALUES ('745','Group','24','User','15','glpi (2)','2017-08-23 00:34:55','0','','Pinedo Rojas Yasmin (317)');
INSERT INTO `glpi_logs` VALUES ('746','User','317','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('747','User','317','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('748','User','318','Group','15','glpi (2)','2017-08-23 00:34:55','0','','procesos_g (31)');
INSERT INTO `glpi_logs` VALUES ('749','Group','31','User','15','glpi (2)','2017-08-23 00:34:55','0','','Saenz Palomino Fernando (318)');
INSERT INTO `glpi_logs` VALUES ('750','User','318','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('751','User','318','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('752','User','319','Group','15','glpi (2)','2017-08-23 00:34:55','0','','actos_preparatorios_procedimiento_seleccion_g (2)');
INSERT INTO `glpi_logs` VALUES ('753','Group','2','User','15','glpi (2)','2017-08-23 00:34:55','0','','Bottoni Varillas Giovana (319)');
INSERT INTO `glpi_logs` VALUES ('754','User','319','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('755','User','319','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('756','User','320','Group','15','glpi (2)','2017-08-23 00:34:55','0','','control_previo_g (5)');
INSERT INTO `glpi_logs` VALUES ('757','Group','5','User','15','glpi (2)','2017-08-23 00:34:55','0','','Siancas La Rosa Anne (320)');
INSERT INTO `glpi_logs` VALUES ('758','User','320','Group','15','glpi (2)','2017-08-23 00:34:55','0','','sp_of_eco_con_g (38)');
INSERT INTO `glpi_logs` VALUES ('759','Group','38','User','15','glpi (2)','2017-08-23 00:34:55','0','','Siancas La Rosa Anne (320)');
INSERT INTO `glpi_logs` VALUES ('760','User','320','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('761','User','320','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('762','User','321','Group','15','glpi (2)','2017-08-23 00:34:55','0','','control_previo_g (5)');
INSERT INTO `glpi_logs` VALUES ('763','Group','5','User','15','glpi (2)','2017-08-23 00:34:55','0','','De Amat Perez Yanet (321)');
INSERT INTO `glpi_logs` VALUES ('764','User','321','Group','15','glpi (2)','2017-08-23 00:34:55','0','','sp_of_eco_con_g (38)');
INSERT INTO `glpi_logs` VALUES ('765','Group','38','User','15','glpi (2)','2017-08-23 00:34:55','0','','De Amat Perez Yanet (321)');
INSERT INTO `glpi_logs` VALUES ('766','User','321','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('767','User','321','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('768','User','322','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('769','User','322','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('770','User','323','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('771','User','323','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('772','User','324','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('773','User','324','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('774','User','325','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('775','User','325','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('776','User','326','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('777','User','326','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('778','User','327','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('779','User','327','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('780','User','328','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('781','User','328','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('782','User','329','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('783','User','329','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('784','User','330','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('785','User','330','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('786','User','331','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('787','User','331','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('788','User','332','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('789','User','332','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('790','User','333','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('791','User','333','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('792','User','334','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('793','User','334','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('794','User','335','Group','15','glpi (2)','2017-08-23 00:34:55','0','','control_previo_g (5)');
INSERT INTO `glpi_logs` VALUES ('795','Group','5','User','15','glpi (2)','2017-08-23 00:34:55','0','','Mogollon Pasapera Eleodora (335)');
INSERT INTO `glpi_logs` VALUES ('796','User','335','Group','15','glpi (2)','2017-08-23 00:34:55','0','','sp_of_eco_con_g (38)');
INSERT INTO `glpi_logs` VALUES ('797','Group','38','User','15','glpi (2)','2017-08-23 00:34:55','0','','Mogollon Pasapera Eleodora (335)');
INSERT INTO `glpi_logs` VALUES ('798','User','335','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('799','User','335','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('800','User','336','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('801','User','336','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('802','User','337','Group','15','glpi (2)','2017-08-23 00:34:55','0','','efcp_of_con_pre_g (12)');
INSERT INTO `glpi_logs` VALUES ('803','Group','12','User','15','glpi (2)','2017-08-23 00:34:55','0','','Puyen Mendoza Cecilia (337)');
INSERT INTO `glpi_logs` VALUES ('804','User','337','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('805','User','337','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('806','User','338','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('807','User','338','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('808','User','339','Group','15','glpi (2)','2017-08-23 00:34:55','0','','efcp_of_con_pre_g (12)');
INSERT INTO `glpi_logs` VALUES ('809','Group','12','User','15','glpi (2)','2017-08-23 00:34:55','0','','Pajuelo Koky Freddy (339)');
INSERT INTO `glpi_logs` VALUES ('810','User','339','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('811','User','339','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('812','User','340','Group','15','glpi (2)','2017-08-23 00:34:55','0','','efcp_of_con_pre_g (12)');
INSERT INTO `glpi_logs` VALUES ('813','Group','12','User','15','glpi (2)','2017-08-23 00:34:55','0','','Ramirez Retamozo Giancarlo (340)');
INSERT INTO `glpi_logs` VALUES ('814','User','340','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('815','User','340','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('816','User','341','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('817','User','341','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('818','User','342','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('819','User','342','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('820','User','343','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('821','User','343','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('822','User','344','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('823','User','344','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('824','User','345','Group','15','glpi (2)','2017-08-23 00:34:55','0','','efrh_assist_control_g (20)');
INSERT INTO `glpi_logs` VALUES ('825','Group','20','User','15','glpi (2)','2017-08-23 00:34:55','0','','Linares Arcela Carlos (345)');
INSERT INTO `glpi_logs` VALUES ('826','User','345','Group','15','glpi (2)','2017-08-23 00:34:55','0','','efrh_g (21)');
INSERT INTO `glpi_logs` VALUES ('827','Group','21','User','15','glpi (2)','2017-08-23 00:34:55','0','','Linares Arcela Carlos (345)');
INSERT INTO `glpi_logs` VALUES ('828','User','345','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('829','User','345','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('830','User','346','Group','15','glpi (2)','2017-08-23 00:34:55','0','','almacen_central_g (3)');
INSERT INTO `glpi_logs` VALUES ('831','Group','3','User','15','glpi (2)','2017-08-23 00:34:55','0','','Huaman Tito Cinthya (346)');
INSERT INTO `glpi_logs` VALUES ('832','User','346','Group','15','glpi (2)','2017-08-23 00:34:55','0','','logistic16_p (28)');
INSERT INTO `glpi_logs` VALUES ('833','Group','28','User','15','glpi (2)','2017-08-23 00:34:55','0','','Huaman Tito Cinthya (346)');
INSERT INTO `glpi_logs` VALUES ('834','User','346','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('835','User','346','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('836','User','347','Group','15','glpi (2)','2017-08-23 00:34:55','0','','efcp_of_aud_med_g (11)');
INSERT INTO `glpi_logs` VALUES ('837','Group','11','User','15','glpi (2)','2017-08-23 00:34:55','0','','Chavez Castaneda Carla Ines (347)');
INSERT INTO `glpi_logs` VALUES ('838','User','347','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('839','User','347','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('840','User','348','Group','15','glpi (2)','2017-08-23 00:34:55','0','','gg_g (25)');
INSERT INTO `glpi_logs` VALUES ('841','Group','25','User','15','glpi (2)','2017-08-23 00:34:55','0','','Cardenas Manrique Christian Edo (348)');
INSERT INTO `glpi_logs` VALUES ('842','User','348','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('843','User','348','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('844','User','349','Group','15','glpi (2)','2017-08-23 00:34:55','0','','almacen_central_g (3)');
INSERT INTO `glpi_logs` VALUES ('845','Group','3','User','15','glpi (2)','2017-08-23 00:34:55','0','','Barreto Terrones Carmen (349)');
INSERT INTO `glpi_logs` VALUES ('846','User','349','Group','15','glpi (2)','2017-08-23 00:34:55','0','','logistic16_p (28)');
INSERT INTO `glpi_logs` VALUES ('847','Group','28','User','15','glpi (2)','2017-08-23 00:34:55','0','','Barreto Terrones Carmen (349)');
INSERT INTO `glpi_logs` VALUES ('848','User','349','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('849','User','349','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('850','User','350','Group','15','glpi (2)','2017-08-23 00:34:55','0','','control_previo_g (5)');
INSERT INTO `glpi_logs` VALUES ('851','Group','5','User','15','glpi (2)','2017-08-23 00:34:55','0','','Aparicio Ames Cesar Augusto (350)');
INSERT INTO `glpi_logs` VALUES ('852','User','350','Group','15','glpi (2)','2017-08-23 00:34:55','0','','sp_of_eco_con_g (38)');
INSERT INTO `glpi_logs` VALUES ('853','Group','38','User','15','glpi (2)','2017-08-23 00:34:55','0','','Aparicio Ames Cesar Augusto (350)');
INSERT INTO `glpi_logs` VALUES ('854','User','350','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('855','User','350','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('856','User','351','Group','15','glpi (2)','2017-08-23 00:34:55','0','','coordinaciones_gg (6)');
INSERT INTO `glpi_logs` VALUES ('857','Group','6','User','15','glpi (2)','2017-08-23 00:34:55','0','','Alvarez Ramos Carmela (351)');
INSERT INTO `glpi_logs` VALUES ('858','User','351','Group','15','glpi (2)','2017-08-23 00:34:55','0','','responsables_sp (33)');
INSERT INTO `glpi_logs` VALUES ('859','Group','33','User','15','glpi (2)','2017-08-23 00:34:55','0','','Alvarez Ramos Carmela (351)');
INSERT INTO `glpi_logs` VALUES ('860','User','351','Group','15','glpi (2)','2017-08-23 00:34:55','0','','sp_eq_fun_adm_g (36)');
INSERT INTO `glpi_logs` VALUES ('861','Group','36','User','15','glpi (2)','2017-08-23 00:34:55','0','','Alvarez Ramos Carmela (351)');
INSERT INTO `glpi_logs` VALUES ('862','User','351','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('863','User','351','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('864','User','352','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('865','User','352','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('866','User','353','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('867','User','353','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('868','User','354','Group','15','glpi (2)','2017-08-23 00:34:55','0','','efrh_assist_control_g (20)');
INSERT INTO `glpi_logs` VALUES ('869','Group','20','User','15','glpi (2)','2017-08-23 00:34:55','0','','Huaman Barrueta Beatriz E. (354)');
INSERT INTO `glpi_logs` VALUES ('870','User','354','Group','15','glpi (2)','2017-08-23 00:34:55','0','','efrh_g (21)');
INSERT INTO `glpi_logs` VALUES ('871','Group','21','User','15','glpi (2)','2017-08-23 00:34:55','0','','Huaman Barrueta Beatriz E. (354)');
INSERT INTO `glpi_logs` VALUES ('872','User','354','Group','15','glpi (2)','2017-08-23 00:34:55','0','','responsables_sp (33)');
INSERT INTO `glpi_logs` VALUES ('873','Group','33','User','15','glpi (2)','2017-08-23 00:34:55','0','','Huaman Barrueta Beatriz E. (354)');
INSERT INTO `glpi_logs` VALUES ('874','User','354','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('875','User','354','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('876','User','355','Group','15','glpi (2)','2017-08-23 00:34:55','0','','efcp_of_aud_med_g (11)');
INSERT INTO `glpi_logs` VALUES ('877','Group','11','User','15','glpi (2)','2017-08-23 00:34:55','0','','Reyes Gongora Rafael (355)');
INSERT INTO `glpi_logs` VALUES ('878','User','355','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('879','User','355','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('880','User','356','Group','15','glpi (2)','2017-08-23 00:34:55','0','','efcp_of_aud_med_g (11)');
INSERT INTO `glpi_logs` VALUES ('881','Group','11','User','15','glpi (2)','2017-08-23 00:34:55','0','','Cruz Ruiz Sally (356)');
INSERT INTO `glpi_logs` VALUES ('882','User','356','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('883','User','356','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('884','User','357','Group','15','glpi (2)','2017-08-23 00:34:55','0','','efcp_of_aud_med_g (11)');
INSERT INTO `glpi_logs` VALUES ('885','Group','11','User','15','glpi (2)','2017-08-23 00:34:55','0','','Koc Castaneda Pedro  L. (357)');
INSERT INTO `glpi_logs` VALUES ('886','User','357','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('887','User','357','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('888','User','358','Group','15','glpi (2)','2017-08-23 00:34:55','0','','efcp_of_aud_med_g (11)');
INSERT INTO `glpi_logs` VALUES ('889','Group','11','User','15','glpi (2)','2017-08-23 00:34:55','0','','Robles Lezcano Corina (358)');
INSERT INTO `glpi_logs` VALUES ('890','User','358','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('891','User','358','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('892','User','359','Group','15','glpi (2)','2017-08-23 00:34:55','0','','efcp_of_aud_med_g (11)');
INSERT INTO `glpi_logs` VALUES ('893','Group','11','User','15','glpi (2)','2017-08-23 00:34:55','0','','Ramirez Oropeza Ramon (359)');
INSERT INTO `glpi_logs` VALUES ('894','User','359','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('895','User','359','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('896','User','360','Group','15','glpi (2)','2017-08-23 00:34:55','0','','efcp_of_aud_med_g (11)');
INSERT INTO `glpi_logs` VALUES ('897','Group','11','User','15','glpi (2)','2017-08-23 00:34:55','0','','Sanchez Broncano Juan (360)');
INSERT INTO `glpi_logs` VALUES ('898','User','360','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('899','User','360','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('900','User','361','Group','15','glpi (2)','2017-08-23 00:34:55','0','','efcp_of_aud_med_g (11)');
INSERT INTO `glpi_logs` VALUES ('901','Group','11','User','15','glpi (2)','2017-08-23 00:34:55','0','','Muñoz Tello Miguel (361)');
INSERT INTO `glpi_logs` VALUES ('902','User','361','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('903','User','361','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('904','User','362','Group','15','glpi (2)','2017-08-23 00:34:55','0','','efcp_of_aud_med_g (11)');
INSERT INTO `glpi_logs` VALUES ('905','Group','11','User','15','glpi (2)','2017-08-23 00:34:55','0','','Mechato Aldave Javier (362)');
INSERT INTO `glpi_logs` VALUES ('906','User','362','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('907','User','362','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('908','User','363','Group','15','glpi (2)','2017-08-23 00:34:55','0','','efcp_of_aud_med_g (11)');
INSERT INTO `glpi_logs` VALUES ('909','Group','11','User','15','glpi (2)','2017-08-23 00:34:55','0','','Maguina Aguedo Katty (363)');
INSERT INTO `glpi_logs` VALUES ('910','User','363','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('911','User','363','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('912','User','364','Group','15','glpi (2)','2017-08-23 00:34:55','0','','efcp_of_aud_med_g (11)');
INSERT INTO `glpi_logs` VALUES ('913','Group','11','User','15','glpi (2)','2017-08-23 00:34:55','0','','Begazo Neyra Mery (364)');
INSERT INTO `glpi_logs` VALUES ('914','User','364','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('915','User','364','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('916','User','365','Group','15','glpi (2)','2017-08-23 00:34:55','0','','efcp_of_aud_med_g (11)');
INSERT INTO `glpi_logs` VALUES ('917','Group','11','User','15','glpi (2)','2017-08-23 00:34:55','0','','Chavez Castaneda Carla (365)');
INSERT INTO `glpi_logs` VALUES ('918','User','365','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('919','User','365','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('920','User','366','Group','15','glpi (2)','2017-08-23 00:34:55','0','','efcp_of_aud_med_g (11)');
INSERT INTO `glpi_logs` VALUES ('921','Group','11','User','15','glpi (2)','2017-08-23 00:34:55','0','','Gonzales Lopez Paloma (366)');
INSERT INTO `glpi_logs` VALUES ('922','User','366','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('923','User','366','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('924','User','367','Group','15','glpi (2)','2017-08-23 00:34:55','0','','efcp_of_aud_med_g (11)');
INSERT INTO `glpi_logs` VALUES ('925','Group','11','User','15','glpi (2)','2017-08-23 00:34:55','0','','Begazo Neyra Mery (367)');
INSERT INTO `glpi_logs` VALUES ('926','User','367','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('927','User','367','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('928','User','368','Group','15','glpi (2)','2017-08-23 00:34:55','0','','logistic16_p (28)');
INSERT INTO `glpi_logs` VALUES ('929','Group','28','User','15','glpi (2)','2017-08-23 00:34:55','0','','auditoria (368)');
INSERT INTO `glpi_logs` VALUES ('930','User','368','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('931','User','368','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('932','User','369','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('933','User','369','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('934','User','370','Group','15','glpi (2)','2017-08-23 00:34:55','0','','efga_w (17)');
INSERT INTO `glpi_logs` VALUES ('935','Group','17','User','15','glpi (2)','2017-08-23 00:34:55','0','','Ninapaytan Miranda Crys (370)');
INSERT INTO `glpi_logs` VALUES ('936','User','370','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('937','User','370','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('938','User','371','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('939','User','371','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('940','User','372','Group','15','glpi (2)','2017-08-23 00:34:55','0','','coordinaciones_gg (6)');
INSERT INTO `glpi_logs` VALUES ('941','Group','6','User','15','glpi (2)','2017-08-23 00:34:55','0','','Pretel Menacho Jessica (372)');
INSERT INTO `glpi_logs` VALUES ('942','User','372','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('943','User','372','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('944','User','373','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('945','User','373','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('946','User','374','Group','15','glpi (2)','2017-08-23 00:34:55','0','','coordinaciones_gg (6)');
INSERT INTO `glpi_logs` VALUES ('947','Group','6','User','15','glpi (2)','2017-08-23 00:34:55','0','','Gamarra Esmeralda (374)');
INSERT INTO `glpi_logs` VALUES ('948','User','374','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('949','User','374','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('950','User','375','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('951','User','375','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('952','User','376','Group','15','glpi (2)','2017-08-23 00:34:55','0','','coordinaciones_gg (6)');
INSERT INTO `glpi_logs` VALUES ('953','Group','6','User','15','glpi (2)','2017-08-23 00:34:55','0','','Manrique Aguilar Ana (376)');
INSERT INTO `glpi_logs` VALUES ('954','User','376','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('955','User','376','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('956','User','377','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('957','User','377','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('958','User','378','Group','15','glpi (2)','2017-08-23 00:34:55','0','','coordinaciones_gg (6)');
INSERT INTO `glpi_logs` VALUES ('959','Group','6','User','15','glpi (2)','2017-08-23 00:34:55','0','','Loarte Zorrilla Elizabeth (378)');
INSERT INTO `glpi_logs` VALUES ('960','User','378','Group','15','glpi (2)','2017-08-23 00:34:55','0','','efcp_of_aud_med_g (11)');
INSERT INTO `glpi_logs` VALUES ('961','Group','11','User','15','glpi (2)','2017-08-23 00:34:55','0','','Loarte Zorrilla Elizabeth (378)');
INSERT INTO `glpi_logs` VALUES ('962','User','378','Group','15','glpi (2)','2017-08-23 00:34:55','0','','secretarias_sp (34)');
INSERT INTO `glpi_logs` VALUES ('963','Group','34','User','15','glpi (2)','2017-08-23 00:34:55','0','','Loarte Zorrilla Elizabeth (378)');
INSERT INTO `glpi_logs` VALUES ('964','User','378','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('965','User','378','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('966','User','379','Group','15','glpi (2)','2017-08-23 00:34:55','0','','efcp_of_aud_med_g (11)');
INSERT INTO `glpi_logs` VALUES ('967','Group','11','User','15','glpi (2)','2017-08-23 00:34:55','0','','Inomata Suazo Maria Belen (379)');
INSERT INTO `glpi_logs` VALUES ('968','User','379','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('969','User','379','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('970','User','380','Group','15','glpi (2)','2017-08-23 00:34:55','0','','efrh_g (21)');
INSERT INTO `glpi_logs` VALUES ('971','Group','21','User','15','glpi (2)','2017-08-23 00:34:55','0','','Quispe Cotrina Cesia (380)');
INSERT INTO `glpi_logs` VALUES ('972','User','380','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('973','User','380','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('974','User','381','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('975','User','381','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('976','User','382','Group','15','glpi (2)','2017-08-23 00:34:55','0','','servicios_generales_g (35)');
INSERT INTO `glpi_logs` VALUES ('977','Group','35','User','15','glpi (2)','2017-08-23 00:34:55','0','','Molero Baez Jorge Luis (382)');
INSERT INTO `glpi_logs` VALUES ('978','User','382','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('979','User','382','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('980','User','383','Group','15','glpi (2)','2017-08-23 00:34:55','0','','servicios_generales_g (35)');
INSERT INTO `glpi_logs` VALUES ('981','Group','35','User','15','glpi (2)','2017-08-23 00:34:55','0','','Chivilches Talledo Miguel (383)');
INSERT INTO `glpi_logs` VALUES ('982','User','383','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('983','User','383','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('984','User','384','Group','15','glpi (2)','2017-08-23 00:34:55','0','','efrh_assist_control_g (20)');
INSERT INTO `glpi_logs` VALUES ('985','Group','20','User','15','glpi (2)','2017-08-23 00:34:55','0','','Quintanilla Renteria Maria (384)');
INSERT INTO `glpi_logs` VALUES ('986','User','384','Group','15','glpi (2)','2017-08-23 00:34:55','0','','efrh_g (21)');
INSERT INTO `glpi_logs` VALUES ('987','Group','21','User','15','glpi (2)','2017-08-23 00:34:55','0','','Quintanilla Renteria Maria (384)');
INSERT INTO `glpi_logs` VALUES ('988','User','384','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('989','User','384','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('990','User','385','Group','15','glpi (2)','2017-08-23 00:34:55','0','','efrh_assist_control_g (20)');
INSERT INTO `glpi_logs` VALUES ('991','Group','20','User','15','glpi (2)','2017-08-23 00:34:55','0','','Espinoza Centurion Walter (385)');
INSERT INTO `glpi_logs` VALUES ('992','User','385','Group','15','glpi (2)','2017-08-23 00:34:55','0','','efrh_g (21)');
INSERT INTO `glpi_logs` VALUES ('993','Group','21','User','15','glpi (2)','2017-08-23 00:34:55','0','','Espinoza Centurion Walter (385)');
INSERT INTO `glpi_logs` VALUES ('994','User','385','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('995','User','385','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('996','User','386','Group','15','glpi (2)','2017-08-23 00:34:55','0','','efrh_assist_control_g (20)');
INSERT INTO `glpi_logs` VALUES ('997','Group','20','User','15','glpi (2)','2017-08-23 00:34:55','0','','Mego Aramburu Haydee L. (386)');
INSERT INTO `glpi_logs` VALUES ('998','User','386','Group','15','glpi (2)','2017-08-23 00:34:55','0','','efrh_g (21)');
INSERT INTO `glpi_logs` VALUES ('999','Group','21','User','15','glpi (2)','2017-08-23 00:34:55','0','','Mego Aramburu Haydee L. (386)');
INSERT INTO `glpi_logs` VALUES ('1000','User','386','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('1001','User','386','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('1002','User','387','Group','15','glpi (2)','2017-08-23 00:34:55','0','','efrh_assist_control_g (20)');
INSERT INTO `glpi_logs` VALUES ('1003','Group','20','User','15','glpi (2)','2017-08-23 00:34:55','0','','Burga Vasquez Edward (387)');
INSERT INTO `glpi_logs` VALUES ('1004','User','387','Group','15','glpi (2)','2017-08-23 00:34:55','0','','efrh_g (21)');
INSERT INTO `glpi_logs` VALUES ('1005','Group','21','User','15','glpi (2)','2017-08-23 00:34:55','0','','Burga Vasquez Edward (387)');
INSERT INTO `glpi_logs` VALUES ('1006','User','387','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('1007','User','387','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('1008','User','388','Group','15','glpi (2)','2017-08-23 00:34:55','0','','coordinaciones_gg (6)');
INSERT INTO `glpi_logs` VALUES ('1009','Group','6','User','15','glpi (2)','2017-08-23 00:34:55','0','','Escajadillo Suarez Hilder (388)');
INSERT INTO `glpi_logs` VALUES ('1010','User','388','Group','15','glpi (2)','2017-08-23 00:34:55','0','','gg_of_seguros (26)');
INSERT INTO `glpi_logs` VALUES ('1011','Group','26','User','15','glpi (2)','2017-08-23 00:34:55','0','','Escajadillo Suarez Hilder (388)');
INSERT INTO `glpi_logs` VALUES ('1012','User','388','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('1013','User','388','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('1014','User','389','Group','15','glpi (2)','2017-08-23 00:34:55','0','','coordinaciones_gg (6)');
INSERT INTO `glpi_logs` VALUES ('1015','Group','6','User','15','glpi (2)','2017-08-23 00:34:55','0','','Banda Lozano Melissa (389)');
INSERT INTO `glpi_logs` VALUES ('1016','User','389','Group','15','glpi (2)','2017-08-23 00:34:55','0','','gg_of_seguros (26)');
INSERT INTO `glpi_logs` VALUES ('1017','Group','26','User','15','glpi (2)','2017-08-23 00:34:55','0','','Banda Lozano Melissa (389)');
INSERT INTO `glpi_logs` VALUES ('1018','User','389','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('1019','User','389','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('1020','User','390','Group','15','glpi (2)','2017-08-23 00:34:55','0','','coordinaciones_gg (6)');
INSERT INTO `glpi_logs` VALUES ('1021','Group','6','User','15','glpi (2)','2017-08-23 00:34:55','0','','Cerna Quiroz Glenda (390)');
INSERT INTO `glpi_logs` VALUES ('1022','User','390','Group','15','glpi (2)','2017-08-23 00:34:55','0','','gg_g (25)');
INSERT INTO `glpi_logs` VALUES ('1023','Group','25','User','15','glpi (2)','2017-08-23 00:34:55','0','','Cerna Quiroz Glenda (390)');
INSERT INTO `glpi_logs` VALUES ('1024','User','390','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('1025','User','390','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('1026','User','391','Group','15','glpi (2)','2017-08-23 00:34:55','0','','efcp_of_aud_med_g (11)');
INSERT INTO `glpi_logs` VALUES ('1027','Group','11','User','15','glpi (2)','2017-08-23 00:34:55','0','','Rios Diaz Eyleen (391)');
INSERT INTO `glpi_logs` VALUES ('1028','User','391','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('1029','User','391','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('1030','User','392','Group','15','glpi (2)','2017-08-23 00:34:55','0','','efcp_of_aud_med_g (11)');
INSERT INTO `glpi_logs` VALUES ('1031','Group','11','User','15','glpi (2)','2017-08-23 00:34:55','0','','Tamayo Martinez Blado (392)');
INSERT INTO `glpi_logs` VALUES ('1032','User','392','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('1033','User','392','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('1034','User','393','Group','15','glpi (2)','2017-08-23 00:34:55','0','','efcp_of_aud_med_g (11)');
INSERT INTO `glpi_logs` VALUES ('1035','Group','11','User','15','glpi (2)','2017-08-23 00:34:55','0','','Diaz Heredia Yovana (393)');
INSERT INTO `glpi_logs` VALUES ('1036','User','393','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('1037','User','393','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('1038','User','394','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('1039','User','394','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('1040','User','395','Group','15','glpi (2)','2017-08-23 00:34:55','0','','coordinaciones_gg (6)');
INSERT INTO `glpi_logs` VALUES ('1041','Group','6','User','15','glpi (2)','2017-08-23 00:34:55','0','','Andonaire Jackeline (395)');
INSERT INTO `glpi_logs` VALUES ('1042','User','395','Group','15','glpi (2)','2017-08-23 00:34:55','0','','sp_eq_fun_adm_g (36)');
INSERT INTO `glpi_logs` VALUES ('1043','Group','36','User','15','glpi (2)','2017-08-23 00:34:55','0','','Andonaire Jackeline (395)');
INSERT INTO `glpi_logs` VALUES ('1044','User','395','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('1045','User','395','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('1046','User','396','Group','15','glpi (2)','2017-08-23 00:34:55','0','','sp_eq_fun_adm_g (36)');
INSERT INTO `glpi_logs` VALUES ('1047','Group','36','User','15','glpi (2)','2017-08-23 00:34:55','0','','Chuan Mendoza Adriana (396)');
INSERT INTO `glpi_logs` VALUES ('1048','User','396','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('1049','User','396','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('1050','User','397','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('1051','User','397','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('1052','User','398','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('1053','User','398','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('1054','User','399','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('1055','User','399','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('1056','User','400','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('1057','User','400','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('1058','User','401','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('1059','User','401','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('1060','User','402','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('1061','User','402','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('1062','User','403','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('1063','User','403','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('1064','User','404','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('1065','User','404','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('1066','User','405','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('1067','User','405','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('1068','User','406','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('1069','User','406','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('1070','User','407','Group','15','glpi (2)','2017-08-23 00:34:55','0','','responsables_sp (33)');
INSERT INTO `glpi_logs` VALUES ('1071','Group','33','User','15','glpi (2)','2017-08-23 00:34:55','0','','Mena Benavente Amalia Celica (407)');
INSERT INTO `glpi_logs` VALUES ('1072','User','407','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('1073','User','407','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('1074','User','408','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('1075','User','408','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('1076','User','409','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('1077','User','409','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('1078','User','410','Group','15','glpi (2)','2017-08-23 00:34:55','0','','almacen_central_g (3)');
INSERT INTO `glpi_logs` VALUES ('1079','Group','3','User','15','glpi (2)','2017-08-23 00:34:55','0','','Calvay Cruz Diana (410)');
INSERT INTO `glpi_logs` VALUES ('1080','User','410','Group','15','glpi (2)','2017-08-23 00:34:55','0','','logistic16_p (28)');
INSERT INTO `glpi_logs` VALUES ('1081','Group','28','User','15','glpi (2)','2017-08-23 00:34:55','0','','Calvay Cruz Diana (410)');
INSERT INTO `glpi_logs` VALUES ('1082','User','410','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('1083','User','410','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('1084','User','411','Group','15','glpi (2)','2017-08-23 00:34:55','0','','almacen_central_g (3)');
INSERT INTO `glpi_logs` VALUES ('1085','Group','3','User','15','glpi (2)','2017-08-23 00:34:55','0','','Gonzales Suarez Medaly (411)');
INSERT INTO `glpi_logs` VALUES ('1086','User','411','Group','15','glpi (2)','2017-08-23 00:34:55','0','','logistic16_p (28)');
INSERT INTO `glpi_logs` VALUES ('1087','Group','28','User','15','glpi (2)','2017-08-23 00:34:55','0','','Gonzales Suarez Medaly (411)');
INSERT INTO `glpi_logs` VALUES ('1088','User','411','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('1089','User','411','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('1090','User','412','Group','15','glpi (2)','2017-08-23 00:34:55','0','','almacen_central_g (3)');
INSERT INTO `glpi_logs` VALUES ('1091','Group','3','User','15','glpi (2)','2017-08-23 00:34:55','0','','Aldaz Alarcon Vanesa (412)');
INSERT INTO `glpi_logs` VALUES ('1092','User','412','Group','15','glpi (2)','2017-08-23 00:34:55','0','','logistic16_p (28)');
INSERT INTO `glpi_logs` VALUES ('1093','Group','28','User','15','glpi (2)','2017-08-23 00:34:55','0','','Aldaz Alarcon Vanesa (412)');
INSERT INTO `glpi_logs` VALUES ('1094','User','412','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('1095','User','412','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('1096','User','413','Group','15','glpi (2)','2017-08-23 00:34:55','0','','almacen_central_g (3)');
INSERT INTO `glpi_logs` VALUES ('1097','Group','3','User','15','glpi (2)','2017-08-23 00:34:55','0','','Diaz Barrios Richard (413)');
INSERT INTO `glpi_logs` VALUES ('1098','User','413','Group','15','glpi (2)','2017-08-23 00:34:55','0','','logistic16_p (28)');
INSERT INTO `glpi_logs` VALUES ('1099','Group','28','User','15','glpi (2)','2017-08-23 00:34:55','0','','Diaz Barrios Richard (413)');
INSERT INTO `glpi_logs` VALUES ('1100','User','413','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('1101','User','413','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('1102','User','414','Group','15','glpi (2)','2017-08-23 00:34:55','0','','almacen_central_g (3)');
INSERT INTO `glpi_logs` VALUES ('1103','Group','3','User','15','glpi (2)','2017-08-23 00:34:55','0','','Mendoza Uribe Augusto (414)');
INSERT INTO `glpi_logs` VALUES ('1104','User','414','Group','15','glpi (2)','2017-08-23 00:34:55','0','','logistic16_p (28)');
INSERT INTO `glpi_logs` VALUES ('1105','Group','28','User','15','glpi (2)','2017-08-23 00:34:55','0','','Mendoza Uribe Augusto (414)');
INSERT INTO `glpi_logs` VALUES ('1106','User','414','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('1107','User','414','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('1108','User','415','Group','15','glpi (2)','2017-08-23 00:34:55','0','','almacen_central_g (3)');
INSERT INTO `glpi_logs` VALUES ('1109','Group','3','User','15','glpi (2)','2017-08-23 00:34:55','0','','Quispe Sandoval Luis (415)');
INSERT INTO `glpi_logs` VALUES ('1110','User','415','Group','15','glpi (2)','2017-08-23 00:34:55','0','','logistic16_p (28)');
INSERT INTO `glpi_logs` VALUES ('1111','Group','28','User','15','glpi (2)','2017-08-23 00:34:55','0','','Quispe Sandoval Luis (415)');
INSERT INTO `glpi_logs` VALUES ('1112','User','415','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('1113','User','415','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('1114','User','416','Group','15','glpi (2)','2017-08-23 00:34:55','0','','eff_g (16)');
INSERT INTO `glpi_logs` VALUES ('1115','Group','16','User','15','glpi (2)','2017-08-23 00:34:55','0','','Salas Paz Elizabeth E. (416)');
INSERT INTO `glpi_logs` VALUES ('1116','User','416','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('1117','User','416','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('1118','User','417','Group','15','glpi (2)','2017-08-23 00:34:55','0','','logistic16_p (28)');
INSERT INTO `glpi_logs` VALUES ('1119','Group','28','User','15','glpi (2)','2017-08-23 00:34:55','0','','actos_preparatorios_procedimiento_seleccion_g (417)');
INSERT INTO `glpi_logs` VALUES ('1120','User','417','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('1121','User','417','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('1122','User','418','Group','15','glpi (2)','2017-08-23 00:34:55','0','','gg_of_seguros (26)');
INSERT INTO `glpi_logs` VALUES ('1123','Group','26','User','15','glpi (2)','2017-08-23 00:34:55','0','','Cordova Malca Angela Jessica (418)');
INSERT INTO `glpi_logs` VALUES ('1124','User','418','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('1125','User','418','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('1126','User','419','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('1127','User','419','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('1128','User','420','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('1129','User','420','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('1130','User','421','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('1131','User','421','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('1132','User','422','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('1133','User','422','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('1134','User','423','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('1135','User','423','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('1136','User','424','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('1137','User','424','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('1138','User','425','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('1139','User','425','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('1140','User','426','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('1141','User','426','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('1142','User','427','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('1143','User','427','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('1144','User','428','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('1145','User','428','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('1146','User','429','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('1147','User','429','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('1148','User','430','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('1149','User','430','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('1150','User','431','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('1151','User','431','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('1152','User','432','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('1153','User','432','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('1154','User','433','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('1155','User','433','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('1156','User','434','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('1157','User','434','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('1158','User','435','Profile','17','glpi (2)','2017-08-23 00:34:55','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('1159','User','435','0','20','glpi (2)','2017-08-23 00:34:55','0','','');
INSERT INTO `glpi_logs` VALUES ('1160','User','126','Group','15','glpi (2)','2017-08-23 15:51:21','0','','control_previo_g (5)');
INSERT INTO `glpi_logs` VALUES ('1161','Group','5','User','15','glpi (2)','2017-08-23 15:51:21','0','','Franco Rojas Tania (126)');
INSERT INTO `glpi_logs` VALUES ('1162','User','126','Group','15','glpi (2)','2017-08-23 15:51:21','0','','sp_of_eco_con_g (38)');
INSERT INTO `glpi_logs` VALUES ('1163','Group','38','User','15','glpi (2)','2017-08-23 15:51:21','0','','Franco Rojas Tania (126)');
INSERT INTO `glpi_logs` VALUES ('1164','User','134','Group','15','glpi (2)','2017-08-23 15:51:21','0','','control_previo_g (5)');
INSERT INTO `glpi_logs` VALUES ('1165','Group','5','User','15','glpi (2)','2017-08-23 15:51:21','0','','Zagaceta Mendoza Jorge (134)');
INSERT INTO `glpi_logs` VALUES ('1166','User','134','Group','15','glpi (2)','2017-08-23 15:51:21','0','','sp_of_eco_con_g (38)');
INSERT INTO `glpi_logs` VALUES ('1167','Group','38','User','15','glpi (2)','2017-08-23 15:51:21','0','','Zagaceta Mendoza Jorge (134)');
INSERT INTO `glpi_logs` VALUES ('1168','User','136','Group','15','glpi (2)','2017-08-23 15:51:21','0','','control_previo_g (5)');
INSERT INTO `glpi_logs` VALUES ('1169','Group','5','User','15','glpi (2)','2017-08-23 15:51:21','0','','Pari Paredes Mirian (136)');
INSERT INTO `glpi_logs` VALUES ('1170','User','136','Group','15','glpi (2)','2017-08-23 15:51:21','0','','sp_of_eco_con_g (38)');
INSERT INTO `glpi_logs` VALUES ('1171','Group','38','User','15','glpi (2)','2017-08-23 15:51:21','0','','Pari Paredes Mirian (136)');
INSERT INTO `glpi_logs` VALUES ('1172','User','174','Group','15','glpi (2)','2017-08-23 15:51:21','0','','efga_w (17)');
INSERT INTO `glpi_logs` VALUES ('1173','Group','17','User','15','glpi (2)','2017-08-23 15:51:21','0','','Illescas Ruiz Luz Marina (174)');
INSERT INTO `glpi_logs` VALUES ('1174','User','174','Group','15','glpi (2)','2017-08-23 15:51:21','0','','responsables_sp (33)');
INSERT INTO `glpi_logs` VALUES ('1175','Group','33','User','15','glpi (2)','2017-08-23 15:51:21','0','','Illescas Ruiz Luz Marina (174)');
INSERT INTO `glpi_logs` VALUES ('1176','Entity','0','','0','glpi (2)','2017-08-23 16:25:54','14','Root entity','Saludpol');
INSERT INTO `glpi_logs` VALUES ('1177','Entity','0','','0','glpi (2)','2017-08-23 16:25:54','1','Root entity','Saludpol');
INSERT INTO `glpi_logs` VALUES ('1178','AuthMail','1','0','20','glpi (2)','2017-08-23 16:41:12','0','','');
INSERT INTO `glpi_logs` VALUES ('1179','AuthMail','1','','0','glpi (2)','2017-08-23 16:43:08','3','','saludpol');
INSERT INTO `glpi_logs` VALUES ('1180','AuthMail','1','','0','glpi (2)','2017-08-23 16:43:08','4','{zimbra.saludpol.gob.pe/pop/ssl/validate-cert/tls/norsh/secure}','{zimbra.saludpol.gob.pe:465/pop/ssl/validate-cert/tls/norsh/secure}');
INSERT INTO `glpi_logs` VALUES ('1181','AuthMail','1','','0','glpi (2)','2017-08-23 16:47:23','3','saludpol','fmendoza@saludpol.gob.pe');
INSERT INTO `glpi_logs` VALUES ('1182','AuthMail','1','','0','glpi (2)','2017-08-23 16:47:23','4','{zimbra.saludpol.gob.pe:465/pop/ssl/validate-cert/tls/norsh/secure}','{zimbra.saludpol.gob.pe:25/pop/ssl/validate-cert/tls/norsh/secure}');
INSERT INTO `glpi_logs` VALUES ('1183','AuthMail','1','','0','glpi (2)','2017-08-23 16:50:13','3','fmendoza@saludpol.gob.pe','');
INSERT INTO `glpi_logs` VALUES ('1184','AuthMail','1','','0','glpi (2)','2017-08-23 17:00:55','1','SaludPol','Servidor de Correo SaludPol');
INSERT INTO `glpi_logs` VALUES ('1185','AuthMail','1','','0','glpi (2)','2017-08-23 17:00:55','4','{zimbra.saludpol.gob.pe:25/pop/ssl/validate-cert/tls/norsh/secure}','{zimbra.saludpol.gob.pe:25/pop}');
INSERT INTO `glpi_logs` VALUES ('1186','AuthLDAP','1','','0','glpi (2)','2017-08-23 18:41:07','24','0','2');
INSERT INTO `glpi_logs` VALUES ('1187','AuthLDAP','1','','0','glpi (2)','2017-08-23 18:47:07','17','mail','userprincipalname');
INSERT INTO `glpi_logs` VALUES ('1188','AuthLDAP','1','','0','glpi (2)','2017-08-23 18:47:07','25','','mail');
INSERT INTO `glpi_logs` VALUES ('1189','User','7','Group','15','glpi (2)','2017-08-23 18:55:54','0','','logistic16_p (28)');
INSERT INTO `glpi_logs` VALUES ('1190','Group','28','User','15','glpi (2)','2017-08-23 18:55:54','0','','Yamunaque Cruz Willian Cesar (7)');
INSERT INTO `glpi_logs` VALUES ('1191','User','7','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','wyamunaquec@saludpol.local (2)');
INSERT INTO `glpi_logs` VALUES ('1192','UserEmail','2','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1193','User','8','Group','15','glpi (2)','2017-08-23 18:55:54','0','','efrh_assist_control_g (20)');
INSERT INTO `glpi_logs` VALUES ('1194','Group','20','User','15','glpi (2)','2017-08-23 18:55:54','0','','Valdivia Ludena Willy Milton (8)');
INSERT INTO `glpi_logs` VALUES ('1195','User','8','Group','15','glpi (2)','2017-08-23 18:55:54','0','','efrh_g (21)');
INSERT INTO `glpi_logs` VALUES ('1196','Group','21','User','15','glpi (2)','2017-08-23 18:55:54','0','','Valdivia Ludena Willy Milton (8)');
INSERT INTO `glpi_logs` VALUES ('1197','User','8','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','wvaldivia@saludpol.local (3)');
INSERT INTO `glpi_logs` VALUES ('1198','UserEmail','3','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1199','User','9','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','wportocarrero@saludpol.local (4)');
INSERT INTO `glpi_logs` VALUES ('1200','UserEmail','4','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1201','User','10','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','vramirezy@saludpol.local (5)');
INSERT INTO `glpi_logs` VALUES ('1202','UserEmail','5','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1203','User','11','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','vgarcia@saludpol.local (6)');
INSERT INTO `glpi_logs` VALUES ('1204','UserEmail','6','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1205','User','12','Group','15','glpi (2)','2017-08-23 18:55:54','0','','efaj_g (8)');
INSERT INTO `glpi_logs` VALUES ('1206','Group','8','User','15','glpi (2)','2017-08-23 18:55:54','0','','Veliz Perez Nathalie (12)');
INSERT INTO `glpi_logs` VALUES ('1207','User','12','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','user_efaj_5@saludpol.local (7)');
INSERT INTO `glpi_logs` VALUES ('1208','UserEmail','7','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1209','User','13','Group','15','glpi (2)','2017-08-23 18:55:54','0','','efaj_g (8)');
INSERT INTO `glpi_logs` VALUES ('1210','Group','8','User','15','glpi (2)','2017-08-23 18:55:54','0','','Penaloza Huacachin Edith (13)');
INSERT INTO `glpi_logs` VALUES ('1211','User','13','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','user_efaj_4@saludpol.local (8)');
INSERT INTO `glpi_logs` VALUES ('1212','UserEmail','8','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1213','User','14','Group','15','glpi (2)','2017-08-23 18:55:54','0','','efaj_g (8)');
INSERT INTO `glpi_logs` VALUES ('1214','Group','8','User','15','glpi (2)','2017-08-23 18:55:54','0','','Cubas Ayasta Zarela (14)');
INSERT INTO `glpi_logs` VALUES ('1215','User','14','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','user_efaj_3@saludpol.local (9)');
INSERT INTO `glpi_logs` VALUES ('1216','UserEmail','9','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1217','User','15','Group','15','glpi (2)','2017-08-23 18:55:54','0','','efaj_g (8)');
INSERT INTO `glpi_logs` VALUES ('1218','Group','8','User','15','glpi (2)','2017-08-23 18:55:54','0','','Remotti Carbonell Gisella (15)');
INSERT INTO `glpi_logs` VALUES ('1219','User','15','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','user_efaj_2@saludpol.local (10)');
INSERT INTO `glpi_logs` VALUES ('1220','UserEmail','10','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1221','User','16','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','user_efaj_1@saludpol.local (11)');
INSERT INTO `glpi_logs` VALUES ('1222','UserEmail','11','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1223','User','17','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','ugipress3@saludpol.local (12)');
INSERT INTO `glpi_logs` VALUES ('1224','UserEmail','12','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1225','User','18','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','ugipress2@saludpol.local (13)');
INSERT INTO `glpi_logs` VALUES ('1226','UserEmail','13','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1227','User','19','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','ugipress1@saludpol.local (14)');
INSERT INTO `glpi_logs` VALUES ('1228','UserEmail','14','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1229','User','20','Group','15','glpi (2)','2017-08-23 18:55:54','0','','efcp_of_aud_med_g (11)');
INSERT INTO `glpi_logs` VALUES ('1230','Group','11','User','15','glpi (2)','2017-08-23 18:55:54','0','','Robles Lezcano Trinidad Corina (20)');
INSERT INTO `glpi_logs` VALUES ('1231','User','20','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','trobles@saludpol.local (15)');
INSERT INTO `glpi_logs` VALUES ('1232','UserEmail','15','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1233','User','22','Group','15','glpi (2)','2017-08-23 18:55:54','0','','eff_g (16)');
INSERT INTO `glpi_logs` VALUES ('1234','Group','16','User','15','glpi (2)','2017-08-23 18:55:54','0','','Paredes Cabel Jose R. (22)');
INSERT INTO `glpi_logs` VALUES ('1235','User','22','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','tec_eff4@saludpol.local (16)');
INSERT INTO `glpi_logs` VALUES ('1236','UserEmail','16','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1237','User','23','Group','15','glpi (2)','2017-08-23 18:55:54','0','','eff_g (16)');
INSERT INTO `glpi_logs` VALUES ('1238','Group','16','User','15','glpi (2)','2017-08-23 18:55:54','0','','Reynoso Gutierrez Guillermo F. (23)');
INSERT INTO `glpi_logs` VALUES ('1239','User','23','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','tec_eff3@saludpol.local (17)');
INSERT INTO `glpi_logs` VALUES ('1240','UserEmail','17','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1241','User','24','Group','15','glpi (2)','2017-08-23 18:55:54','0','','eff_g (16)');
INSERT INTO `glpi_logs` VALUES ('1242','Group','16','User','15','glpi (2)','2017-08-23 18:55:54','0','','Orrego Rodriguez Carlos A. (24)');
INSERT INTO `glpi_logs` VALUES ('1243','User','24','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','tec_eff2@saludpol.local (18)');
INSERT INTO `glpi_logs` VALUES ('1244','UserEmail','18','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1245','User','25','Group','15','glpi (2)','2017-08-23 18:55:54','0','','eff_g (16)');
INSERT INTO `glpi_logs` VALUES ('1246','Group','16','User','15','glpi (2)','2017-08-23 18:55:54','0','','Hermoza Injoque Melissa M. (25)');
INSERT INTO `glpi_logs` VALUES ('1247','User','25','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','tec_eff1@saludpol.local (19)');
INSERT INTO `glpi_logs` VALUES ('1248','UserEmail','19','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1249','User','26','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','sverasteguie@saludpol.local (20)');
INSERT INTO `glpi_logs` VALUES ('1250','UserEmail','20','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1251','User','28','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','support@saludpol.local (21)');
INSERT INTO `glpi_logs` VALUES ('1252','UserEmail','21','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1253','User','32','Group','15','glpi (2)','2017-08-23 18:55:54','0','','efrh_assist_control_g (20)');
INSERT INTO `glpi_logs` VALUES ('1254','Group','20','User','15','glpi (2)','2017-08-23 18:55:54','0','','Raffo Noriega Carlos Americo (32)');
INSERT INTO `glpi_logs` VALUES ('1255','User','32','Group','15','glpi (2)','2017-08-23 18:55:54','0','','efrh_g (21)');
INSERT INTO `glpi_logs` VALUES ('1256','Group','21','User','15','glpi (2)','2017-08-23 18:55:54','0','','Raffo Noriega Carlos Americo (32)');
INSERT INTO `glpi_logs` VALUES ('1257','User','32','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','soporte_rrhh1@saludpol.local (22)');
INSERT INTO `glpi_logs` VALUES ('1258','UserEmail','22','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1259','User','33','Group','15','glpi (2)','2017-08-23 18:55:54','0','','Operadores de configuración de red (30)');
INSERT INTO `glpi_logs` VALUES ('1260','Group','30','User','15','glpi (2)','2017-08-23 18:55:54','0','','Ofatec Soporte (33)');
INSERT INTO `glpi_logs` VALUES ('1261','User','33','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','soporte@saludpol.local (23)');
INSERT INTO `glpi_logs` VALUES ('1262','UserEmail','23','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1263','User','34','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','smorey@saludpol.local (24)');
INSERT INTO `glpi_logs` VALUES ('1264','UserEmail','24','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1265','User','35','Group','15','glpi (2)','2017-08-23 18:55:54','0','','logistic16_p (28)');
INSERT INTO `glpi_logs` VALUES ('1266','Group','28','User','15','glpi (2)','2017-08-23 18:55:54','0','','servicios_generales_g (35)');
INSERT INTO `glpi_logs` VALUES ('1267','User','37','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','secre_oseguros1@saludpol.local (25)');
INSERT INTO `glpi_logs` VALUES ('1268','UserEmail','25','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1269','User','38','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','secre_efga@saludpol.local (26)');
INSERT INTO `glpi_logs` VALUES ('1270','UserEmail','26','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1271','User','39','Group','15','glpi (2)','2017-08-23 18:55:54','0','','coordinaciones_gg (6)');
INSERT INTO `glpi_logs` VALUES ('1272','Group','6','User','15','glpi (2)','2017-08-23 18:55:54','0','','Penalillo Rocha Isabel (39)');
INSERT INTO `glpi_logs` VALUES ('1273','User','39','Group','15','glpi (2)','2017-08-23 18:55:54','0','','Jefatura_g (27)');
INSERT INTO `glpi_logs` VALUES ('1274','Group','27','User','15','glpi (2)','2017-08-23 18:55:54','0','','Penalillo Rocha Isabel (39)');
INSERT INTO `glpi_logs` VALUES ('1275','User','39','Group','15','glpi (2)','2017-08-23 18:55:54','0','','logistica_servicios_generales_g (29)');
INSERT INTO `glpi_logs` VALUES ('1276','Group','29','User','15','glpi (2)','2017-08-23 18:55:54','0','','Penalillo Rocha Isabel (39)');
INSERT INTO `glpi_logs` VALUES ('1277','User','39','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','sec_log_1@saludpol.local (27)');
INSERT INTO `glpi_logs` VALUES ('1278','UserEmail','27','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1279','User','40','Group','15','glpi (2)','2017-08-23 18:55:54','0','','coordinaciones_gg (6)');
INSERT INTO `glpi_logs` VALUES ('1280','Group','6','User','15','glpi (2)','2017-08-23 18:55:54','0','','Torres Bastante Mayela (40)');
INSERT INTO `glpi_logs` VALUES ('1281','User','40','Group','15','glpi (2)','2017-08-23 18:55:54','0','','sp_of_eco_con_g (38)');
INSERT INTO `glpi_logs` VALUES ('1282','Group','38','User','15','glpi (2)','2017-08-23 18:55:54','0','','Torres Bastante Mayela (40)');
INSERT INTO `glpi_logs` VALUES ('1283','User','40','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','sec_econ_1@saludpol.local (28)');
INSERT INTO `glpi_logs` VALUES ('1284','UserEmail','28','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1285','User','41','Group','15','glpi (2)','2017-08-23 18:55:54','0','','efcp_of_aud_med_g (11)');
INSERT INTO `glpi_logs` VALUES ('1286','Group','11','User','15','glpi (2)','2017-08-23 18:55:54','0','','Cruz Ruiz Sally Olimpia (41)');
INSERT INTO `glpi_logs` VALUES ('1287','User','41','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','scruz@saludpol.local (29)');
INSERT INTO `glpi_logs` VALUES ('1288','UserEmail','29','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1289','User','42','Group','15','glpi (2)','2017-08-23 18:55:54','0','','gg_of_seguros (26)');
INSERT INTO `glpi_logs` VALUES ('1290','Group','26','User','15','glpi (2)','2017-08-23 18:55:54','0','','Cabello Calero Sussy (42)');
INSERT INTO `glpi_logs` VALUES ('1291','User','42','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','scabelloc@saludpol.local (30)');
INSERT INTO `glpi_logs` VALUES ('1292','UserEmail','30','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1293','User','43','Group','15','glpi (2)','2017-08-23 18:55:54','0','','efaj_g (8)');
INSERT INTO `glpi_logs` VALUES ('1294','Group','8','User','15','glpi (2)','2017-08-23 18:55:54','0','','Alocen Tito Sylvia Liliana (43)');
INSERT INTO `glpi_logs` VALUES ('1295','User','43','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','salocent@saludpol.local (31)');
INSERT INTO `glpi_logs` VALUES ('1296','UserEmail','31','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1297','User','44','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','rvillarg@saludpol.local (32)');
INSERT INTO `glpi_logs` VALUES ('1298','UserEmail','32','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1299','User','45','Group','15','glpi (2)','2017-08-23 18:55:54','0','','almacen_central_g (3)');
INSERT INTO `glpi_logs` VALUES ('1300','Group','3','User','15','glpi (2)','2017-08-23 18:55:54','0','','Vega Takach Rosa (45)');
INSERT INTO `glpi_logs` VALUES ('1301','User','45','Group','15','glpi (2)','2017-08-23 18:55:54','0','','logistic16_p (28)');
INSERT INTO `glpi_logs` VALUES ('1302','Group','28','User','15','glpi (2)','2017-08-23 18:55:54','0','','Vega Takach Rosa (45)');
INSERT INTO `glpi_logs` VALUES ('1303','User','45','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','rvegat@saludpol.local (33)');
INSERT INTO `glpi_logs` VALUES ('1304','UserEmail','33','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1305','User','46','Group','15','glpi (2)','2017-08-23 18:55:54','0','','almacen_central_g (3)');
INSERT INTO `glpi_logs` VALUES ('1306','Group','3','User','15','glpi (2)','2017-08-23 18:55:54','0','','Lopez Arana Rogger (46)');
INSERT INTO `glpi_logs` VALUES ('1307','User','46','Group','15','glpi (2)','2017-08-23 18:55:54','0','','logistic16_p (28)');
INSERT INTO `glpi_logs` VALUES ('1308','Group','28','User','15','glpi (2)','2017-08-23 18:55:54','0','','Lopez Arana Rogger (46)');
INSERT INTO `glpi_logs` VALUES ('1309','User','46','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','rlopeza@saludpol.local (34)');
INSERT INTO `glpi_logs` VALUES ('1310','UserEmail','34','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1311','User','47','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','ringas@saludpol.local (35)');
INSERT INTO `glpi_logs` VALUES ('1312','UserEmail','35','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1313','User','48','Group','15','glpi (2)','2017-08-23 18:55:54','0','','gg_g (25)');
INSERT INTO `glpi_logs` VALUES ('1314','Group','25','User','15','glpi (2)','2017-08-23 18:55:54','0','','Hidalgo Jara Rene (48)');
INSERT INTO `glpi_logs` VALUES ('1315','User','48','Group','15','glpi (2)','2017-08-23 18:55:54','0','','responsables_sp (33)');
INSERT INTO `glpi_logs` VALUES ('1316','Group','33','User','15','glpi (2)','2017-08-23 18:55:54','0','','Hidalgo Jara Rene (48)');
INSERT INTO `glpi_logs` VALUES ('1317','User','48','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','rhidalgoj@saludpol.local (36)');
INSERT INTO `glpi_logs` VALUES ('1318','UserEmail','36','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1319','User','49','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','rfloress@saludpol.local (37)');
INSERT INTO `glpi_logs` VALUES ('1320','UserEmail','37','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1321','User','50','Group','15','glpi (2)','2017-08-23 18:55:54','0','','sp_of_eco_con_g (38)');
INSERT INTO `glpi_logs` VALUES ('1322','Group','38','User','15','glpi (2)','2017-08-23 18:55:54','0','','Fajardo Saucedo Robert Modesto (50)');
INSERT INTO `glpi_logs` VALUES ('1323','User','50','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','rfajardos@saludpol.local (38)');
INSERT INTO `glpi_logs` VALUES ('1324','UserEmail','38','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1325','User','52','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','red.servidor01@saludpol.local (39)');
INSERT INTO `glpi_logs` VALUES ('1326','UserEmail','39','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1327','User','53','Group','15','glpi (2)','2017-08-23 18:55:54','0','','logistic16_p (28)');
INSERT INTO `glpi_logs` VALUES ('1328','Group','28','User','15','glpi (2)','2017-08-23 18:55:54','0','','rdesktop7 (53)');
INSERT INTO `glpi_logs` VALUES ('1329','User','53','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','rdesktop7@saludpol.local (40)');
INSERT INTO `glpi_logs` VALUES ('1330','UserEmail','40','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1331','User','54','Group','15','glpi (2)','2017-08-23 18:55:54','0','','logistic16_p (28)');
INSERT INTO `glpi_logs` VALUES ('1332','Group','28','User','15','glpi (2)','2017-08-23 18:55:54','0','','rdesktop6 (54)');
INSERT INTO `glpi_logs` VALUES ('1333','User','54','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','rdesktop6@saludpol.local (41)');
INSERT INTO `glpi_logs` VALUES ('1334','UserEmail','41','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1335','User','55','Group','15','glpi (2)','2017-08-23 18:55:54','0','','logistic16_p (28)');
INSERT INTO `glpi_logs` VALUES ('1336','Group','28','User','15','glpi (2)','2017-08-23 18:55:54','0','','rdesktop5 (55)');
INSERT INTO `glpi_logs` VALUES ('1337','User','55','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','rdesktop5@saludpol.local (42)');
INSERT INTO `glpi_logs` VALUES ('1338','UserEmail','42','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1339','User','56','Group','15','glpi (2)','2017-08-23 18:55:54','0','','logistic16_p (28)');
INSERT INTO `glpi_logs` VALUES ('1340','Group','28','User','15','glpi (2)','2017-08-23 18:55:54','0','','rdesktop4 (56)');
INSERT INTO `glpi_logs` VALUES ('1341','User','56','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','rdesktop4@saludpol.local (43)');
INSERT INTO `glpi_logs` VALUES ('1342','UserEmail','43','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1343','User','57','Group','15','glpi (2)','2017-08-23 18:55:54','0','','logistic16_p (28)');
INSERT INTO `glpi_logs` VALUES ('1344','Group','28','User','15','glpi (2)','2017-08-23 18:55:54','0','','rdesktop3 (57)');
INSERT INTO `glpi_logs` VALUES ('1345','User','57','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','rdesktop3@saludpol.local (44)');
INSERT INTO `glpi_logs` VALUES ('1346','UserEmail','44','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1347','User','58','Group','15','glpi (2)','2017-08-23 18:55:54','0','','logistic16_p (28)');
INSERT INTO `glpi_logs` VALUES ('1348','Group','28','User','15','glpi (2)','2017-08-23 18:55:54','0','','rdesktop2 (58)');
INSERT INTO `glpi_logs` VALUES ('1349','User','58','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','rdesktop2@saludpol.local (45)');
INSERT INTO `glpi_logs` VALUES ('1350','UserEmail','45','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1351','User','59','Group','15','glpi (2)','2017-08-23 18:55:54','0','','logistic16_p (28)');
INSERT INTO `glpi_logs` VALUES ('1352','Group','28','User','15','glpi (2)','2017-08-23 18:55:54','0','','rdesktop1 (59)');
INSERT INTO `glpi_logs` VALUES ('1353','User','59','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','rdesktop1@saludpol.local (46)');
INSERT INTO `glpi_logs` VALUES ('1354','UserEmail','46','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1355','User','60','Group','15','glpi (2)','2017-08-23 18:55:54','0','','logistic16_p (28)');
INSERT INTO `glpi_logs` VALUES ('1356','Group','28','User','15','glpi (2)','2017-08-23 18:55:54','0','','rdesktop (60)');
INSERT INTO `glpi_logs` VALUES ('1357','User','60','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','rdesktop@saludpol.local (47)');
INSERT INTO `glpi_logs` VALUES ('1358','UserEmail','47','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1359','User','61','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','rdavilae@saludpol.local (48)');
INSERT INTO `glpi_logs` VALUES ('1360','UserEmail','48','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1361','User','62','Group','15','glpi (2)','2017-08-23 18:55:54','0','','efcp_of_pre_liq_g (13)');
INSERT INTO `glpi_logs` VALUES ('1362','Group','13','User','15','glpi (2)','2017-08-23 18:55:54','0','','Corvacho Becerra Rafael (62)');
INSERT INTO `glpi_logs` VALUES ('1363','User','62','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','rcorvachob@saludpol.local (49)');
INSERT INTO `glpi_logs` VALUES ('1364','UserEmail','49','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1365','User','63','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','ralarcong@saludpol.local (50)');
INSERT INTO `glpi_logs` VALUES ('1366','UserEmail','50','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1367','User','64','Group','15','glpi (2)','2017-08-23 18:55:54','0','','logistic16_p (28)');
INSERT INTO `glpi_logs` VALUES ('1368','Group','28','User','15','glpi (2)','2017-08-23 18:55:54','0','','programacion_g (64)');
INSERT INTO `glpi_logs` VALUES ('1369','User','65','Group','15','glpi (2)','2017-08-23 18:55:54','0','','eff_g (16)');
INSERT INTO `glpi_logs` VALUES ('1370','Group','16','User','15','glpi (2)','2017-08-23 18:55:54','0','','Zapata Jara Diana (65)');
INSERT INTO `glpi_logs` VALUES ('1371','User','65','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','prof_eff7@saludpol.local (51)');
INSERT INTO `glpi_logs` VALUES ('1372','UserEmail','51','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1373','User','66','Group','15','glpi (2)','2017-08-23 18:55:54','0','','eff_g (16)');
INSERT INTO `glpi_logs` VALUES ('1374','Group','16','User','15','glpi (2)','2017-08-23 18:55:54','0','','Sanchez Ortiz Carmen (66)');
INSERT INTO `glpi_logs` VALUES ('1375','User','66','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','prof_eff6@saludpol.local (52)');
INSERT INTO `glpi_logs` VALUES ('1376','UserEmail','52','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1377','User','67','Group','15','glpi (2)','2017-08-23 18:55:54','0','','eff_g (16)');
INSERT INTO `glpi_logs` VALUES ('1378','Group','16','User','15','glpi (2)','2017-08-23 18:55:54','0','','Figueroa Collado Jazmin (67)');
INSERT INTO `glpi_logs` VALUES ('1379','User','67','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','prof_eff5@saludpol.local (53)');
INSERT INTO `glpi_logs` VALUES ('1380','UserEmail','53','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1381','User','68','Group','15','glpi (2)','2017-08-23 18:55:54','0','','eff_g (16)');
INSERT INTO `glpi_logs` VALUES ('1382','Group','16','User','15','glpi (2)','2017-08-23 18:55:54','0','','Zavala Curzo David (68)');
INSERT INTO `glpi_logs` VALUES ('1383','User','68','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','prof_eff4@saludpol.local (54)');
INSERT INTO `glpi_logs` VALUES ('1384','UserEmail','54','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1385','User','69','Group','15','glpi (2)','2017-08-23 18:55:54','0','','eff_g (16)');
INSERT INTO `glpi_logs` VALUES ('1386','Group','16','User','15','glpi (2)','2017-08-23 18:55:54','0','','Yarasca Zegarra Christopher (69)');
INSERT INTO `glpi_logs` VALUES ('1387','User','69','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','prof_eff3@saludpol.local (55)');
INSERT INTO `glpi_logs` VALUES ('1388','UserEmail','55','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1389','User','70','Group','15','glpi (2)','2017-08-23 18:55:54','0','','eff_g (16)');
INSERT INTO `glpi_logs` VALUES ('1390','Group','16','User','15','glpi (2)','2017-08-23 18:55:54','0','','Paredes Cabel Jose (70)');
INSERT INTO `glpi_logs` VALUES ('1391','User','70','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','prof_eff2@saludpol.local (56)');
INSERT INTO `glpi_logs` VALUES ('1392','UserEmail','56','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1393','User','71','Group','15','glpi (2)','2017-08-23 18:55:54','0','','eff_g (16)');
INSERT INTO `glpi_logs` VALUES ('1394','Group','16','User','15','glpi (2)','2017-08-23 18:55:54','0','','Montalvo Chavez Ana (71)');
INSERT INTO `glpi_logs` VALUES ('1395','User','71','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','prof_eff1@saludpol.local (57)');
INSERT INTO `glpi_logs` VALUES ('1396','UserEmail','57','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1397','User','72','Group','15','glpi (2)','2017-08-23 18:55:54','0','','logistic16_p (28)');
INSERT INTO `glpi_logs` VALUES ('1398','Group','28','User','15','glpi (2)','2017-08-23 18:55:54','0','','procesos_g (72)');
INSERT INTO `glpi_logs` VALUES ('1399','User','73','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','presupuesto3@saludpol.local (58)');
INSERT INTO `glpi_logs` VALUES ('1400','UserEmail','58','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1401','User','74','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','presupuesto2@saludpol.local (59)');
INSERT INTO `glpi_logs` VALUES ('1402','UserEmail','59','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1403','User','75','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','presupuesto1@saludpol.local (60)');
INSERT INTO `glpi_logs` VALUES ('1404','UserEmail','60','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1405','User','76','Group','15','glpi (2)','2017-08-23 18:55:54','0','','efcp_of_pre_liq_g (13)');
INSERT INTO `glpi_logs` VALUES ('1406','Group','13','User','15','glpi (2)','2017-08-23 18:55:54','0','','Chavez Golles Carla (76)');
INSERT INTO `glpi_logs` VALUES ('1407','User','76','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','pre_liquidacion4@saludpol.local (61)');
INSERT INTO `glpi_logs` VALUES ('1408','UserEmail','61','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1409','User','77','Group','15','glpi (2)','2017-08-23 18:55:54','0','','efcp_g (9)');
INSERT INTO `glpi_logs` VALUES ('1410','Group','9','User','15','glpi (2)','2017-08-23 18:55:54','0','','Antay Torero Anthony (77)');
INSERT INTO `glpi_logs` VALUES ('1411','User','77','Group','15','glpi (2)','2017-08-23 18:55:54','0','','efcp_of_pre_liq_g (13)');
INSERT INTO `glpi_logs` VALUES ('1412','Group','13','User','15','glpi (2)','2017-08-23 18:55:54','0','','Antay Torero Anthony (77)');
INSERT INTO `glpi_logs` VALUES ('1413','User','77','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','pre_liquidacion3@saludpol.local (62)');
INSERT INTO `glpi_logs` VALUES ('1414','UserEmail','62','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1415','User','78','Group','15','glpi (2)','2017-08-23 18:55:54','0','','efcp_of_pre_liq_g (13)');
INSERT INTO `glpi_logs` VALUES ('1416','Group','13','User','15','glpi (2)','2017-08-23 18:55:54','0','','Benito Torres Sharon (78)');
INSERT INTO `glpi_logs` VALUES ('1417','User','78','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','pre_liquidacion2@saludpol.local (63)');
INSERT INTO `glpi_logs` VALUES ('1418','UserEmail','63','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1419','User','79','Group','15','glpi (2)','2017-08-23 18:55:54','0','','efcp_of_pre_liq_g (13)');
INSERT INTO `glpi_logs` VALUES ('1420','Group','13','User','15','glpi (2)','2017-08-23 18:55:54','0','','Egusguiza Acero Mariza (79)');
INSERT INTO `glpi_logs` VALUES ('1421','User','79','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','pre_liquidacion1@saludpol.local (64)');
INSERT INTO `glpi_logs` VALUES ('1422','UserEmail','64','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1423','User','80','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','pparedesm@saludpol.local (65)');
INSERT INTO `glpi_logs` VALUES ('1424','UserEmail','65','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1425','User','81','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','planeamiento2@saludpol.local (66)');
INSERT INTO `glpi_logs` VALUES ('1426','UserEmail','66','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1427','User','82','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','planeamiento1@saludpol.local (67)');
INSERT INTO `glpi_logs` VALUES ('1428','UserEmail','67','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1429','User','83','Group','15','glpi (2)','2017-08-23 18:55:54','0','','efcp_of_aud_med_g (11)');
INSERT INTO `glpi_logs` VALUES ('1430','Group','11','User','15','glpi (2)','2017-08-23 18:55:54','0','','Koc Castañed Pedro (83)');
INSERT INTO `glpi_logs` VALUES ('1431','User','83','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','pkocc@saludpol.local (68)');
INSERT INTO `glpi_logs` VALUES ('1432','UserEmail','68','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1433','User','84','Group','15','glpi (2)','2017-08-23 18:55:54','0','','efaj_g (8)');
INSERT INTO `glpi_logs` VALUES ('1434','Group','8','User','15','glpi (2)','2017-08-23 18:55:54','0','','Figueroa Marin Pablo Manuel (84)');
INSERT INTO `glpi_logs` VALUES ('1435','User','84','Group','15','glpi (2)','2017-08-23 18:55:54','0','','responsables_sp (33)');
INSERT INTO `glpi_logs` VALUES ('1436','Group','33','User','15','glpi (2)','2017-08-23 18:55:54','0','','Figueroa Marin Pablo Manuel (84)');
INSERT INTO `glpi_logs` VALUES ('1437','User','84','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','pfigueroa@saludpol.local (69)');
INSERT INTO `glpi_logs` VALUES ('1438','UserEmail','69','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1439','User','85','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','pecosas@saludpol.local (70)');
INSERT INTO `glpi_logs` VALUES ('1440','UserEmail','70','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1441','User','86','Group','15','glpi (2)','2017-08-23 18:55:54','0','','servicios_generales_g (35)');
INSERT INTO `glpi_logs` VALUES ('1442','Group','35','User','15','glpi (2)','2017-08-23 18:55:54','0','','Rodriguez Alegria German (86)');
INSERT INTO `glpi_logs` VALUES ('1443','User','86','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_patrimonio_2@saludpol.local (71)');
INSERT INTO `glpi_logs` VALUES ('1444','UserEmail','71','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1445','User','87','Group','15','glpi (2)','2017-08-23 18:55:54','0','','servicios_generales_g (35)');
INSERT INTO `glpi_logs` VALUES ('1446','Group','35','User','15','glpi (2)','2017-08-23 18:55:54','0','','Villacorta Bazan Roberto (87)');
INSERT INTO `glpi_logs` VALUES ('1447','User','87','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_patrimonio_1@saludpol.local (72)');
INSERT INTO `glpi_logs` VALUES ('1448','UserEmail','72','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1449','User','88','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_log_6@saludpol.local (73)');
INSERT INTO `glpi_logs` VALUES ('1450','UserEmail','73','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1451','User','89','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_log_5@saludpol.local (74)');
INSERT INTO `glpi_logs` VALUES ('1452','UserEmail','74','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1453','User','90','Group','15','glpi (2)','2017-08-23 18:55:54','0','','ejecucion_contractual_g (24)');
INSERT INTO `glpi_logs` VALUES ('1454','Group','24','User','15','glpi (2)','2017-08-23 18:55:54','0','','Asuncion Mejia Omar (90)');
INSERT INTO `glpi_logs` VALUES ('1455','User','90','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_log_45@saludpol.local (75)');
INSERT INTO `glpi_logs` VALUES ('1456','UserEmail','75','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1457','User','91','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_log_44@saludpol.local (76)');
INSERT INTO `glpi_logs` VALUES ('1458','UserEmail','76','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1459','User','92','Group','15','glpi (2)','2017-08-23 18:55:54','0','','ejecucion_contractual_g (24)');
INSERT INTO `glpi_logs` VALUES ('1460','Group','24','User','15','glpi (2)','2017-08-23 18:55:54','0','','Castro Quinto Edwin (92)');
INSERT INTO `glpi_logs` VALUES ('1461','User','92','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_log_43@saludpol.local (77)');
INSERT INTO `glpi_logs` VALUES ('1462','UserEmail','77','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1463','User','93','Group','15','glpi (2)','2017-08-23 18:55:54','0','','ejecucion_contractual_g (24)');
INSERT INTO `glpi_logs` VALUES ('1464','Group','24','User','15','glpi (2)','2017-08-23 18:55:54','0','','Tipismana Sifuentes Julissa (93)');
INSERT INTO `glpi_logs` VALUES ('1465','User','93','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_log_42@saludpol.local (78)');
INSERT INTO `glpi_logs` VALUES ('1466','UserEmail','78','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1467','User','94','Group','15','glpi (2)','2017-08-23 18:55:54','0','','actos_preparatorios_procedimiento_seleccion_g (2)');
INSERT INTO `glpi_logs` VALUES ('1468','Group','2','User','15','glpi (2)','2017-08-23 18:55:54','0','','Honores Carhuamaca Eliana (94)');
INSERT INTO `glpi_logs` VALUES ('1469','User','94','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_log_41@saludpol.local (79)');
INSERT INTO `glpi_logs` VALUES ('1470','UserEmail','79','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1471','User','95','Group','15','glpi (2)','2017-08-23 18:55:54','0','','actos_preparatorios_procedimiento_seleccion_g (2)');
INSERT INTO `glpi_logs` VALUES ('1472','Group','2','User','15','glpi (2)','2017-08-23 18:55:54','0','','Vargas Cordova Cesar (95)');
INSERT INTO `glpi_logs` VALUES ('1473','User','95','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_log_40@saludpol.local (80)');
INSERT INTO `glpi_logs` VALUES ('1474','UserEmail','80','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1475','User','96','Group','15','glpi (2)','2017-08-23 18:55:54','0','','ejecucion_contractual_g (24)');
INSERT INTO `glpi_logs` VALUES ('1476','Group','24','User','15','glpi (2)','2017-08-23 18:55:54','0','','Meza Yangali Yoselin (96)');
INSERT INTO `glpi_logs` VALUES ('1477','User','96','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_log_39@saludpol.local (81)');
INSERT INTO `glpi_logs` VALUES ('1478','UserEmail','81','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1479','User','97','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_log_36@saludpol.local (82)');
INSERT INTO `glpi_logs` VALUES ('1480','UserEmail','82','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1481','User','98','Group','15','glpi (2)','2017-08-23 18:55:54','0','','ejecucion_contractual_g (24)');
INSERT INTO `glpi_logs` VALUES ('1482','Group','24','User','15','glpi (2)','2017-08-23 18:55:54','0','','Santa Gadea Yamir (98)');
INSERT INTO `glpi_logs` VALUES ('1483','User','98','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_log_35@saludpol.local (83)');
INSERT INTO `glpi_logs` VALUES ('1484','UserEmail','83','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1485','User','99','Group','15','glpi (2)','2017-08-23 18:55:54','0','','ejecucion_contractual_g (24)');
INSERT INTO `glpi_logs` VALUES ('1486','Group','24','User','15','glpi (2)','2017-08-23 18:55:54','0','','Cardenas Herrera Marlene (99)');
INSERT INTO `glpi_logs` VALUES ('1487','User','99','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_log_34@saludpol.local (84)');
INSERT INTO `glpi_logs` VALUES ('1488','UserEmail','84','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1489','User','100','Group','15','glpi (2)','2017-08-23 18:55:54','0','','ejecucion_contractual_g (24)');
INSERT INTO `glpi_logs` VALUES ('1490','Group','24','User','15','glpi (2)','2017-08-23 18:55:54','0','','Lama Pinedo Roberto (100)');
INSERT INTO `glpi_logs` VALUES ('1491','User','100','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_log_33@saludpol.local (85)');
INSERT INTO `glpi_logs` VALUES ('1492','UserEmail','85','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1493','User','101','Group','15','glpi (2)','2017-08-23 18:55:54','0','','actos_preparatorios_procedimiento_seleccion_g (2)');
INSERT INTO `glpi_logs` VALUES ('1494','Group','2','User','15','glpi (2)','2017-08-23 18:55:54','0','','Robles Yanoc Tiberio (101)');
INSERT INTO `glpi_logs` VALUES ('1495','User','101','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_log_32@saludpol.local (86)');
INSERT INTO `glpi_logs` VALUES ('1496','UserEmail','86','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1497','User','102','Group','15','glpi (2)','2017-08-23 18:55:54','0','','ejecucion_contractual_g (24)');
INSERT INTO `glpi_logs` VALUES ('1498','Group','24','User','15','glpi (2)','2017-08-23 18:55:54','0','','Paucar Gutierrez Paola (102)');
INSERT INTO `glpi_logs` VALUES ('1499','User','102','Group','15','glpi (2)','2017-08-23 18:55:54','0','','logistic16_p (28)');
INSERT INTO `glpi_logs` VALUES ('1500','Group','28','User','15','glpi (2)','2017-08-23 18:55:54','0','','Paucar Gutierrez Paola (102)');
INSERT INTO `glpi_logs` VALUES ('1501','User','102','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_log_31@saludpol.local (87)');
INSERT INTO `glpi_logs` VALUES ('1502','UserEmail','87','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1503','User','103','Group','15','glpi (2)','2017-08-23 18:55:54','0','','ejecucion_contractual_g (24)');
INSERT INTO `glpi_logs` VALUES ('1504','Group','24','User','15','glpi (2)','2017-08-23 18:55:54','0','','Ruiz Pozo Vanessa (103)');
INSERT INTO `glpi_logs` VALUES ('1505','User','103','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_log_30@saludpol.local (88)');
INSERT INTO `glpi_logs` VALUES ('1506','UserEmail','88','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1507','User','104','Group','15','glpi (2)','2017-08-23 18:55:54','0','','logistic16_p (28)');
INSERT INTO `glpi_logs` VALUES ('1508','Group','28','User','15','glpi (2)','2017-08-23 18:55:54','0','','Murillo Chuquivilca Elisa (104)');
INSERT INTO `glpi_logs` VALUES ('1509','User','104','Group','15','glpi (2)','2017-08-23 18:55:54','0','','programacion_g (32)');
INSERT INTO `glpi_logs` VALUES ('1510','Group','32','User','15','glpi (2)','2017-08-23 18:55:54','0','','Murillo Chuquivilca Elisa (104)');
INSERT INTO `glpi_logs` VALUES ('1511','User','104','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_log_3@saludpol.local (89)');
INSERT INTO `glpi_logs` VALUES ('1512','UserEmail','89','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1513','User','105','Group','15','glpi (2)','2017-08-23 18:55:54','0','','ejecucion_contractual_g (24)');
INSERT INTO `glpi_logs` VALUES ('1514','Group','24','User','15','glpi (2)','2017-08-23 18:55:54','0','','Cornelio Mas Jackelyn (105)');
INSERT INTO `glpi_logs` VALUES ('1515','User','105','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_log_28@saludpol.local (90)');
INSERT INTO `glpi_logs` VALUES ('1516','UserEmail','90','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1517','User','106','Group','15','glpi (2)','2017-08-23 18:55:54','0','','ejecucion_contractual_g (24)');
INSERT INTO `glpi_logs` VALUES ('1518','Group','24','User','15','glpi (2)','2017-08-23 18:55:54','0','','Chuan Mendoza Mirian (106)');
INSERT INTO `glpi_logs` VALUES ('1519','User','106','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_log_26@saludpol.local (91)');
INSERT INTO `glpi_logs` VALUES ('2423','User','106','UserEmail','19','glpi (2)','2017-08-23 21:46:07','0','oper_log_26@saludpol.gob.pe (91)','');
INSERT INTO `glpi_logs` VALUES ('1521','User','107','Group','15','glpi (2)','2017-08-23 18:55:54','0','','ejecucion_contractual_g (24)');
INSERT INTO `glpi_logs` VALUES ('1522','Group','24','User','15','glpi (2)','2017-08-23 18:55:54','0','','Zapana Arapa Carlos (107)');
INSERT INTO `glpi_logs` VALUES ('1523','User','107','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_log_25@saludpol.local (92)');
INSERT INTO `glpi_logs` VALUES ('1524','UserEmail','92','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1525','User','108','Group','15','glpi (2)','2017-08-23 18:55:54','0','','ejecucion_contractual_g (24)');
INSERT INTO `glpi_logs` VALUES ('1526','Group','24','User','15','glpi (2)','2017-08-23 18:55:54','0','','Galvez Nieto Jonathan (108)');
INSERT INTO `glpi_logs` VALUES ('1527','User','108','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_log_24@saludpol.local (93)');
INSERT INTO `glpi_logs` VALUES ('1528','UserEmail','93','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1529','User','109','Group','15','glpi (2)','2017-08-23 18:55:54','0','','ejecucion_contractual_g (24)');
INSERT INTO `glpi_logs` VALUES ('1530','Group','24','User','15','glpi (2)','2017-08-23 18:55:54','0','','De Amat Perez Yanet (109)');
INSERT INTO `glpi_logs` VALUES ('1531','User','109','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_log_23@saludpol.local (94)');
INSERT INTO `glpi_logs` VALUES ('1532','UserEmail','94','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1533','User','110','Group','15','glpi (2)','2017-08-23 18:55:54','0','','ejecucion_contractual_g (24)');
INSERT INTO `glpi_logs` VALUES ('1534','Group','24','User','15','glpi (2)','2017-08-23 18:55:54','0','','Gutierrez T. Ivan (110)');
INSERT INTO `glpi_logs` VALUES ('1535','User','110','Group','15','glpi (2)','2017-08-23 18:55:54','0','','logistic16_p (28)');
INSERT INTO `glpi_logs` VALUES ('1536','Group','28','User','15','glpi (2)','2017-08-23 18:55:54','0','','Gutierrez T. Ivan (110)');
INSERT INTO `glpi_logs` VALUES ('1537','User','110','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_log_22@saludpol.local (95)');
INSERT INTO `glpi_logs` VALUES ('1538','UserEmail','95','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1539','User','111','Group','15','glpi (2)','2017-08-23 18:55:54','0','','ejecucion_contractual_g (24)');
INSERT INTO `glpi_logs` VALUES ('1540','Group','24','User','15','glpi (2)','2017-08-23 18:55:54','0','','Benites Diaz Ruth (111)');
INSERT INTO `glpi_logs` VALUES ('1541','User','111','Group','15','glpi (2)','2017-08-23 18:55:54','0','','logistic16_p (28)');
INSERT INTO `glpi_logs` VALUES ('1542','Group','28','User','15','glpi (2)','2017-08-23 18:55:54','0','','Benites Diaz Ruth (111)');
INSERT INTO `glpi_logs` VALUES ('1543','User','111','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_log_21@saludpol.local (96)');
INSERT INTO `glpi_logs` VALUES ('1544','UserEmail','96','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1545','User','112','Group','15','glpi (2)','2017-08-23 18:55:54','0','','ejecucion_contractual_g (24)');
INSERT INTO `glpi_logs` VALUES ('1546','Group','24','User','15','glpi (2)','2017-08-23 18:55:54','0','','Torres Alvarez Rocio (112)');
INSERT INTO `glpi_logs` VALUES ('1547','User','112','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_log_20@saludpol.local (97)');
INSERT INTO `glpi_logs` VALUES ('1548','UserEmail','97','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1549','User','113','Group','15','glpi (2)','2017-08-23 18:55:54','0','','Jefatura_g (27)');
INSERT INTO `glpi_logs` VALUES ('1550','Group','27','User','15','glpi (2)','2017-08-23 18:55:54','0','','Blas Mendez Mercedes (113)');
INSERT INTO `glpi_logs` VALUES ('1551','User','113','Group','15','glpi (2)','2017-08-23 18:55:54','0','','logistica_servicios_generales_g (29)');
INSERT INTO `glpi_logs` VALUES ('1552','Group','29','User','15','glpi (2)','2017-08-23 18:55:54','0','','Blas Mendez Mercedes (113)');
INSERT INTO `glpi_logs` VALUES ('1553','User','113','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_log_2@saludpol.local (98)');
INSERT INTO `glpi_logs` VALUES ('1554','UserEmail','98','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1555','User','114','Group','15','glpi (2)','2017-08-23 18:55:54','0','','ejecucion_contractual_g (24)');
INSERT INTO `glpi_logs` VALUES ('1556','Group','24','User','15','glpi (2)','2017-08-23 18:55:54','0','','Acuña Tomaylla Mercedes (114)');
INSERT INTO `glpi_logs` VALUES ('1557','User','114','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_log_18@saludpol.local (99)');
INSERT INTO `glpi_logs` VALUES ('1558','UserEmail','99','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1559','User','115','Group','15','glpi (2)','2017-08-23 18:55:54','0','','procesos_g (31)');
INSERT INTO `glpi_logs` VALUES ('1560','Group','31','User','15','glpi (2)','2017-08-23 18:55:54','0','','Farromeque Espinoza Lucia (115)');
INSERT INTO `glpi_logs` VALUES ('1561','User','115','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_log_17@saludpol.local (100)');
INSERT INTO `glpi_logs` VALUES ('1562','UserEmail','100','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1563','User','116','Group','15','glpi (2)','2017-08-23 18:55:54','0','','procesos_g (31)');
INSERT INTO `glpi_logs` VALUES ('1564','Group','31','User','15','glpi (2)','2017-08-23 18:55:54','0','','Milla Rivas Soledad (116)');
INSERT INTO `glpi_logs` VALUES ('1565','User','116','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_log_16@saludpol.local (101)');
INSERT INTO `glpi_logs` VALUES ('1566','UserEmail','101','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1567','User','117','Group','15','glpi (2)','2017-08-23 18:55:54','0','','procesos_g (31)');
INSERT INTO `glpi_logs` VALUES ('1568','Group','31','User','15','glpi (2)','2017-08-23 18:55:54','0','','Hinostroza Barrientos Mercy (117)');
INSERT INTO `glpi_logs` VALUES ('1569','User','117','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_log_15@saludpol.local (102)');
INSERT INTO `glpi_logs` VALUES ('1570','UserEmail','102','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1571','User','118','Group','15','glpi (2)','2017-08-23 18:55:54','0','','actos_preparatorios_procedimiento_seleccion_g (2)');
INSERT INTO `glpi_logs` VALUES ('1572','Group','2','User','15','glpi (2)','2017-08-23 18:55:54','0','','Villa Llanos Marlene (118)');
INSERT INTO `glpi_logs` VALUES ('1573','User','118','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_log_14@saludpol.local (103)');
INSERT INTO `glpi_logs` VALUES ('1574','UserEmail','103','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1575','User','119','Group','15','glpi (2)','2017-08-23 18:55:54','0','','actos_preparatorios_procedimiento_seleccion_g (2)');
INSERT INTO `glpi_logs` VALUES ('1576','Group','2','User','15','glpi (2)','2017-08-23 18:55:54','0','','Alarcon Leon Alexander (119)');
INSERT INTO `glpi_logs` VALUES ('1577','User','119','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_log_13@saludpol.local (104)');
INSERT INTO `glpi_logs` VALUES ('1578','UserEmail','104','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1579','User','120','Group','15','glpi (2)','2017-08-23 18:55:54','0','','actos_preparatorios_procedimiento_seleccion_g (2)');
INSERT INTO `glpi_logs` VALUES ('1580','Group','2','User','15','glpi (2)','2017-08-23 18:55:54','0','','Albujar Loza Jorge (120)');
INSERT INTO `glpi_logs` VALUES ('1581','User','120','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_log_12@saludpol.local (105)');
INSERT INTO `glpi_logs` VALUES ('1582','UserEmail','105','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1583','User','121','Group','15','glpi (2)','2017-08-23 18:55:54','0','','ejecucion_contractual_g (24)');
INSERT INTO `glpi_logs` VALUES ('1584','Group','24','User','15','glpi (2)','2017-08-23 18:55:54','0','','Huaringa Llacsa Raul (121)');
INSERT INTO `glpi_logs` VALUES ('1585','User','121','Group','15','glpi (2)','2017-08-23 18:55:54','0','','logistic16_p (28)');
INSERT INTO `glpi_logs` VALUES ('1586','Group','28','User','15','glpi (2)','2017-08-23 18:55:54','0','','Huaringa Llacsa Raul (121)');
INSERT INTO `glpi_logs` VALUES ('1587','User','121','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_log_11@saludpol.local (106)');
INSERT INTO `glpi_logs` VALUES ('1588','UserEmail','106','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1589','User','122','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_log_10@saludpol.local (107)');
INSERT INTO `glpi_logs` VALUES ('1590','UserEmail','107','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1591','User','123','Group','15','glpi (2)','2017-08-23 18:55:54','0','','Jefatura_g (27)');
INSERT INTO `glpi_logs` VALUES ('1592','Group','27','User','15','glpi (2)','2017-08-23 18:55:54','0','','Fajardo Saucedo Robert (123)');
INSERT INTO `glpi_logs` VALUES ('1593','User','123','Group','15','glpi (2)','2017-08-23 18:55:54','0','','logistica_servicios_generales_g (29)');
INSERT INTO `glpi_logs` VALUES ('1594','Group','29','User','15','glpi (2)','2017-08-23 18:55:54','0','','Fajardo Saucedo Robert (123)');
INSERT INTO `glpi_logs` VALUES ('1595','User','123','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_log_1@saludpol.local (108)');
INSERT INTO `glpi_logs` VALUES ('1596','UserEmail','108','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1597','User','124','Group','15','glpi (2)','2017-08-23 18:55:54','0','','control_previo_g (5)');
INSERT INTO `glpi_logs` VALUES ('1598','Group','5','User','15','glpi (2)','2017-08-23 18:55:54','0','','Bonifacio Nolasco Delis (124)');
INSERT INTO `glpi_logs` VALUES ('1599','User','124','Group','15','glpi (2)','2017-08-23 18:55:54','0','','sp_of_eco_con_g (38)');
INSERT INTO `glpi_logs` VALUES ('1600','Group','38','User','15','glpi (2)','2017-08-23 18:55:54','0','','Bonifacio Nolasco Delis (124)');
INSERT INTO `glpi_logs` VALUES ('1601','User','124','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_econ9@saludpol.local (109)');
INSERT INTO `glpi_logs` VALUES ('1602','UserEmail','109','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1603','User','125','Group','15','glpi (2)','2017-08-23 18:55:54','0','','control_previo_g (5)');
INSERT INTO `glpi_logs` VALUES ('1604','Group','5','User','15','glpi (2)','2017-08-23 18:55:54','0','','Trinidad Huaranga Cinthia (125)');
INSERT INTO `glpi_logs` VALUES ('1605','User','125','Group','15','glpi (2)','2017-08-23 18:55:54','0','','sp_of_eco_con_g (38)');
INSERT INTO `glpi_logs` VALUES ('1606','Group','38','User','15','glpi (2)','2017-08-23 18:55:54','0','','Trinidad Huaranga Cinthia (125)');
INSERT INTO `glpi_logs` VALUES ('1607','User','125','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_econ8@saludpol.local (110)');
INSERT INTO `glpi_logs` VALUES ('1608','UserEmail','110','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1609','User','126','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_econ7@saludpol.local (111)');
INSERT INTO `glpi_logs` VALUES ('1610','UserEmail','111','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1611','User','127','Group','15','glpi (2)','2017-08-23 18:55:54','0','','control_previo_g (5)');
INSERT INTO `glpi_logs` VALUES ('1612','Group','5','User','15','glpi (2)','2017-08-23 18:55:54','0','','Paredes Gamarra Francisco (127)');
INSERT INTO `glpi_logs` VALUES ('1613','User','127','Group','15','glpi (2)','2017-08-23 18:55:54','0','','sp_of_eco_con_g (38)');
INSERT INTO `glpi_logs` VALUES ('1614','Group','38','User','15','glpi (2)','2017-08-23 18:55:54','0','','Paredes Gamarra Francisco (127)');
INSERT INTO `glpi_logs` VALUES ('1615','User','127','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_econ6@saludpol.local (112)');
INSERT INTO `glpi_logs` VALUES ('1616','UserEmail','112','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1617','User','128','Group','15','glpi (2)','2017-08-23 18:55:54','0','','control_previo_g (5)');
INSERT INTO `glpi_logs` VALUES ('1618','Group','5','User','15','glpi (2)','2017-08-23 18:55:54','0','','Aparicio Ames Cesar (128)');
INSERT INTO `glpi_logs` VALUES ('1619','User','128','Group','15','glpi (2)','2017-08-23 18:55:54','0','','sp_of_eco_con_g (38)');
INSERT INTO `glpi_logs` VALUES ('1620','Group','38','User','15','glpi (2)','2017-08-23 18:55:54','0','','Aparicio Ames Cesar (128)');
INSERT INTO `glpi_logs` VALUES ('1621','User','128','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_econ5@saludpol.local (113)');
INSERT INTO `glpi_logs` VALUES ('1622','UserEmail','113','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1623','User','129','Group','15','glpi (2)','2017-08-23 18:55:54','0','','control_previo_g (5)');
INSERT INTO `glpi_logs` VALUES ('1624','Group','5','User','15','glpi (2)','2017-08-23 18:55:54','0','','Montes Barrantes Jose (129)');
INSERT INTO `glpi_logs` VALUES ('1625','User','129','Group','15','glpi (2)','2017-08-23 18:55:54','0','','sp_of_eco_con_g (38)');
INSERT INTO `glpi_logs` VALUES ('1626','Group','38','User','15','glpi (2)','2017-08-23 18:55:54','0','','Montes Barrantes Jose (129)');
INSERT INTO `glpi_logs` VALUES ('1627','User','129','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_econ4@saludpol.local (114)');
INSERT INTO `glpi_logs` VALUES ('1628','UserEmail','114','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1629','User','130','Group','15','glpi (2)','2017-08-23 18:55:54','0','','control_previo_g (5)');
INSERT INTO `glpi_logs` VALUES ('1630','Group','5','User','15','glpi (2)','2017-08-23 18:55:54','0','','Llaque Salas Carlos (130)');
INSERT INTO `glpi_logs` VALUES ('1631','User','130','Group','15','glpi (2)','2017-08-23 18:55:54','0','','sp_of_eco_con_g (38)');
INSERT INTO `glpi_logs` VALUES ('1632','Group','38','User','15','glpi (2)','2017-08-23 18:55:54','0','','Llaque Salas Carlos (130)');
INSERT INTO `glpi_logs` VALUES ('1633','User','130','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_econ3@saludpol.local (115)');
INSERT INTO `glpi_logs` VALUES ('1634','UserEmail','115','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1635','User','131','Group','15','glpi (2)','2017-08-23 18:55:54','0','','control_previo_g (5)');
INSERT INTO `glpi_logs` VALUES ('1636','Group','5','User','15','glpi (2)','2017-08-23 18:55:54','0','','Espinoza Pablich Jorge (131)');
INSERT INTO `glpi_logs` VALUES ('1637','User','131','Group','15','glpi (2)','2017-08-23 18:55:54','0','','sp_of_eco_con_g (38)');
INSERT INTO `glpi_logs` VALUES ('1638','Group','38','User','15','glpi (2)','2017-08-23 18:55:54','0','','Espinoza Pablich Jorge (131)');
INSERT INTO `glpi_logs` VALUES ('1639','User','131','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_econ2@saludpol.local (116)');
INSERT INTO `glpi_logs` VALUES ('1640','UserEmail','116','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1641','User','132','Group','15','glpi (2)','2017-08-23 18:55:54','0','','control_previo_g (5)');
INSERT INTO `glpi_logs` VALUES ('1642','Group','5','User','15','glpi (2)','2017-08-23 18:55:54','0','','Tinoco Gomez Elvin (132)');
INSERT INTO `glpi_logs` VALUES ('1643','User','132','Group','15','glpi (2)','2017-08-23 18:55:54','0','','sp_of_eco_con_g (38)');
INSERT INTO `glpi_logs` VALUES ('1644','Group','38','User','15','glpi (2)','2017-08-23 18:55:54','0','','Tinoco Gomez Elvin (132)');
INSERT INTO `glpi_logs` VALUES ('1645','User','132','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_econ17@saludpol.local (117)');
INSERT INTO `glpi_logs` VALUES ('1646','UserEmail','117','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1647','User','133','Group','15','glpi (2)','2017-08-23 18:55:54','0','','control_previo_g (5)');
INSERT INTO `glpi_logs` VALUES ('1648','Group','5','User','15','glpi (2)','2017-08-23 18:55:54','0','','Quinonez Alvarez Teresa (133)');
INSERT INTO `glpi_logs` VALUES ('1649','User','133','Group','15','glpi (2)','2017-08-23 18:55:54','0','','sp_of_eco_con_g (38)');
INSERT INTO `glpi_logs` VALUES ('1650','Group','38','User','15','glpi (2)','2017-08-23 18:55:54','0','','Quinonez Alvarez Teresa (133)');
INSERT INTO `glpi_logs` VALUES ('1651','User','133','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_econ16@saludpol.local (118)');
INSERT INTO `glpi_logs` VALUES ('1652','UserEmail','118','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1653','User','134','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_econ15@saludpol.local (119)');
INSERT INTO `glpi_logs` VALUES ('2426','User','134','UserEmail','19','glpi (2)','2017-08-23 21:46:07','0','oper_econ15@saludpol.gob.pe (119)','');
INSERT INTO `glpi_logs` VALUES ('1655','User','135','Group','15','glpi (2)','2017-08-23 18:55:54','0','','control_previo_g (5)');
INSERT INTO `glpi_logs` VALUES ('1656','Group','5','User','15','glpi (2)','2017-08-23 18:55:54','0','','Valentin Sotelo Jaquelin (135)');
INSERT INTO `glpi_logs` VALUES ('1657','User','135','Group','15','glpi (2)','2017-08-23 18:55:54','0','','sp_of_eco_con_g (38)');
INSERT INTO `glpi_logs` VALUES ('1658','Group','38','User','15','glpi (2)','2017-08-23 18:55:54','0','','Valentin Sotelo Jaquelin (135)');
INSERT INTO `glpi_logs` VALUES ('1659','User','135','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_econ14@saludpol.local (120)');
INSERT INTO `glpi_logs` VALUES ('1660','UserEmail','120','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1661','User','136','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_econ13@saludpol.local (121)');
INSERT INTO `glpi_logs` VALUES ('1662','UserEmail','121','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1663','User','137','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_econ12@saludpol.local (122)');
INSERT INTO `glpi_logs` VALUES ('1664','UserEmail','122','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1665','User','138','Group','15','glpi (2)','2017-08-23 18:55:54','0','','control_previo_g (5)');
INSERT INTO `glpi_logs` VALUES ('1666','Group','5','User','15','glpi (2)','2017-08-23 18:55:54','0','','Puente Martinez Nicolas (138)');
INSERT INTO `glpi_logs` VALUES ('1667','User','138','Group','15','glpi (2)','2017-08-23 18:55:54','0','','sp_of_eco_con_g (38)');
INSERT INTO `glpi_logs` VALUES ('1668','Group','38','User','15','glpi (2)','2017-08-23 18:55:54','0','','Puente Martinez Nicolas (138)');
INSERT INTO `glpi_logs` VALUES ('1669','User','138','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_econ11@saludpol.local (123)');
INSERT INTO `glpi_logs` VALUES ('1670','UserEmail','123','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1671','User','139','Group','15','glpi (2)','2017-08-23 18:55:54','0','','control_previo_g (5)');
INSERT INTO `glpi_logs` VALUES ('1672','Group','5','User','15','glpi (2)','2017-08-23 18:55:54','0','','Medina Lacerna Carlos (139)');
INSERT INTO `glpi_logs` VALUES ('1673','User','139','Group','15','glpi (2)','2017-08-23 18:55:54','0','','sp_of_eco_con_g (38)');
INSERT INTO `glpi_logs` VALUES ('1674','Group','38','User','15','glpi (2)','2017-08-23 18:55:54','0','','Medina Lacerna Carlos (139)');
INSERT INTO `glpi_logs` VALUES ('1675','User','139','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_econ10@saludpol.local (124)');
INSERT INTO `glpi_logs` VALUES ('1676','UserEmail','124','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1677','User','140','Group','15','glpi (2)','2017-08-23 18:55:54','0','','control_previo_g (5)');
INSERT INTO `glpi_logs` VALUES ('1678','Group','5','User','15','glpi (2)','2017-08-23 18:55:54','0','','Ascarza Lopez Kalinin (140)');
INSERT INTO `glpi_logs` VALUES ('1679','User','140','Group','15','glpi (2)','2017-08-23 18:55:54','0','','sp_of_eco_con_g (38)');
INSERT INTO `glpi_logs` VALUES ('1680','Group','38','User','15','glpi (2)','2017-08-23 18:55:54','0','','Ascarza Lopez Kalinin (140)');
INSERT INTO `glpi_logs` VALUES ('1681','User','140','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_econ1@saludpol.local (125)');
INSERT INTO `glpi_logs` VALUES ('1682','UserEmail','125','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1683','User','141','Group','15','glpi (2)','2017-08-23 18:55:54','0','','contabilidad_g (4)');
INSERT INTO `glpi_logs` VALUES ('1684','Group','4','User','15','glpi (2)','2017-08-23 18:55:54','0','','Pereyra Acosta Sonaly (141)');
INSERT INTO `glpi_logs` VALUES ('1685','User','141','Group','15','glpi (2)','2017-08-23 18:55:54','0','','sp_of_eco_con_g (38)');
INSERT INTO `glpi_logs` VALUES ('1686','Group','38','User','15','glpi (2)','2017-08-23 18:55:54','0','','Pereyra Acosta Sonaly (141)');
INSERT INTO `glpi_logs` VALUES ('1687','User','141','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_cont3@saludpol.local (126)');
INSERT INTO `glpi_logs` VALUES ('1688','UserEmail','126','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1689','User','142','Group','15','glpi (2)','2017-08-23 18:55:54','0','','contabilidad_g (4)');
INSERT INTO `glpi_logs` VALUES ('1690','Group','4','User','15','glpi (2)','2017-08-23 18:55:54','0','','Atoche Castillo Ernesto (142)');
INSERT INTO `glpi_logs` VALUES ('1691','User','142','Group','15','glpi (2)','2017-08-23 18:55:54','0','','sp_of_eco_con_g (38)');
INSERT INTO `glpi_logs` VALUES ('1692','Group','38','User','15','glpi (2)','2017-08-23 18:55:54','0','','Atoche Castillo Ernesto (142)');
INSERT INTO `glpi_logs` VALUES ('1693','User','142','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_cont2@saludpol.local (127)');
INSERT INTO `glpi_logs` VALUES ('1694','UserEmail','127','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1695','User','143','Group','15','glpi (2)','2017-08-23 18:55:54','0','','contabilidad_g (4)');
INSERT INTO `glpi_logs` VALUES ('1696','Group','4','User','15','glpi (2)','2017-08-23 18:55:54','0','','Atapoma Balladares Ernesto (143)');
INSERT INTO `glpi_logs` VALUES ('1697','User','143','Group','15','glpi (2)','2017-08-23 18:55:54','0','','sp_of_eco_con_g (38)');
INSERT INTO `glpi_logs` VALUES ('1698','Group','38','User','15','glpi (2)','2017-08-23 18:55:54','0','','Atapoma Balladares Ernesto (143)');
INSERT INTO `glpi_logs` VALUES ('1699','User','143','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oper_cont1@saludpol.local (128)');
INSERT INTO `glpi_logs` VALUES ('1700','UserEmail','128','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1701','User','144','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','oftic@saludpol.local (129)');
INSERT INTO `glpi_logs` VALUES ('1702','UserEmail','129','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1703','User','145','Group','15','glpi (2)','2017-08-23 18:55:54','0','','efga_w (17)');
INSERT INTO `glpi_logs` VALUES ('1704','Group','17','User','15','glpi (2)','2017-08-23 18:55:54','0','','Oliva Viguria Norma E. (145)');
INSERT INTO `glpi_logs` VALUES ('1705','User','145','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','nolivav@saludpol.local (130)');
INSERT INTO `glpi_logs` VALUES ('1706','UserEmail','130','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1707','User','146','Group','15','glpi (2)','2017-08-23 18:55:54','0','','responsables_sp (33)');
INSERT INTO `glpi_logs` VALUES ('1708','Group','33','User','15','glpi (2)','2017-08-23 18:55:54','0','','Mosqueira Lovon Nelly Rocio (146)');
INSERT INTO `glpi_logs` VALUES ('1709','User','146','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','nmosqueiral@saludpol.local (131)');
INSERT INTO `glpi_logs` VALUES ('1710','UserEmail','131','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1711','User','147','Group','15','glpi (2)','2017-08-23 18:55:54','0','','almacen_central_g (3)');
INSERT INTO `glpi_logs` VALUES ('1712','Group','3','User','15','glpi (2)','2017-08-23 18:55:54','0','','Huancaruna Mendoza Noemi (147)');
INSERT INTO `glpi_logs` VALUES ('1713','User','147','Group','15','glpi (2)','2017-08-23 18:55:54','0','','logistic16_p (28)');
INSERT INTO `glpi_logs` VALUES ('1714','Group','28','User','15','glpi (2)','2017-08-23 18:55:54','0','','Huancaruna Mendoza Noemi (147)');
INSERT INTO `glpi_logs` VALUES ('1715','User','147','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','nhuancarunam@saludpol.local (132)');
INSERT INTO `glpi_logs` VALUES ('2429','User','147','UserEmail','19','glpi (2)','2017-08-23 21:46:07','0','nhuancarunam@saludpol.gob.pe (132)','');
INSERT INTO `glpi_logs` VALUES ('1717','User','148','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','netstor@saludpol.local (133)');
INSERT INTO `glpi_logs` VALUES ('1718','UserEmail','133','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1719','User','149','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','ncoronell@saludpol.local (134)');
INSERT INTO `glpi_logs` VALUES ('1720','UserEmail','134','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1721','User','150','Group','15','glpi (2)','2017-08-23 18:55:54','0','','sp_of_eco_con_g (38)');
INSERT INTO `glpi_logs` VALUES ('1722','Group','38','User','15','glpi (2)','2017-08-23 18:55:54','0','','Zavala Siancas Mirna (150)');
INSERT INTO `glpi_logs` VALUES ('1723','User','150','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','mzavalas@saludpol.local (135)');
INSERT INTO `glpi_logs` VALUES ('1724','UserEmail','135','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1725','User','151','Group','15','glpi (2)','2017-08-23 18:55:54','0','','sp_gg_of_macro_regiones_g (37)');
INSERT INTO `glpi_logs` VALUES ('1726','Group','37','User','15','glpi (2)','2017-08-23 18:55:54','0','','Strul Farias de Sanchez Myriam (151)');
INSERT INTO `glpi_logs` VALUES ('1727','User','151','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','mstrulf@saludpol.local (136)');
INSERT INTO `glpi_logs` VALUES ('1728','UserEmail','136','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1729','User','152','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','msotomayorc@saludpol.local (137)');
INSERT INTO `glpi_logs` VALUES ('1730','UserEmail','137','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1731','User','153','Group','15','glpi (2)','2017-08-23 18:55:54','0','','responsables_sp (33)');
INSERT INTO `glpi_logs` VALUES ('1732','Group','33','User','15','glpi (2)','2017-08-23 18:55:54','0','','Silva Pinedo Maria (153)');
INSERT INTO `glpi_logs` VALUES ('1733','User','153','Group','15','glpi (2)','2017-08-23 18:55:54','0','','sp_eq_fun_adm_g (36)');
INSERT INTO `glpi_logs` VALUES ('1734','Group','36','User','15','glpi (2)','2017-08-23 18:55:54','0','','Silva Pinedo Maria (153)');
INSERT INTO `glpi_logs` VALUES ('1735','User','153','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','msilvap@saludpol.local (138)');
INSERT INTO `glpi_logs` VALUES ('1736','UserEmail','138','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1737','User','154','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','mrosasf@saludpol.local (139)');
INSERT INTO `glpi_logs` VALUES ('1738','UserEmail','139','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1739','User','155','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','mpintoy@saludpol.local (140)');
INSERT INTO `glpi_logs` VALUES ('1740','UserEmail','140','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1741','User','156','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','modernizacion1@saludpol.local (141)');
INSERT INTO `glpi_logs` VALUES ('1742','UserEmail','141','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1743','User','157','Group','15','glpi (2)','2017-08-23 18:55:54','0','','efcp_of_aud_med_g (11)');
INSERT INTO `glpi_logs` VALUES ('1744','Group','11','User','15','glpi (2)','2017-08-23 18:55:54','0','','Munoz Tello Miguel Angel (157)');
INSERT INTO `glpi_logs` VALUES ('1745','User','157','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','mmunoz@saludpol.local (142)');
INSERT INTO `glpi_logs` VALUES ('1746','UserEmail','142','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1747','User','158','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','mlara@saludpol.local (143)');
INSERT INTO `glpi_logs` VALUES ('1748','UserEmail','143','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1749','User','159','Group','15','glpi (2)','2017-08-23 18:55:54','0','','efcp_of_pre_liq_g (13)');
INSERT INTO `glpi_logs` VALUES ('1750','Group','13','User','15','glpi (2)','2017-08-23 18:55:54','0','','Egusquiza Acero Mariza Lorena (159)');
INSERT INTO `glpi_logs` VALUES ('1751','User','159','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','megusquiza@saludpol.local (144)');
INSERT INTO `glpi_logs` VALUES ('1752','UserEmail','144','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1753','User','160','Group','15','glpi (2)','2017-08-23 18:55:54','0','','sp_eq_fun_adm_g (36)');
INSERT INTO `glpi_logs` VALUES ('1754','Group','36','User','15','glpi (2)','2017-08-23 18:55:54','0','','Davila Servat Miguel (160)');
INSERT INTO `glpi_logs` VALUES ('1755','User','160','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','mdavilas@saludpol.local (145)');
INSERT INTO `glpi_logs` VALUES ('1756','UserEmail','145','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1757','User','161','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','mchiangp@saludpol.local (146)');
INSERT INTO `glpi_logs` VALUES ('1758','UserEmail','146','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1759','User','162','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','mcardenasr@saludpol.local (147)');
INSERT INTO `glpi_logs` VALUES ('1760','UserEmail','147','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1761','User','163','Group','15','glpi (2)','2017-08-23 18:55:54','0','','efrh_g (21)');
INSERT INTO `glpi_logs` VALUES ('1762','Group','21','User','15','glpi (2)','2017-08-23 18:55:54','0','','Blancas Diaz Maria (163)');
INSERT INTO `glpi_logs` VALUES ('1763','User','163','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','mblancasd@saludpol.local (148)');
INSERT INTO `glpi_logs` VALUES ('1764','UserEmail','148','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1765','User','164','Group','15','glpi (2)','2017-08-23 18:55:54','0','','ejecucion_contractual_g (24)');
INSERT INTO `glpi_logs` VALUES ('1766','Group','24','User','15','glpi (2)','2017-08-23 18:55:54','0','','Baños Diaz Maritza (164)');
INSERT INTO `glpi_logs` VALUES ('1767','User','164','Group','15','glpi (2)','2017-08-23 18:55:54','0','','logistic16_p (28)');
INSERT INTO `glpi_logs` VALUES ('1768','Group','28','User','15','glpi (2)','2017-08-23 18:55:54','0','','Baños Diaz Maritza (164)');
INSERT INTO `glpi_logs` VALUES ('1769','User','164','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','mbañosd@saludpol.local (149)');
INSERT INTO `glpi_logs` VALUES ('1770','UserEmail','149','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1771','User','165','Group','15','glpi (2)','2017-08-23 18:55:54','0','','efga_w (17)');
INSERT INTO `glpi_logs` VALUES ('1772','Group','17','User','15','glpi (2)','2017-08-23 18:55:54','0','','Barragan Pacheco Marylin Berenice (165)');
INSERT INTO `glpi_logs` VALUES ('1773','User','165','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','mbarraganp@saludpol.local (150)');
INSERT INTO `glpi_logs` VALUES ('1774','UserEmail','150','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1775','User','166','Group','15','glpi (2)','2017-08-23 18:55:54','0','','gg_of_seguros (26)');
INSERT INTO `glpi_logs` VALUES ('1776','Group','26','User','15','glpi (2)','2017-08-23 18:55:54','0','','Tello Alvarado Luz Amalia (166)');
INSERT INTO `glpi_logs` VALUES ('1777','User','166','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','ltello@saludpol.local (151)');
INSERT INTO `glpi_logs` VALUES ('1778','UserEmail','151','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1779','User','167','Group','15','glpi (2)','2017-08-23 18:55:54','0','','efaj_g (8)');
INSERT INTO `glpi_logs` VALUES ('1780','Group','8','User','15','glpi (2)','2017-08-23 18:55:54','0','','Serrano Cahuantico Luz Elena (167)');
INSERT INTO `glpi_logs` VALUES ('1781','User','167','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','lserranoc@saludpol.local (152)');
INSERT INTO `glpi_logs` VALUES ('1782','UserEmail','152','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1783','User','168','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','lreinosoc@saludpol.local (153)');
INSERT INTO `glpi_logs` VALUES ('1784','UserEmail','153','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1785','User','169','Group','15','glpi (2)','2017-08-23 18:55:54','0','','procesos_g (31)');
INSERT INTO `glpi_logs` VALUES ('1786','Group','31','User','15','glpi (2)','2017-08-23 18:55:54','0','','Pando Huaman Lilia (169)');
INSERT INTO `glpi_logs` VALUES ('1787','User','169','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','lpandoh@saludpol.local (154)');
INSERT INTO `glpi_logs` VALUES ('1788','UserEmail','154','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1789','User','172','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','lmigueld@saludpol.local (155)');
INSERT INTO `glpi_logs` VALUES ('1790','UserEmail','155','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1791','User','173','Group','15','glpi (2)','2017-08-23 18:55:54','0','','secretarias_sp (34)');
INSERT INTO `glpi_logs` VALUES ('1792','Group','34','User','15','glpi (2)','2017-08-23 18:55:54','0','','Lopez Maguña Louissy (173)');
INSERT INTO `glpi_logs` VALUES ('1793','User','173','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','llopezm@saludpol.local (156)');
INSERT INTO `glpi_logs` VALUES ('1794','UserEmail','156','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1795','User','174','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','lillescasr@saludpol.local (157)');
INSERT INTO `glpi_logs` VALUES ('1796','UserEmail','157','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1797','User','175','Group','15','glpi (2)','2017-08-23 18:55:54','0','','contabilidad_g (4)');
INSERT INTO `glpi_logs` VALUES ('1798','Group','4','User','15','glpi (2)','2017-08-23 18:55:54','0','','Huayta Bonifacio Linda Edith (175)');
INSERT INTO `glpi_logs` VALUES ('1799','User','175','Group','15','glpi (2)','2017-08-23 18:55:54','0','','sp_of_eco_con_g (38)');
INSERT INTO `glpi_logs` VALUES ('1800','Group','38','User','15','glpi (2)','2017-08-23 18:55:54','0','','Huayta Bonifacio Linda Edith (175)');
INSERT INTO `glpi_logs` VALUES ('1801','User','175','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','lhuayta@saludpol.local (158)');
INSERT INTO `glpi_logs` VALUES ('1802','UserEmail','158','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1803','User','176','Group','15','glpi (2)','2017-08-23 18:55:54','0','','efaj_g (8)');
INSERT INTO `glpi_logs` VALUES ('1804','Group','8','User','15','glpi (2)','2017-08-23 18:55:54','0','','Garcia Santos Lloy Francisco (176)');
INSERT INTO `glpi_logs` VALUES ('1805','User','176','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','lgarcias@saludpol.local (159)');
INSERT INTO `glpi_logs` VALUES ('1806','UserEmail','159','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1807','User','177','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','lescalerar@saludpol.local (160)');
INSERT INTO `glpi_logs` VALUES ('2412','User','177','UserEmail','19','','2017-08-23 19:31:23','0','lescalerar@saludpol.gob.pe (160)','');
INSERT INTO `glpi_logs` VALUES ('1809','User','178','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','lchungat@saludpol.local (161)');
INSERT INTO `glpi_logs` VALUES ('1810','UserEmail','161','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1811','User','179','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','lcardenasm@saludpol.local (162)');
INSERT INTO `glpi_logs` VALUES ('1812','UserEmail','162','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1813','User','180','Group','15','glpi (2)','2017-08-23 18:55:54','0','','efcp_of_aud_med_g (11)');
INSERT INTO `glpi_logs` VALUES ('1814','Group','11','User','15','glpi (2)','2017-08-23 18:55:54','0','','Basurto Nolasco Lenin Gustavo (180)');
INSERT INTO `glpi_logs` VALUES ('1815','User','180','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','lbasurto@saludpol.local (163)');
INSERT INTO `glpi_logs` VALUES ('1816','UserEmail','163','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1817','User','181','Group','15','glpi (2)','2017-08-23 18:55:54','0','','coordinaciones_gg (6)');
INSERT INTO `glpi_logs` VALUES ('1818','Group','6','User','15','glpi (2)','2017-08-23 18:55:54','0','','Vicente Inga Kelly Juana (181)');
INSERT INTO `glpi_logs` VALUES ('1819','User','181','Group','15','glpi (2)','2017-08-23 18:55:54','0','','efga_w (17)');
INSERT INTO `glpi_logs` VALUES ('1820','Group','17','User','15','glpi (2)','2017-08-23 18:55:54','0','','Vicente Inga Kelly Juana (181)');
INSERT INTO `glpi_logs` VALUES ('1821','User','181','Group','15','glpi (2)','2017-08-23 18:55:54','0','','secretarias_sp (34)');
INSERT INTO `glpi_logs` VALUES ('1822','Group','34','User','15','glpi (2)','2017-08-23 18:55:54','0','','Vicente Inga Kelly Juana (181)');
INSERT INTO `glpi_logs` VALUES ('1823','User','181','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','kvicentei@saludpol.local (164)');
INSERT INTO `glpi_logs` VALUES ('1824','UserEmail','164','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1825','User','182','Group','15','glpi (2)','2017-08-23 18:55:54','0','','programacion_g (32)');
INSERT INTO `glpi_logs` VALUES ('1826','Group','32','User','15','glpi (2)','2017-08-23 18:55:54','0','','Zubieta Carlos Jose (182)');
INSERT INTO `glpi_logs` VALUES ('1827','User','182','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','jzubietac@saludpol.local (165)');
INSERT INTO `glpi_logs` VALUES ('1828','UserEmail','165','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1829','User','183','Group','15','glpi (2)','2017-08-23 18:55:54','0','','logistic16_p (28)');
INSERT INTO `glpi_logs` VALUES ('1830','Group','28','User','15','glpi (2)','2017-08-23 18:55:54','0','','Valerio Vega Jesus (183)');
INSERT INTO `glpi_logs` VALUES ('1831','User','183','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','jvaleriov@saludpol.local (166)');
INSERT INTO `glpi_logs` VALUES ('1832','UserEmail','166','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1833','User','184','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','jsantistebanv@saludpol.local (167)');
INSERT INTO `glpi_logs` VALUES ('1834','UserEmail','167','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1835','User','185','Group','15','glpi (2)','2017-08-23 18:55:54','0','','efcp_gj_g (10)');
INSERT INTO `glpi_logs` VALUES ('1836','Group','10','User','15','glpi (2)','2017-08-23 18:55:54','0','','Sanchez Broncano Juan Antonio (185)');
INSERT INTO `glpi_logs` VALUES ('1837','User','185','Group','15','glpi (2)','2017-08-23 18:55:54','0','','responsables_sp (33)');
INSERT INTO `glpi_logs` VALUES ('1838','Group','33','User','15','glpi (2)','2017-08-23 18:55:54','0','','Sanchez Broncano Juan Antonio (185)');
INSERT INTO `glpi_logs` VALUES ('1839','User','185','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','jsanchezb@saludpol.local (168)');
INSERT INTO `glpi_logs` VALUES ('1840','UserEmail','168','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1841','User','186','Group','15','glpi (2)','2017-08-23 18:55:54','0','','eff_g (16)');
INSERT INTO `glpi_logs` VALUES ('1842','Group','16','User','15','glpi (2)','2017-08-23 18:55:54','0','','Ruiz Portal Jorge Armando (186)');
INSERT INTO `glpi_logs` VALUES ('1843','User','186','Group','15','glpi (2)','2017-08-23 18:55:54','0','','responsables_sp (33)');
INSERT INTO `glpi_logs` VALUES ('1844','Group','33','User','15','glpi (2)','2017-08-23 18:55:54','0','','Ruiz Portal Jorge Armando (186)');
INSERT INTO `glpi_logs` VALUES ('1845','User','186','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','jruiz@saludpol.local (169)');
INSERT INTO `glpi_logs` VALUES ('1846','UserEmail','169','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1847','User','187','Group','15','glpi (2)','2017-08-23 18:55:54','0','','control_previo_g (5)');
INSERT INTO `glpi_logs` VALUES ('1848','Group','5','User','15','glpi (2)','2017-08-23 18:55:54','0','','Montes Barrantes Jose Antonio (187)');
INSERT INTO `glpi_logs` VALUES ('1849','User','187','Group','15','glpi (2)','2017-08-23 18:55:54','0','','sp_of_eco_con_g (38)');
INSERT INTO `glpi_logs` VALUES ('1850','Group','38','User','15','glpi (2)','2017-08-23 18:55:54','0','','Montes Barrantes Jose Antonio (187)');
INSERT INTO `glpi_logs` VALUES ('1851','User','187','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','jmontes@saludpol.local (170)');
INSERT INTO `glpi_logs` VALUES ('1852','UserEmail','170','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1853','User','188','Group','15','glpi (2)','2017-08-23 18:55:54','0','','gg_of_seguros (26)');
INSERT INTO `glpi_logs` VALUES ('1854','Group','26','User','15','glpi (2)','2017-08-23 18:55:54','0','','Huarcaya Mamani Jessica (188)');
INSERT INTO `glpi_logs` VALUES ('1855','User','188','Group','15','glpi (2)','2017-08-23 18:55:54','0','','sp_gg_of_macro_regiones_g (37)');
INSERT INTO `glpi_logs` VALUES ('1856','Group','37','User','15','glpi (2)','2017-08-23 18:55:54','0','','Huarcaya Mamani Jessica (188)');
INSERT INTO `glpi_logs` VALUES ('1857','User','188','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','jhuarcayam@saludpol.local (171)');
INSERT INTO `glpi_logs` VALUES ('1858','UserEmail','171','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1859','User','189','Group','15','glpi (2)','2017-08-23 18:55:54','0','','control_previo_g (5)');
INSERT INTO `glpi_logs` VALUES ('1860','Group','5','User','15','glpi (2)','2017-08-23 18:55:54','0','','Espinoza Jorge (189)');
INSERT INTO `glpi_logs` VALUES ('1861','User','189','Group','15','glpi (2)','2017-08-23 18:55:54','0','','sp_of_eco_con_g (38)');
INSERT INTO `glpi_logs` VALUES ('1862','Group','38','User','15','glpi (2)','2017-08-23 18:55:54','0','','Espinoza Jorge (189)');
INSERT INTO `glpi_logs` VALUES ('1863','User','189','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','jespinoza@saludpol.local (172)');
INSERT INTO `glpi_logs` VALUES ('1864','UserEmail','172','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1865','User','190','Group','15','glpi (2)','2017-08-23 18:55:54','0','','almacen_central_g (3)');
INSERT INTO `glpi_logs` VALUES ('1866','Group','3','User','15','glpi (2)','2017-08-23 18:55:54','0','','Dulce Dias Javier (190)');
INSERT INTO `glpi_logs` VALUES ('1867','User','190','Group','15','glpi (2)','2017-08-23 18:55:54','0','','logistic16_p (28)');
INSERT INTO `glpi_logs` VALUES ('1868','Group','28','User','15','glpi (2)','2017-08-23 18:55:54','0','','Dulce Dias Javier (190)');
INSERT INTO `glpi_logs` VALUES ('1869','User','190','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','jdulced@saludpol.local (173)');
INSERT INTO `glpi_logs` VALUES ('1870','UserEmail','173','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1871','User','191','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','jdelgadol@saludpol.local (174)');
INSERT INTO `glpi_logs` VALUES ('1872','UserEmail','174','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1873','User','192','Group','15','glpi (2)','2017-08-23 18:55:54','0','','sp_eq_fun_adm_g (36)');
INSERT INTO `glpi_logs` VALUES ('1874','Group','36','User','15','glpi (2)','2017-08-23 18:55:54','0','','Cuzquen Quevedo Juan (192)');
INSERT INTO `glpi_logs` VALUES ('1875','User','192','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','jcuzquenq@saludpol.local (175)');
INSERT INTO `glpi_logs` VALUES ('1876','UserEmail','175','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1877','User','193','Group','15','glpi (2)','2017-08-23 18:55:54','0','','almacen_central_g (3)');
INSERT INTO `glpi_logs` VALUES ('1878','Group','3','User','15','glpi (2)','2017-08-23 18:55:54','0','','Chuquillanqui Limaylla Jorge (193)');
INSERT INTO `glpi_logs` VALUES ('1879','User','193','Group','15','glpi (2)','2017-08-23 18:55:54','0','','logistic16_p (28)');
INSERT INTO `glpi_logs` VALUES ('1880','Group','28','User','15','glpi (2)','2017-08-23 18:55:54','0','','Chuquillanqui Limaylla Jorge (193)');
INSERT INTO `glpi_logs` VALUES ('1881','User','193','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','jchuquillanquil@saludpol.local (176)');
INSERT INTO `glpi_logs` VALUES ('1882','UserEmail','176','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1883','User','194','Group','15','glpi (2)','2017-08-23 18:55:54','0','','gg_of_seguros (26)');
INSERT INTO `glpi_logs` VALUES ('1884','Group','26','User','15','glpi (2)','2017-08-23 18:55:54','0','','Agurto Chinguel Juan Miguel (194)');
INSERT INTO `glpi_logs` VALUES ('1885','User','194','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','jagurtoc@saludpol.local (177)');
INSERT INTO `glpi_logs` VALUES ('1886','UserEmail','177','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1887','User','195','Group','15','glpi (2)','2017-08-23 18:55:54','0','','coordinaciones_gg (6)');
INSERT INTO `glpi_logs` VALUES ('1888','Group','6','User','15','glpi (2)','2017-08-23 18:55:54','0','','Quispe Anchiraico Irma Silvana (195)');
INSERT INTO `glpi_logs` VALUES ('1889','User','195','Group','15','glpi (2)','2017-08-23 18:55:54','0','','gg_of_seguros (26)');
INSERT INTO `glpi_logs` VALUES ('1890','Group','26','User','15','glpi (2)','2017-08-23 18:55:54','0','','Quispe Anchiraico Irma Silvana (195)');
INSERT INTO `glpi_logs` VALUES ('1891','User','195','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','iquispe@saludpol.local (178)');
INSERT INTO `glpi_logs` VALUES ('1892','UserEmail','178','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1893','User','196','Group','15','glpi (2)','2017-08-23 18:55:54','0','','Jefatura_g (27)');
INSERT INTO `glpi_logs` VALUES ('1894','Group','27','User','15','glpi (2)','2017-08-23 18:55:54','0','','Muñoz Avellaneda Iris (196)');
INSERT INTO `glpi_logs` VALUES ('1895','User','196','Group','15','glpi (2)','2017-08-23 18:55:54','0','','logistica_servicios_generales_g (29)');
INSERT INTO `glpi_logs` VALUES ('1896','Group','29','User','15','glpi (2)','2017-08-23 18:55:54','0','','Muñoz Avellaneda Iris (196)');
INSERT INTO `glpi_logs` VALUES ('1897','User','196','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','imunoza@saludpol.local (179)');
INSERT INTO `glpi_logs` VALUES ('1898','UserEmail','179','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1899','User','197','Group','15','glpi (2)','2017-08-23 18:55:54','0','','gg_of_seguros (26)');
INSERT INTO `glpi_logs` VALUES ('1900','Group','26','User','15','glpi (2)','2017-08-23 18:55:54','0','','Leon Yurivilca Ivan Gustavo (197)');
INSERT INTO `glpi_logs` VALUES ('1901','User','197','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','ileony@saludpol.local (180)');
INSERT INTO `glpi_logs` VALUES ('1902','UserEmail','180','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1903','User','198','Group','15','glpi (2)','2017-08-23 18:55:54','0','','coordinaciones_gg (6)');
INSERT INTO `glpi_logs` VALUES ('1904','Group','6','User','15','glpi (2)','2017-08-23 18:55:54','0','','Mego Aramburu Haydee Lourdes (198)');
INSERT INTO `glpi_logs` VALUES ('1905','User','198','Group','15','glpi (2)','2017-08-23 18:55:54','0','','efrh_assist_control_g (20)');
INSERT INTO `glpi_logs` VALUES ('1906','Group','20','User','15','glpi (2)','2017-08-23 18:55:54','0','','Mego Aramburu Haydee Lourdes (198)');
INSERT INTO `glpi_logs` VALUES ('1907','User','198','Group','15','glpi (2)','2017-08-23 18:55:54','0','','efrh_g (21)');
INSERT INTO `glpi_logs` VALUES ('1908','Group','21','User','15','glpi (2)','2017-08-23 18:55:54','0','','Mego Aramburu Haydee Lourdes (198)');
INSERT INTO `glpi_logs` VALUES ('1909','User','198','Group','15','glpi (2)','2017-08-23 18:55:54','0','','secretarias_sp (34)');
INSERT INTO `glpi_logs` VALUES ('1910','Group','34','User','15','glpi (2)','2017-08-23 18:55:54','0','','Mego Aramburu Haydee Lourdes (198)');
INSERT INTO `glpi_logs` VALUES ('1911','User','198','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','hmegoa@saludpol.local (181)');
INSERT INTO `glpi_logs` VALUES ('1912','UserEmail','181','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1913','User','199','Group','15','glpi (2)','2017-08-23 18:55:54','0','','efrh_assist_control_g (20)');
INSERT INTO `glpi_logs` VALUES ('1914','Group','20','User','15','glpi (2)','2017-08-23 18:55:54','0','','Zamora Pachas Gustavo (199)');
INSERT INTO `glpi_logs` VALUES ('1915','User','199','Group','15','glpi (2)','2017-08-23 18:55:54','0','','efrh_g (21)');
INSERT INTO `glpi_logs` VALUES ('1916','Group','21','User','15','glpi (2)','2017-08-23 18:55:54','0','','Zamora Pachas Gustavo (199)');
INSERT INTO `glpi_logs` VALUES ('1917','User','199','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','gzamorap@saludpol.local (182)');
INSERT INTO `glpi_logs` VALUES ('1918','UserEmail','182','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1919','User','200','Group','15','glpi (2)','2017-08-23 18:55:54','0','','coordinaciones_gg (6)');
INSERT INTO `glpi_logs` VALUES ('1920','Group','6','User','15','glpi (2)','2017-08-23 18:55:54','0','','Quinones Quintana Graicy (200)');
INSERT INTO `glpi_logs` VALUES ('1921','User','200','Group','15','glpi (2)','2017-08-23 18:55:54','0','','gg_g (25)');
INSERT INTO `glpi_logs` VALUES ('1922','Group','25','User','15','glpi (2)','2017-08-23 18:55:54','0','','Quinones Quintana Graicy (200)');
INSERT INTO `glpi_logs` VALUES ('1923','User','200','Group','15','glpi (2)','2017-08-23 18:55:54','0','','secretarias_sp (34)');
INSERT INTO `glpi_logs` VALUES ('1924','Group','34','User','15','glpi (2)','2017-08-23 18:55:54','0','','Quinones Quintana Graicy (200)');
INSERT INTO `glpi_logs` VALUES ('1925','User','200','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','gquinonesq@saludpol.local (183)');
INSERT INTO `glpi_logs` VALUES ('1926','UserEmail','183','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1927','User','201','Group','15','glpi (2)','2017-08-23 18:55:54','0','','eff_g (16)');
INSERT INTO `glpi_logs` VALUES ('1928','Group','16','User','15','glpi (2)','2017-08-23 18:55:54','0','','Infante Lembcke Gustavo A. (201)');
INSERT INTO `glpi_logs` VALUES ('1929','User','201','Group','15','glpi (2)','2017-08-23 18:55:54','0','','responsables_sp (33)');
INSERT INTO `glpi_logs` VALUES ('1930','Group','33','User','15','glpi (2)','2017-08-23 18:55:54','0','','Infante Lembcke Gustavo A. (201)');
INSERT INTO `glpi_logs` VALUES ('1931','User','201','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','ginfantel@saludpol.local (184)');
INSERT INTO `glpi_logs` VALUES ('1932','UserEmail','184','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1933','User','202','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','giantongv@saludpol.local (185)');
INSERT INTO `glpi_logs` VALUES ('1934','UserEmail','185','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1935','User','203','Group','15','glpi (2)','2017-08-23 18:55:54','0','','coordinaciones_gg (6)');
INSERT INTO `glpi_logs` VALUES ('1936','Group','6','User','15','glpi (2)','2017-08-23 18:55:54','0','','Huamanquispe Cabana Giannina Sandra (203)');
INSERT INTO `glpi_logs` VALUES ('1937','User','203','Group','15','glpi (2)','2017-08-23 18:55:54','0','','gg_of_seguros (26)');
INSERT INTO `glpi_logs` VALUES ('1938','Group','26','User','15','glpi (2)','2017-08-23 18:55:54','0','','Huamanquispe Cabana Giannina Sandra (203)');
INSERT INTO `glpi_logs` VALUES ('1939','User','203','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','ghuamanquispec@saludpol.local (186)');
INSERT INTO `glpi_logs` VALUES ('1940','UserEmail','186','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1941','User','207','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','gfrancol@saludpol.local (187)');
INSERT INTO `glpi_logs` VALUES ('1942','UserEmail','187','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1943','User','208','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','gestor_efga4@saludpol.local (188)');
INSERT INTO `glpi_logs` VALUES ('1944','UserEmail','188','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1945','User','209','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','gestor_efga3@saludpol.local (189)');
INSERT INTO `glpi_logs` VALUES ('1946','UserEmail','189','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1947','User','210','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','gestor_efga2@saludpol.local (190)');
INSERT INTO `glpi_logs` VALUES ('1948','UserEmail','190','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1949','User','211','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','gestor_efga1@saludpol.local (191)');
INSERT INTO `glpi_logs` VALUES ('1950','UserEmail','191','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1951','User','212','Group','15','glpi (2)','2017-08-23 18:55:54','0','','coordinaciones_gg (6)');
INSERT INTO `glpi_logs` VALUES ('1952','Group','6','User','15','glpi (2)','2017-08-23 18:55:54','0','','Chirinos Zevallos Geanne M. (212)');
INSERT INTO `glpi_logs` VALUES ('1953','User','212','Group','15','glpi (2)','2017-08-23 18:55:54','0','','eff_g (16)');
INSERT INTO `glpi_logs` VALUES ('1954','Group','16','User','15','glpi (2)','2017-08-23 18:55:54','0','','Chirinos Zevallos Geanne M. (212)');
INSERT INTO `glpi_logs` VALUES ('1955','User','212','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','gchirinosz@saludpol.local (192)');
INSERT INTO `glpi_logs` VALUES ('1956','UserEmail','192','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1957','User','213','Group','15','glpi (2)','2017-08-23 18:55:54','0','','coordinaciones_gg (6)');
INSERT INTO `glpi_logs` VALUES ('1958','Group','6','User','15','glpi (2)','2017-08-23 18:55:54','0','','Chirinos Zevallos Geanne MIlagros (213)');
INSERT INTO `glpi_logs` VALUES ('1959','User','213','Group','15','glpi (2)','2017-08-23 18:55:54','0','','eff_g (16)');
INSERT INTO `glpi_logs` VALUES ('1960','Group','16','User','15','glpi (2)','2017-08-23 18:55:54','0','','Chirinos Zevallos Geanne MIlagros (213)');
INSERT INTO `glpi_logs` VALUES ('1961','User','213','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','gchirinos@saludpol.local (193)');
INSERT INTO `glpi_logs` VALUES ('1962','UserEmail','193','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1963','User','214','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','fyucras@saludpol.local (194)');
INSERT INTO `glpi_logs` VALUES ('1964','UserEmail','194','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1965','User','215','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','foxpro@saludpol.local (195)');
INSERT INTO `glpi_logs` VALUES ('1966','UserEmail','195','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1967','User','216','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','ffrancol@saludpol.local (196)');
INSERT INTO `glpi_logs` VALUES ('1968','UserEmail','196','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1969','User','217','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','fcardenasd@saludpol.local (197)');
INSERT INTO `glpi_logs` VALUES ('1970','UserEmail','197','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1971','User','218','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','ezavala@saludpol.local (198)');
INSERT INTO `glpi_logs` VALUES ('1972','UserEmail','198','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1973','User','219','Group','15','glpi (2)','2017-08-23 18:55:54','0','','efrh_g (21)');
INSERT INTO `glpi_logs` VALUES ('1974','Group','21','User','15','glpi (2)','2017-08-23 18:55:54','0','','Villafranca Valle Elizabeth (219)');
INSERT INTO `glpi_logs` VALUES ('1975','User','219','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','evillafrancav@saludpol.local (199)');
INSERT INTO `glpi_logs` VALUES ('1976','UserEmail','199','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1977','User','220','Group','15','glpi (2)','2017-08-23 18:55:54','0','','coordinaciones_gg (6)');
INSERT INTO `glpi_logs` VALUES ('1978','Group','6','User','15','glpi (2)','2017-08-23 18:55:54','0','','Torres Sanchez Edipt Wong (220)');
INSERT INTO `glpi_logs` VALUES ('1979','User','220','Group','15','glpi (2)','2017-08-23 18:55:54','0','','secretarias_sp (34)');
INSERT INTO `glpi_logs` VALUES ('1980','Group','34','User','15','glpi (2)','2017-08-23 18:55:54','0','','Torres Sanchez Edipt Wong (220)');
INSERT INTO `glpi_logs` VALUES ('1981','User','220','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','etorress@saludpol.local (200)');
INSERT INTO `glpi_logs` VALUES ('1982','UserEmail','200','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1983','User','221','Group','15','glpi (2)','2017-08-23 18:55:54','0','','almacen_central_g (3)');
INSERT INTO `glpi_logs` VALUES ('1984','Group','3','User','15','glpi (2)','2017-08-23 18:55:54','0','','Torres Perez Elizabeth (221)');
INSERT INTO `glpi_logs` VALUES ('1985','User','221','Group','15','glpi (2)','2017-08-23 18:55:54','0','','logistic16_p (28)');
INSERT INTO `glpi_logs` VALUES ('1986','Group','28','User','15','glpi (2)','2017-08-23 18:55:54','0','','Torres Perez Elizabeth (221)');
INSERT INTO `glpi_logs` VALUES ('1987','User','221','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','etorresp@saludpol.local (201)');
INSERT INTO `glpi_logs` VALUES ('1988','UserEmail','201','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1989','User','222','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','espec_oseguros3@saludpol.local (202)');
INSERT INTO `glpi_logs` VALUES ('1990','UserEmail','202','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1991','User','223','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','espec_oseguros2@saludpol.local (203)');
INSERT INTO `glpi_logs` VALUES ('1992','UserEmail','203','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1993','User','224','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','espec_oseguros1@saludpol.local (204)');
INSERT INTO `glpi_logs` VALUES ('1994','UserEmail','204','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1995','User','225','Group','15','glpi (2)','2017-08-23 18:55:54','0','','coordinaciones_gg (6)');
INSERT INTO `glpi_logs` VALUES ('1996','Group','6','User','15','glpi (2)','2017-08-23 18:55:54','0','','Salas Paz Elizabeth Emilia (225)');
INSERT INTO `glpi_logs` VALUES ('1997','User','225','Group','15','glpi (2)','2017-08-23 18:55:54','0','','eff_g (16)');
INSERT INTO `glpi_logs` VALUES ('1998','Group','16','User','15','glpi (2)','2017-08-23 18:55:54','0','','Salas Paz Elizabeth Emilia (225)');
INSERT INTO `glpi_logs` VALUES ('1999','User','225','Group','15','glpi (2)','2017-08-23 18:55:54','0','','secretarias_sp (34)');
INSERT INTO `glpi_logs` VALUES ('2000','Group','34','User','15','glpi (2)','2017-08-23 18:55:54','0','','Salas Paz Elizabeth Emilia (225)');
INSERT INTO `glpi_logs` VALUES ('2001','User','225','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','esalasp@saludpol.local (205)');
INSERT INTO `glpi_logs` VALUES ('2002','UserEmail','205','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2003','User','226','Group','15','glpi (2)','2017-08-23 18:55:54','0','','coordinaciones_gg (6)');
INSERT INTO `glpi_logs` VALUES ('2004','Group','6','User','15','glpi (2)','2017-08-23 18:55:54','0','','Riega Renteria Monica (226)');
INSERT INTO `glpi_logs` VALUES ('2005','User','226','Group','15','glpi (2)','2017-08-23 18:55:54','0','','efaj_g (8)');
INSERT INTO `glpi_logs` VALUES ('2006','Group','8','User','15','glpi (2)','2017-08-23 18:55:54','0','','Riega Renteria Monica (226)');
INSERT INTO `glpi_logs` VALUES ('2007','User','226','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','eriegar@saludpol.local (206)');
INSERT INTO `glpi_logs` VALUES ('2008','UserEmail','206','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2009','User','227','Group','15','glpi (2)','2017-08-23 18:55:54','0','','efaj_g (8)');
INSERT INTO `glpi_logs` VALUES ('2010','Group','8','User','15','glpi (2)','2017-08-23 18:55:54','0','','Monzon Melgarejo Ericka Lorena (227)');
INSERT INTO `glpi_logs` VALUES ('2011','User','227','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','emonzonm@saludpol.local (207)');
INSERT INTO `glpi_logs` VALUES ('2012','UserEmail','207','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2013','User','228','Group','15','glpi (2)','2017-08-23 18:55:54','0','','efcp_of_aud_med_g (11)');
INSERT INTO `glpi_logs` VALUES ('2014','Group','11','User','15','glpi (2)','2017-08-23 18:55:54','0','','Loarte Zorrilla Elizabeth (228)');
INSERT INTO `glpi_logs` VALUES ('2015','User','228','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','eloartez@saludpol.local (208)');
INSERT INTO `glpi_logs` VALUES ('2016','UserEmail','208','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2017','User','229','Group','15','glpi (2)','2017-08-23 18:55:54','0','','coordinaciones_gg (6)');
INSERT INTO `glpi_logs` VALUES ('2018','Group','6','User','15','glpi (2)','2017-08-23 18:55:54','0','','Loarte Zorrilla Elizabeth Pamela (229)');
INSERT INTO `glpi_logs` VALUES ('2019','User','229','Group','15','glpi (2)','2017-08-23 18:55:54','0','','efcp_of_aud_med_g (11)');
INSERT INTO `glpi_logs` VALUES ('2020','Group','11','User','15','glpi (2)','2017-08-23 18:55:54','0','','Loarte Zorrilla Elizabeth Pamela (229)');
INSERT INTO `glpi_logs` VALUES ('2021','User','229','Group','15','glpi (2)','2017-08-23 18:55:54','0','','secretarias_sp (34)');
INSERT INTO `glpi_logs` VALUES ('2022','Group','34','User','15','glpi (2)','2017-08-23 18:55:54','0','','Loarte Zorrilla Elizabeth Pamela (229)');
INSERT INTO `glpi_logs` VALUES ('2023','User','229','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','eloarte@saludpol.local (209)');
INSERT INTO `glpi_logs` VALUES ('2024','UserEmail','209','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2025','User','230','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','ejimenezs@saludpol.local (210)');
INSERT INTO `glpi_logs` VALUES ('2026','UserEmail','210','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2027','User','231','Group','15','glpi (2)','2017-08-23 18:55:54','0','','logistic16_p (28)');
INSERT INTO `glpi_logs` VALUES ('2028','Group','28','User','15','glpi (2)','2017-08-23 18:55:54','0','','ejecucion_contractual_g (231)');
INSERT INTO `glpi_logs` VALUES ('2029','User','232','Group','15','glpi (2)','2017-08-23 18:55:54','0','','sp_of_eco_con_g (38)');
INSERT INTO `glpi_logs` VALUES ('2030','Group','38','User','15','glpi (2)','2017-08-23 18:55:54','0','','Huachua Aguirre Edgar (232)');
INSERT INTO `glpi_logs` VALUES ('2031','User','232','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','ehuachuaa@saludpol.local (211)');
INSERT INTO `glpi_logs` VALUES ('2032','UserEmail','211','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2033','User','244','Group','15','glpi (2)','2017-08-23 18:55:54','0','','efcp_g (9)');
INSERT INTO `glpi_logs` VALUES ('2034','Group','9','User','15','glpi (2)','2017-08-23 18:55:54','0','','efcp_of_pre_liq_g (244)');
INSERT INTO `glpi_logs` VALUES ('2035','User','245','Group','15','glpi (2)','2017-08-23 18:55:54','0','','efcp_g (9)');
INSERT INTO `glpi_logs` VALUES ('2036','Group','9','User','15','glpi (2)','2017-08-23 18:55:54','0','','efcp_of_con_pre_g (245)');
INSERT INTO `glpi_logs` VALUES ('2037','User','246','Group','15','glpi (2)','2017-08-23 18:55:54','0','','efcp_g (9)');
INSERT INTO `glpi_logs` VALUES ('2038','Group','9','User','15','glpi (2)','2017-08-23 18:55:54','0','','efcp_of_aud_med_g (246)');
INSERT INTO `glpi_logs` VALUES ('2039','User','247','Group','15','glpi (2)','2017-08-23 18:55:54','0','','efcp_g (9)');
INSERT INTO `glpi_logs` VALUES ('2040','Group','9','User','15','glpi (2)','2017-08-23 18:55:54','0','','efcp_gj_g (247)');
INSERT INTO `glpi_logs` VALUES ('2041','User','249','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','10127025@saludpol.local (212)');
INSERT INTO `glpi_logs` VALUES ('2042','UserEmail','212','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2043','User','250','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','10602278@saludpol.local (213)');
INSERT INTO `glpi_logs` VALUES ('2044','UserEmail','213','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2045','User','251','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','10621495@saludpol.local (214)');
INSERT INTO `glpi_logs` VALUES ('2046','UserEmail','214','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2047','User','252','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','15368253@saludpol.local (215)');
INSERT INTO `glpi_logs` VALUES ('2048','UserEmail','215','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2049','User','253','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','17821503@saludpol.local (216)');
INSERT INTO `glpi_logs` VALUES ('2050','UserEmail','216','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2051','User','254','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','21401967@saludpol.local (217)');
INSERT INTO `glpi_logs` VALUES ('2052','UserEmail','217','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2053','User','255','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','21409333@saludpol.local (218)');
INSERT INTO `glpi_logs` VALUES ('2054','UserEmail','218','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2055','User','256','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','21575335@saludpol.local (219)');
INSERT INTO `glpi_logs` VALUES ('2056','UserEmail','219','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2057','User','257','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','22241340@saludpol.local (220)');
INSERT INTO `glpi_logs` VALUES ('2058','UserEmail','220','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2059','User','258','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','25830467@saludpol.local (221)');
INSERT INTO `glpi_logs` VALUES ('2060','UserEmail','221','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2061','User','259','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','30815132@saludpol.local (222)');
INSERT INTO `glpi_logs` VALUES ('2062','UserEmail','222','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2063','User','260','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','30979548@saludpol.local (223)');
INSERT INTO `glpi_logs` VALUES ('2064','UserEmail','223','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2065','User','261','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','30996752@saludpol.local (224)');
INSERT INTO `glpi_logs` VALUES ('2066','UserEmail','224','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2067','User','262','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','31018183@saludpol.local (225)');
INSERT INTO `glpi_logs` VALUES ('2068','UserEmail','225','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2069','User','263','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','31018815@saludpol.local (226)');
INSERT INTO `glpi_logs` VALUES ('2070','UserEmail','226','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2071','User','264','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','31027888@saludpol.local (227)');
INSERT INTO `glpi_logs` VALUES ('2072','UserEmail','227','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2073','User','265','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','31037372@saludpol.local (228)');
INSERT INTO `glpi_logs` VALUES ('2074','UserEmail','228','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2075','User','266','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','31038969@saludpol.local (229)');
INSERT INTO `glpi_logs` VALUES ('2076','UserEmail','229','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2077','User','267','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','31039187@saludpol.local (230)');
INSERT INTO `glpi_logs` VALUES ('2078','UserEmail','230','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2079','User','268','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','31041495@saludpol.local (231)');
INSERT INTO `glpi_logs` VALUES ('2080','UserEmail','231','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2081','User','269','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','32965320@saludpol.local (232)');
INSERT INTO `glpi_logs` VALUES ('2082','UserEmail','232','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2083','User','270','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','40266565@saludpol.local (233)');
INSERT INTO `glpi_logs` VALUES ('2084','UserEmail','233','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2085','User','271','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','40652104@saludpol.local (234)');
INSERT INTO `glpi_logs` VALUES ('2086','UserEmail','234','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2087','User','272','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','41522991@saludpol.local (235)');
INSERT INTO `glpi_logs` VALUES ('2088','UserEmail','235','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2089','User','273','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','43705759@saludpol.local (236)');
INSERT INTO `glpi_logs` VALUES ('2090','UserEmail','236','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2091','User','274','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','45313004@saludpol.local (237)');
INSERT INTO `glpi_logs` VALUES ('2092','UserEmail','237','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2093','User','275','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','45462253@saludpol.local (238)');
INSERT INTO `glpi_logs` VALUES ('2094','UserEmail','238','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2095','User','276','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','45468228@saludpol.local (239)');
INSERT INTO `glpi_logs` VALUES ('2096','UserEmail','239','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2097','User','277','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','45802179@saludpol.local (240)');
INSERT INTO `glpi_logs` VALUES ('2098','UserEmail','240','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2099','User','278','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','46009262@saludpol.local (241)');
INSERT INTO `glpi_logs` VALUES ('2100','UserEmail','241','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2101','User','279','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','46766130@saludpol.local (242)');
INSERT INTO `glpi_logs` VALUES ('2102','UserEmail','242','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2103','User','280','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','47922354@saludpol.local (243)');
INSERT INTO `glpi_logs` VALUES ('2104','UserEmail','243','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2105','User','281','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','48052773@saludpol.local (244)');
INSERT INTO `glpi_logs` VALUES ('2106','UserEmail','244','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2107','User','282','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','70125366@saludpol.local (245)');
INSERT INTO `glpi_logs` VALUES ('2108','UserEmail','245','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2109','User','283','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','71517050@saludpol.local (246)');
INSERT INTO `glpi_logs` VALUES ('2110','UserEmail','246','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2111','User','286','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','economia@saludpol.local (247)');
INSERT INTO `glpi_logs` VALUES ('2112','UserEmail','247','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2113','User','287','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','ecastilloa@saludpol.local (248)');
INSERT INTO `glpi_logs` VALUES ('2114','UserEmail','248','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2115','User','288','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','eburgav@saludpol.local (249)');
INSERT INTO `glpi_logs` VALUES ('2116','UserEmail','249','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2117','User','289','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','ebricenov@saludpol.local (250)');
INSERT INTO `glpi_logs` VALUES ('2118','UserEmail','250','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2119','User','290','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','eatoche@saludpol.local (251)');
INSERT INTO `glpi_logs` VALUES ('2120','UserEmail','251','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2121','User','291','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','dzavala@saludpol.local (252)');
INSERT INTO `glpi_logs` VALUES ('2122','UserEmail','252','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2123','User','292','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','dtrisogliod@saludpol.local (253)');
INSERT INTO `glpi_logs` VALUES ('2124','UserEmail','253','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2125','User','293','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','dtomastoa@saludpol.local (254)');
INSERT INTO `glpi_logs` VALUES ('2126','UserEmail','254','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2127','User','294','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','dmarcasr@saludpol.local (255)');
INSERT INTO `glpi_logs` VALUES ('2128','UserEmail','255','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2129','User','295','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','dgordilloi@saludpol.local (256)');
INSERT INTO `glpi_logs` VALUES ('2130','UserEmail','256','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2131','User','296','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','dfuentesl@saludpol.local (257)');
INSERT INTO `glpi_logs` VALUES ('2132','UserEmail','257','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2133','User','298','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','dev_php_2@saludpol.local (258)');
INSERT INTO `glpi_logs` VALUES ('2134','UserEmail','258','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2135','User','299','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','dev_php_1@saludpol.local (259)');
INSERT INTO `glpi_logs` VALUES ('2136','UserEmail','259','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2137','User','300','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','dcosmem@saludpol.local (260)');
INSERT INTO `glpi_logs` VALUES ('2138','UserEmail','260','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2139','User','301','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','dchacaliazah@saludpol.local (261)');
INSERT INTO `glpi_logs` VALUES ('2140','UserEmail','261','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2141','User','302','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','dbonifacio@saludpol.local (262)');
INSERT INTO `glpi_logs` VALUES ('2142','UserEmail','262','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2143','User','303','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','dalvarezc@saludpol.local (263)');
INSERT INTO `glpi_logs` VALUES ('2144','UserEmail','263','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2145','User','304','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','ctrinidad@saludpol.local (264)');
INSERT INTO `glpi_logs` VALUES ('2146','UserEmail','264','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2147','User','305','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','ctr.calidad@saludpol.local (265)');
INSERT INTO `glpi_logs` VALUES ('2148','UserEmail','265','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2149','User','306','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','ctellos@saludpol.local (266)');
INSERT INTO `glpi_logs` VALUES ('2150','UserEmail','266','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2151','User','307','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','csolarf@saludpol.local (267)');
INSERT INTO `glpi_logs` VALUES ('2152','UserEmail','267','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2153','User','308','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','csanchezp@saludpol.local (268)');
INSERT INTO `glpi_logs` VALUES ('2154','UserEmail','268','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2155','User','309','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','csaldañaz@saludpol.local (269)');
INSERT INTO `glpi_logs` VALUES ('2156','UserEmail','269','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2157','User','310','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','crodriguez@saludpol.local (270)');
INSERT INTO `glpi_logs` VALUES ('2158','UserEmail','270','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2159','User','311','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','cquispec@saludpol.local (271)');
INSERT INTO `glpi_logs` VALUES ('2160','UserEmail','271','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2161','User','313','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','coord_seniors_am@saludpol.local (272)');
INSERT INTO `glpi_logs` VALUES ('2162','UserEmail','272','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2163','User','314','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','coor_prog_2@saludpol.local (273)');
INSERT INTO `glpi_logs` VALUES ('2164','UserEmail','273','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2165','User','315','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','coor_prog_1@saludpol.local (274)');
INSERT INTO `glpi_logs` VALUES ('2166','UserEmail','274','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2167','User','316','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','coor_log_5@saludpol.local (275)');
INSERT INTO `glpi_logs` VALUES ('2168','UserEmail','275','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2169','User','317','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','coor_log_4@saludpol.local (276)');
INSERT INTO `glpi_logs` VALUES ('2170','UserEmail','276','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2171','User','318','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','coor_log_3@saludpol.local (277)');
INSERT INTO `glpi_logs` VALUES ('2172','UserEmail','277','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2173','User','319','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','coor_log_2@saludpol.local (278)');
INSERT INTO `glpi_logs` VALUES ('2174','UserEmail','278','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2175','User','320','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','coor_eco_02@saludpol.local (279)');
INSERT INTO `glpi_logs` VALUES ('2176','UserEmail','279','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2177','User','321','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','coor_eco_01@saludpol.local (280)');
INSERT INTO `glpi_logs` VALUES ('2178','UserEmail','280','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2179','User','323','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','control_previo_8@saludpol.local (281)');
INSERT INTO `glpi_logs` VALUES ('2180','UserEmail','281','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2181','User','324','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','control_previo_7@saludpol.local (282)');
INSERT INTO `glpi_logs` VALUES ('2182','UserEmail','282','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2183','User','325','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','control_previo_6@saludpol.local (283)');
INSERT INTO `glpi_logs` VALUES ('2184','UserEmail','283','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2185','User','326','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','control_previo_5@saludpol.local (284)');
INSERT INTO `glpi_logs` VALUES ('2186','UserEmail','284','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2187','User','327','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','control_previo_4@saludpol.local (285)');
INSERT INTO `glpi_logs` VALUES ('2188','UserEmail','285','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2189','User','328','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','control_previo_3@saludpol.local (286)');
INSERT INTO `glpi_logs` VALUES ('2190','UserEmail','286','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2191','User','329','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','control_previo_2@saludpol.local (287)');
INSERT INTO `glpi_logs` VALUES ('2192','UserEmail','287','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2193','User','330','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','control_previo_14@saludpol.local (288)');
INSERT INTO `glpi_logs` VALUES ('2194','UserEmail','288','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2195','User','331','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','control_previo_13@saludpol.local (289)');
INSERT INTO `glpi_logs` VALUES ('2196','UserEmail','289','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2197','User','332','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','control_previo_12@saludpol.local (290)');
INSERT INTO `glpi_logs` VALUES ('2198','UserEmail','290','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2199','User','333','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','control_previo_11@saludpol.local (291)');
INSERT INTO `glpi_logs` VALUES ('2200','UserEmail','291','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2201','User','334','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','control_previo_10@saludpol.local (292)');
INSERT INTO `glpi_logs` VALUES ('2202','UserEmail','292','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2203','User','335','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','control_previo_1@saludpol.local (293)');
INSERT INTO `glpi_logs` VALUES ('2204','UserEmail','293','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2205','User','336','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','control_prestacion_5@saludpol.local (294)');
INSERT INTO `glpi_logs` VALUES ('2206','UserEmail','294','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2207','User','337','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','control_prestacion_s@saludpol.local (295)');
INSERT INTO `glpi_logs` VALUES ('2432','User','337','UserEmail','19','glpi (2)','2017-08-23 21:46:07','0','control_prestacion_s@saludpol.gob.pe (295)','');
INSERT INTO `glpi_logs` VALUES ('2209','User','338','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','control_prestacion_8@saludpol.local (296)');
INSERT INTO `glpi_logs` VALUES ('2210','UserEmail','296','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2211','User','339','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','control_prestacion_3@saludpol.local (297)');
INSERT INTO `glpi_logs` VALUES ('2212','UserEmail','297','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2213','User','340','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','control_prestacion12@saludpol.local (298)');
INSERT INTO `glpi_logs` VALUES ('2214','UserEmail','298','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2215','User','342','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','comunicaciones@saludpol.local (299)');
INSERT INTO `glpi_logs` VALUES ('2216','UserEmail','299','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2217','User','343','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','cmantillar@saludpol.local (300)');
INSERT INTO `glpi_logs` VALUES ('2218','UserEmail','300','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2219','User','344','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','cludenat@saludpol.local (301)');
INSERT INTO `glpi_logs` VALUES ('2220','UserEmail','301','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2221','User','345','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','clinaresa@saludpol.local (302)');
INSERT INTO `glpi_logs` VALUES ('2222','UserEmail','302','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2223','User','346','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','chuamant@saludpol.local (303)');
INSERT INTO `glpi_logs` VALUES ('2224','UserEmail','303','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2225','User','347','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','cchavez@saludpol.local (304)');
INSERT INTO `glpi_logs` VALUES ('2226','UserEmail','304','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2227','User','348','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','ccardenas@saludpol.local (305)');
INSERT INTO `glpi_logs` VALUES ('2228','UserEmail','305','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2229','User','349','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','cbarretot@saludpol.local (306)');
INSERT INTO `glpi_logs` VALUES ('2230','UserEmail','306','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2231','User','350','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','caparicio@saludpol.local (307)');
INSERT INTO `glpi_logs` VALUES ('2232','UserEmail','307','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2233','User','351','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','calvarezr@saludpol.local (308)');
INSERT INTO `glpi_logs` VALUES ('2234','UserEmail','308','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2235','User','352','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','callcenter1@saludpol.local (309)');
INSERT INTO `glpi_logs` VALUES ('2236','UserEmail','309','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2237','User','353','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','calburquerquef@saludpol.local (310)');
INSERT INTO `glpi_logs` VALUES ('2238','UserEmail','310','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2239','User','354','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','bhuamanb@saludpol.local (311)');
INSERT INTO `glpi_logs` VALUES ('2240','UserEmail','311','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2241','User','355','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','auditoria_medica9@saludpol.local (312)');
INSERT INTO `glpi_logs` VALUES ('2242','UserEmail','312','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2243','User','356','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','auditoria_medica8@saludpol.local (313)');
INSERT INTO `glpi_logs` VALUES ('2244','UserEmail','313','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2245','User','357','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','auditoria_medica7@saludpol.local (314)');
INSERT INTO `glpi_logs` VALUES ('2246','UserEmail','314','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2247','User','358','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','auditoria_medica6@saludpol.local (315)');
INSERT INTO `glpi_logs` VALUES ('2248','UserEmail','315','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2249','User','359','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','auditoria_medica5@saludpol.local (316)');
INSERT INTO `glpi_logs` VALUES ('2250','UserEmail','316','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2251','User','360','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','auditoria_medica4@saludpol.local (317)');
INSERT INTO `glpi_logs` VALUES ('2252','UserEmail','317','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2253','User','361','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','auditoria_medica3@saludpol.local (318)');
INSERT INTO `glpi_logs` VALUES ('2254','UserEmail','318','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2255','User','362','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','auditoria_medica2@saludpol.local (319)');
INSERT INTO `glpi_logs` VALUES ('2256','UserEmail','319','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2257','User','363','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','auditoria_medica13@saludpol.local (320)');
INSERT INTO `glpi_logs` VALUES ('2258','UserEmail','320','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2259','User','364','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','auditoria_medica12@saludpol.local (321)');
INSERT INTO `glpi_logs` VALUES ('2260','UserEmail','321','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2261','User','365','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','auditoria_medica11@saludpol.local (322)');
INSERT INTO `glpi_logs` VALUES ('2262','UserEmail','322','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2263','User','366','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','auditoria_medica10@saludpol.local (323)');
INSERT INTO `glpi_logs` VALUES ('2264','UserEmail','323','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2265','User','367','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','auditoria_medica1@saludpol.local (324)');
INSERT INTO `glpi_logs` VALUES ('2266','UserEmail','324','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2267','User','368','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','auditoria@saludpol.local (325)');
INSERT INTO `glpi_logs` VALUES ('2268','UserEmail','325','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2269','User','369','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','auditor_efga1@saludpol.local (326)');
INSERT INTO `glpi_logs` VALUES ('2270','UserEmail','326','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2271','User','370','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','atencion_efga1@saludpol.local (327)');
INSERT INTO `glpi_logs` VALUES ('2272','UserEmail','327','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2273','User','371','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','asotob@saludpol.local (328)');
INSERT INTO `glpi_logs` VALUES ('2274','UserEmail','328','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2275','User','372','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','asistente_ti1@saludpol.local (329)');
INSERT INTO `glpi_logs` VALUES ('2276','UserEmail','329','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2277','User','373','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','asistente_ppd4@saludpol.local (330)');
INSERT INTO `glpi_logs` VALUES ('2278','UserEmail','330','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2279','User','374','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','asistente_ppd3@saludpol.local (331)');
INSERT INTO `glpi_logs` VALUES ('2280','UserEmail','331','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2281','User','375','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','asistente_ppd2@saludpol.local (332)');
INSERT INTO `glpi_logs` VALUES ('2282','UserEmail','332','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2283','User','376','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','asistente_ppd1@saludpol.local (333)');
INSERT INTO `glpi_logs` VALUES ('2284','UserEmail','333','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2285','User','377','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','asistente_gg@saludpol.local (334)');
INSERT INTO `glpi_logs` VALUES ('2286','UserEmail','334','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2287','User','378','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','asistente_efps1@saludpol.local (335)');
INSERT INTO `glpi_logs` VALUES ('2288','UserEmail','335','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2289','User','379','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','asistente_efcp@saludpol.local (336)');
INSERT INTO `glpi_logs` VALUES ('2290','UserEmail','336','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2291','User','380','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','asesor_rrhh1@saludpol.local (337)');
INSERT INTO `glpi_logs` VALUES ('2292','UserEmail','337','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2293','User','381','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','aseguramiento1@saludpol.local (338)');
INSERT INTO `glpi_logs` VALUES ('2294','UserEmail','338','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2295','User','382','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','apoyo_ssgg2@saludpol.local (339)');
INSERT INTO `glpi_logs` VALUES ('2296','UserEmail','339','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2297','User','383','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','apoyo_ssgg1@saludpol.local (340)');
INSERT INTO `glpi_logs` VALUES ('2298','UserEmail','340','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2299','User','384','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','apoyo_rrhh4@saludpol.local (341)');
INSERT INTO `glpi_logs` VALUES ('2300','UserEmail','341','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2301','User','385','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','apoyo_rrhh3@saludpol.local (342)');
INSERT INTO `glpi_logs` VALUES ('2302','UserEmail','342','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2303','User','386','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','apoyo_rrhh2@saludpol.local (343)');
INSERT INTO `glpi_logs` VALUES ('2304','UserEmail','343','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2305','User','387','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','apoyo_rrhh1@saludpol.local (344)');
INSERT INTO `glpi_logs` VALUES ('2306','UserEmail','344','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2307','User','388','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','apoyo_oseguros2@saludpol.local (345)');
INSERT INTO `glpi_logs` VALUES ('2308','UserEmail','345','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2309','User','389','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','apoyo_oseguros1@saludpol.local (346)');
INSERT INTO `glpi_logs` VALUES ('2310','UserEmail','346','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2311','User','390','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','apoyo_gg@saludpol.local (347)');
INSERT INTO `glpi_logs` VALUES ('2312','UserEmail','347','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2313','User','391','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','apoyo_efps_3@saludpol.local (348)');
INSERT INTO `glpi_logs` VALUES ('2314','UserEmail','348','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2315','User','392','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','apoyo_efps_2@saludpol.local (349)');
INSERT INTO `glpi_logs` VALUES ('2316','UserEmail','349','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2317','User','393','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','apoyo_efps_1@saludpol.local (350)');
INSERT INTO `glpi_logs` VALUES ('2318','UserEmail','350','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2319','User','394','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','apoyo_efga1@saludpol.local (351)');
INSERT INTO `glpi_logs` VALUES ('2320','UserEmail','351','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2321','User','395','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','apoyo_efa2@saludpol.local (352)');
INSERT INTO `glpi_logs` VALUES ('2322','UserEmail','352','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2323','User','396','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','apoyo_efa1@saludpol.local (353)');
INSERT INTO `glpi_logs` VALUES ('2435','User','396','UserEmail','19','glpi (2)','2017-08-23 21:46:07','0','apoyo_efa1@saludpol.gob.pe (353)','');
INSERT INTO `glpi_logs` VALUES ('2325','User','397','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','apoyo_directorio1@saludpol.local (354)');
INSERT INTO `glpi_logs` VALUES ('2326','UserEmail','354','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2327','User','398','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','apoyo_archivo1@saludpol.local (355)');
INSERT INTO `glpi_logs` VALUES ('2328','UserEmail','355','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2329','User','399','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','apoyo_adm1@saludpol.local (356)');
INSERT INTO `glpi_logs` VALUES ('2330','UserEmail','356','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2331','User','400','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','apoyo2_efetic@saludpol.local (357)');
INSERT INTO `glpi_logs` VALUES ('2332','UserEmail','357','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2333','User','401','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','analista_efga6@saludpol.local (358)');
INSERT INTO `glpi_logs` VALUES ('2334','UserEmail','358','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2335','User','402','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','analista_efga5@saludpol.local (359)');
INSERT INTO `glpi_logs` VALUES ('2336','UserEmail','359','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2337','User','403','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','analista_efga4@saludpol.local (360)');
INSERT INTO `glpi_logs` VALUES ('2338','UserEmail','360','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2339','User','404','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','analista_efga3@saludpol.local (361)');
INSERT INTO `glpi_logs` VALUES ('2340','UserEmail','361','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2341','User','405','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','analista_efga2@saludpol.local (362)');
INSERT INTO `glpi_logs` VALUES ('2342','UserEmail','362','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2343','User','406','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','analista_efga1@saludpol.local (363)');
INSERT INTO `glpi_logs` VALUES ('2344','UserEmail','363','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2345','User','407','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','amenab@saludpol.local (364)');
INSERT INTO `glpi_logs` VALUES ('2346','UserEmail','364','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2347','User','408','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','amelendezh@saludpol.local (365)');
INSERT INTO `glpi_logs` VALUES ('2348','UserEmail','365','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2349','User','410','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','almacen_central6@saludpol.local (366)');
INSERT INTO `glpi_logs` VALUES ('2350','UserEmail','366','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2351','User','411','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','almacen_central5@saludpol.local (367)');
INSERT INTO `glpi_logs` VALUES ('2352','UserEmail','367','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2353','User','412','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','almacen_central4@saludpol.local (368)');
INSERT INTO `glpi_logs` VALUES ('2354','UserEmail','368','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2355','User','413','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','almacen_central3@saludpol.local (369)');
INSERT INTO `glpi_logs` VALUES ('2356','UserEmail','369','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2357','User','414','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','almacen_central2@saludpol.local (370)');
INSERT INTO `glpi_logs` VALUES ('2438','User','414','UserEmail','19','glpi (2)','2017-08-23 21:46:07','0','almacen_central2@saludpol.gob.pe (370)','');
INSERT INTO `glpi_logs` VALUES ('2359','User','415','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','almacen_central1@saludpol.local (371)');
INSERT INTO `glpi_logs` VALUES ('2360','UserEmail','371','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2361','User','416','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','adm_eff1@saludpol.local (372)');
INSERT INTO `glpi_logs` VALUES ('2362','UserEmail','372','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2363','User','418','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','acordovam@saludpol.local (373)');
INSERT INTO `glpi_logs` VALUES ('2364','UserEmail','373','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2365','User','419','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','achineny@saludpol.local (374)');
INSERT INTO `glpi_logs` VALUES ('2366','UserEmail','374','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2367','User','420','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','abenites@saludpol.local (375)');
INSERT INTO `glpi_logs` VALUES ('2368','UserEmail','375','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2369','User','421','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','aantay@saludpol.local (376)');
INSERT INTO `glpi_logs` VALUES ('2370','UserEmail','376','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2371','User','422','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','aalcasg@saludpol.local (377)');
INSERT INTO `glpi_logs` VALUES ('2372','UserEmail','377','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2373','User','424','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','Admin@saludpol.local (378)');
INSERT INTO `glpi_logs` VALUES ('2374','UserEmail','378','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2375','User','425','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','09675655@saludpol.local (379)');
INSERT INTO `glpi_logs` VALUES ('2376','UserEmail','379','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2377','User','426','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','09614744@saludpol.local (380)');
INSERT INTO `glpi_logs` VALUES ('2378','UserEmail','380','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2379','User','427','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','09447464@saludpol.local (381)');
INSERT INTO `glpi_logs` VALUES ('2380','UserEmail','381','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2381','User','428','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','09432222@saludpol.local (382)');
INSERT INTO `glpi_logs` VALUES ('2382','UserEmail','382','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2383','User','429','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','08729715@saludpol.local (383)');
INSERT INTO `glpi_logs` VALUES ('2384','UserEmail','383','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2385','User','430','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','08173726@saludpol.local (384)');
INSERT INTO `glpi_logs` VALUES ('2386','UserEmail','384','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2387','User','431','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','08113649@saludpol.local (385)');
INSERT INTO `glpi_logs` VALUES ('2388','UserEmail','385','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2389','User','432','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','07817091@saludpol.local (386)');
INSERT INTO `glpi_logs` VALUES ('2390','UserEmail','386','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2391','User','433','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','07504518@saludpol.local (387)');
INSERT INTO `glpi_logs` VALUES ('2392','UserEmail','387','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2393','User','434','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','07309531@saludpol.local (388)');
INSERT INTO `glpi_logs` VALUES ('2394','UserEmail','388','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2395','User','435','UserEmail','17','glpi (2)','2017-08-23 18:55:54','0','','02874233@saludpol.local (389)');
INSERT INTO `glpi_logs` VALUES ('2396','UserEmail','389','0','20','glpi (2)','2017-08-23 18:55:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2397','User','436','UserEmail','17','glpi (2)','2017-08-23 18:59:18','0','','fmendoza@saludpol.local (390)');
INSERT INTO `glpi_logs` VALUES ('2409','User','436','UserEmail','19','','2017-08-23 19:15:35','0','fmendoza@saludpol.gob.pe (390)','');
INSERT INTO `glpi_logs` VALUES ('2399','User','436','Profile','17','glpi (2)','2017-08-23 18:59:18','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('2400','User','436','0','20','glpi (2)','2017-08-23 18:59:18','0','','');
INSERT INTO `glpi_logs` VALUES ('2401','Profile','3','','0','glpi (2)','2017-08-23 19:02:07','1','Admin','Administrador');
INSERT INTO `glpi_logs` VALUES ('2402','Profile','2','','0','glpi (2)','2017-08-23 19:04:17','1','Observer','Observador');
INSERT INTO `glpi_logs` VALUES ('2403','User','437','Group','15','glpi (2)','2017-08-23 19:05:35','0','','ejecucion_contractual_g (24)');
INSERT INTO `glpi_logs` VALUES ('2404','Group','24','User','15','glpi (2)','2017-08-23 19:05:35','0','','Mamani Tito Guino Welling (437)');
INSERT INTO `glpi_logs` VALUES ('2405','User','437','UserEmail','17','glpi (2)','2017-08-23 19:05:35','0','','oper_log_46@saludpol.local (391)');
INSERT INTO `glpi_logs` VALUES ('2406','UserEmail','391','0','20','glpi (2)','2017-08-23 19:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('2407','User','437','Profile','17','glpi (2)','2017-08-23 19:05:35','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('2408','User','437','0','20','glpi (2)','2017-08-23 19:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('2410','User','436','UserEmail','17','','2017-08-23 19:15:35','0','','fmendoza@saludpol.local (392)');
INSERT INTO `glpi_logs` VALUES ('2420','User','436','UserEmail','19','','2017-08-23 21:40:12','0','fmendoza@saludpol.gob.pe (392)','');
INSERT INTO `glpi_logs` VALUES ('2413','User','177','UserEmail','17','','2017-08-23 19:31:23','0','','lescalerar@saludpol.local (393)');
INSERT INTO `glpi_logs` VALUES ('2441','User','177','UserEmail','19','','2017-08-23 22:02:34','0','lescalerar@saludpol.gob.pe (393)','');
INSERT INTO `glpi_logs` VALUES ('2415','Profile','8','','0','glpi (2)','2017-08-23 19:42:56','1','Read-Only','Sólo Lectura');
INSERT INTO `glpi_logs` VALUES ('2416','Profile','6','','0','glpi (2)','2017-08-23 19:43:30','1','Technician','Técnico');
INSERT INTO `glpi_logs` VALUES ('2417','Profile','1','','0','glpi (2)','2017-08-23 19:44:51','1','Self-Service','Solicitante');
INSERT INTO `glpi_logs` VALUES ('2418','Profile','1','','0','glpi (2)','2017-08-23 19:45:05','2','helpdesk','central');
INSERT INTO `glpi_logs` VALUES ('2419','Profile','1','','0','glpi (2)','2017-08-23 19:45:32','2','central','helpdesk');
INSERT INTO `glpi_logs` VALUES ('2421','User','436','UserEmail','17','','2017-08-23 21:40:12','0','','fmendoza@saludpol.local (394)');
INSERT INTO `glpi_logs` VALUES ('2821','User','436','UserEmail','19','','2017-08-24 15:43:59','0','fmendoza@saludpol.gob.pe (394)','');
INSERT INTO `glpi_logs` VALUES ('2424','User','106','UserEmail','17','glpi (2)','2017-08-23 21:46:07','0','','oper_log_26@saludpol.local (395)');
INSERT INTO `glpi_logs` VALUES ('2425','UserEmail','395','0','20','glpi (2)','2017-08-23 21:46:07','0','','');
INSERT INTO `glpi_logs` VALUES ('2427','User','134','UserEmail','17','glpi (2)','2017-08-23 21:46:07','0','','oper_econ15@saludpol.local (396)');
INSERT INTO `glpi_logs` VALUES ('2428','UserEmail','396','0','20','glpi (2)','2017-08-23 21:46:07','0','','');
INSERT INTO `glpi_logs` VALUES ('2430','User','147','UserEmail','17','glpi (2)','2017-08-23 21:46:07','0','','nhuancarunam@saludpol.local (397)');
INSERT INTO `glpi_logs` VALUES ('2431','UserEmail','397','0','20','glpi (2)','2017-08-23 21:46:07','0','','');
INSERT INTO `glpi_logs` VALUES ('2433','User','337','UserEmail','17','glpi (2)','2017-08-23 21:46:07','0','','control_prestacion_s@saludpol.local (398)');
INSERT INTO `glpi_logs` VALUES ('2434','UserEmail','398','0','20','glpi (2)','2017-08-23 21:46:07','0','','');
INSERT INTO `glpi_logs` VALUES ('2436','User','396','UserEmail','17','glpi (2)','2017-08-23 21:46:07','0','','apoyo_efa1@saludpol.local (399)');
INSERT INTO `glpi_logs` VALUES ('2437','UserEmail','399','0','20','glpi (2)','2017-08-23 21:46:07','0','','');
INSERT INTO `glpi_logs` VALUES ('2439','User','414','UserEmail','17','glpi (2)','2017-08-23 21:46:07','0','','almacen_central2@saludpol.local (400)');
INSERT INTO `glpi_logs` VALUES ('2440','UserEmail','400','0','20','glpi (2)','2017-08-23 21:46:07','0','','');
INSERT INTO `glpi_logs` VALUES ('2442','User','177','UserEmail','17','','2017-08-23 22:02:34','0','','lescalerar@saludpol.local (401)');
INSERT INTO `glpi_logs` VALUES ('2443','UserEmail','401','0','20','','2017-08-23 22:02:34','0','','');
INSERT INTO `glpi_logs` VALUES ('2444','Document','2','0','20','Escalera Requejo Luis (177)','2017-08-23 22:09:49','0','','');
INSERT INTO `glpi_logs` VALUES ('2445','Document','2','Ticket','15','Escalera Requejo Luis (177)','2017-08-23 22:09:49','0','','SE COLGÓ LA PC (2)');
INSERT INTO `glpi_logs` VALUES ('2446','Ticket','2','Document','15','Escalera Requejo Luis (177)','2017-08-23 22:09:49','0','','Incidente del Documento 2 (2)');
INSERT INTO `glpi_logs` VALUES ('2447','Ticket','2','User','15','Escalera Requejo Luis (177)','2017-08-23 22:09:49','0','','Escalera Requejo Luis (177)');
INSERT INTO `glpi_logs` VALUES ('2448','Ticket','2','User','15','Escalera Requejo Luis (177)','2017-08-23 22:09:49','0','','normal (5)');
INSERT INTO `glpi_logs` VALUES ('2449','Ticket','2','User','15','Escalera Requejo Luis (177)','2017-08-23 22:09:49','0','','efetic_comunicaciones (243)');
INSERT INTO `glpi_logs` VALUES ('2450','Ticket','2','User','15','Escalera Requejo Luis (177)','2017-08-23 22:09:49','0','','contabilidad_g (341)');
INSERT INTO `glpi_logs` VALUES ('2451','Ticket','2','User','15','Escalera Requejo Luis (177)','2017-08-23 22:09:49','0','','coordinaciones_gg (312)');
INSERT INTO `glpi_logs` VALUES ('2452','Ticket','2','User','15','Escalera Requejo Luis (177)','2017-08-23 22:09:49','0','','efetic_estadistica (242)');
INSERT INTO `glpi_logs` VALUES ('2453','Ticket','2','0','20','Escalera Requejo Luis (177)','2017-08-23 22:09:49','0','','');
INSERT INTO `glpi_logs` VALUES ('2454','Ticket','3','User','15','Mendoza Martel Francisco Jesus (436)','2017-08-23 22:21:36','0','','Mendoza Martel Francisco Jesus (436)');
INSERT INTO `glpi_logs` VALUES ('2455','Ticket','3','0','20','Mendoza Martel Francisco Jesus (436)','2017-08-23 22:21:36','0','','');
INSERT INTO `glpi_logs` VALUES ('2456','User','438','Profile','17','glpi (2)','2017-08-23 22:23:10','0','','Super-Admin (4)');
INSERT INTO `glpi_logs` VALUES ('2457','User','438','0','20','glpi (2)','2017-08-23 22:23:10','0','','');
INSERT INTO `glpi_logs` VALUES ('2458','Document','1','Ticket','15','Mendoza Martel Francisco Jesus (436)','2017-08-23 16:59:54','0','','PRUEBA DE INCIDENTE 2 (4)');
INSERT INTO `glpi_logs` VALUES ('2459','Ticket','4','Document','15','Mendoza Martel Francisco Jesus (436)','2017-08-23 16:59:54','0','','Incidente del Documento 1 (1)');
INSERT INTO `glpi_logs` VALUES ('2460','Ticket','4','User','15','Mendoza Martel Francisco Jesus (436)','2017-08-23 16:59:54','0','','Mendoza Martel Francisco Jesus (436)');
INSERT INTO `glpi_logs` VALUES ('2461','Ticket','4','0','20','Mendoza Martel Francisco Jesus (436)','2017-08-23 16:59:54','0','','');
INSERT INTO `glpi_logs` VALUES ('2462','Ticket','2','','0','Escalera Requejo Luis (177)','2017-08-23 17:04:36','21','&lt;p&gt;PROBLEMAS DE LENTITUD AL INICIAR, CONGELAMIENTO DE PANTALLA AZUL&lt;/p&gt;&lt;p&gt;REINICIÉ Y NO ENCIENDE LA PC&lt;/p&gt;&lt;p&gt;FAVOR, ATENDER URGENTE&lt;/p&gt;','&lt;p&gt;PROBLEMAS DE LENTITUD AL INICIAR, CONGELAMIENTO DE PANTALLA AZUL&lt;/p&gt;n&lt;p&gt;REINICIÉ Y NO ENCIENDE LA PC&lt;/p&gt;n&lt;p&gt;FAVOR, ATENDER URGENTE&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('2463','User','436','Profile','17','','2017-08-23 17:13:09','0','','Solicitante (1)');
INSERT INTO `glpi_logs` VALUES ('2464','User','436','Profile','19','','2017-08-23 17:13:09','0','Técnico (6)','');
INSERT INTO `glpi_logs` VALUES ('2465','User','177','','0','Administrador Administrador (438)','2017-08-23 17:13:37','20','&nbsp; (0)','Técnico (6)');
INSERT INTO `glpi_logs` VALUES ('2466','User','436','','0','Administrador Administrador (438)','2017-08-23 17:16:38','20','&nbsp; (0)','Solicitante (1)');
INSERT INTO `glpi_logs` VALUES ('2467','User','436','Profile','17','','2017-08-23 17:23:45','0','','Solicitante (1)');
INSERT INTO `glpi_logs` VALUES ('2468','User','436','Profile','19','','2017-08-23 17:23:45','0','Técnico (6)','');
INSERT INTO `glpi_logs` VALUES ('2469','User','436','Profile','17','','2017-08-23 17:27:10','0','','Solicitante (1)');
INSERT INTO `glpi_logs` VALUES ('2470','User','436','Profile','19','','2017-08-23 17:27:10','0','Técnico (6)','');
INSERT INTO `glpi_logs` VALUES ('2471','User','4','','0','glpi (2)','2017-08-23 17:30:26','1','tech','tech1');
INSERT INTO `glpi_logs` VALUES ('2472','User','4','','0','glpi (2)','2017-08-23 17:31:33','34','','Mantilla Rios');
INSERT INTO `glpi_logs` VALUES ('2473','User','4','','0','glpi (2)','2017-08-23 17:31:33','9','','Cesar Augusto');
INSERT INTO `glpi_logs` VALUES ('2474','User','4','UserEmail','17','glpi (2)','2017-08-23 17:31:33','0','','cmantillar@saludpol.gob.pe (402)');
INSERT INTO `glpi_logs` VALUES ('2475','UserEmail','402','0','20','glpi (2)','2017-08-23 17:31:33','0','','');
INSERT INTO `glpi_logs` VALUES ('2476','User','4','','0','','2017-08-23 17:32:03','15','0','1');
INSERT INTO `glpi_logs` VALUES ('2477','Ticket','3','','0','Mantilla Rios Cesar Augusto (4)','2017-08-23 17:33:00','150','0','1');
INSERT INTO `glpi_logs` VALUES ('2478','Ticket','3','','0','Mantilla Rios Cesar Augusto (4)','2017-08-23 17:33:00','64','fmendoza (436)','tech1 (4)');
INSERT INTO `glpi_logs` VALUES ('2479','Ticket','3','User','15','Mantilla Rios Cesar Augusto (4)','2017-08-23 17:33:00','0','','Mantilla Rios Cesar Augusto (4)');
INSERT INTO `glpi_logs` VALUES ('2480','Ticket','3','','0','Mantilla Rios Cesar Augusto (4)','2017-08-23 17:33:00','12','1','2');
INSERT INTO `glpi_logs` VALUES ('2481','Ticket','3','','0','Mantilla Rios Cesar Augusto (4)','2017-08-23 17:33:00','64','fmendoza (436)','tech1 (4)');
INSERT INTO `glpi_logs` VALUES ('2482','Ticket','3','','0','Mendoza Martel Francisco Jesus (436)','2017-08-23 17:34:11','64','tech1 (4)','fmendoza (436)');
INSERT INTO `glpi_logs` VALUES ('2483','Ticket','3','','0','Mantilla Rios Cesar Augusto (4)','2017-08-23 17:35:26','24','','&lt;p&gt;SE RESOLVIO DE LA SIGUIENTE MANERA BLAH BLAH BLAH&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('2484','Ticket','3','','0','Mantilla Rios Cesar Augusto (4)','2017-08-23 17:35:26','64','fmendoza (436)','tech1 (4)');
INSERT INTO `glpi_logs` VALUES ('2485','Ticket','3','','0','Mantilla Rios Cesar Augusto (4)','2017-08-23 17:35:26','12','2','6');
INSERT INTO `glpi_logs` VALUES ('2486','Ticket','3','','0','Mantilla Rios Cesar Augusto (4)','2017-08-23 17:35:26','16','','2017-08-23 22:21:36');
INSERT INTO `glpi_logs` VALUES ('2487','Ticket','3','','0','Mantilla Rios Cesar Augusto (4)','2017-08-23 17:35:26','17','','2017-08-23 22:21:36');
INSERT INTO `glpi_logs` VALUES ('2488','Ticket','1','','0','Mantilla Rios Cesar Augusto (4)','2017-08-23 17:46:48','24','','&lt;p&gt;RESOLUCIÓN DEL PROBLEMA CON MI PC&lt;/p&gt;rn&lt;p&gt; &lt;/p&gt;rn&lt;p&gt; &lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('2489','Ticket','1','','0','Mantilla Rios Cesar Augusto (4)','2017-08-23 17:46:48','64','tester (6)','tech1 (4)');
INSERT INTO `glpi_logs` VALUES ('2490','Ticket','1','','0','Mantilla Rios Cesar Augusto (4)','2017-08-23 17:46:48','12','1','6');
INSERT INTO `glpi_logs` VALUES ('2491','Ticket','1','','0','Mantilla Rios Cesar Augusto (4)','2017-08-23 17:46:48','16','','2017-08-23 17:46:48');
INSERT INTO `glpi_logs` VALUES ('2492','Ticket','1','','0','Mantilla Rios Cesar Augusto (4)','2017-08-23 17:46:48','17','','2017-08-23 17:46:48');
INSERT INTO `glpi_logs` VALUES ('2493','Ticket','4','','0','glpi (2)','2017-08-23 17:48:44','24','','&lt;p&gt;TEXTO DE SOLUCION&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('2494','Ticket','4','','0','glpi (2)','2017-08-23 17:48:44','64','fmendoza (436)','glpi (2)');
INSERT INTO `glpi_logs` VALUES ('2495','Ticket','4','','0','glpi (2)','2017-08-23 17:48:44','12','1','6');
INSERT INTO `glpi_logs` VALUES ('2496','Ticket','4','','0','glpi (2)','2017-08-23 17:48:44','16','','2017-08-23 17:48:44');
INSERT INTO `glpi_logs` VALUES ('2497','Ticket','4','','0','glpi (2)','2017-08-23 17:48:44','17','','2017-08-23 17:48:44');
INSERT INTO `glpi_logs` VALUES ('2498','Group','40','0','20','Administrador Administrador (438)','2017-08-24 10:07:40','0','','');
INSERT INTO `glpi_logs` VALUES ('2499','ITILCategory','1','0','20','Administrador Administrador (438)','2017-08-24 10:08:11','0','','');
INSERT INTO `glpi_logs` VALUES ('2500','ITILCategory','2','0','20','Administrador Administrador (438)','2017-08-24 10:08:41','0','','');
INSERT INTO `glpi_logs` VALUES ('2501','ITILCategory','3','0','20','Administrador Administrador (438)','2017-08-24 10:09:02','0','','');
INSERT INTO `glpi_logs` VALUES ('2502','ITILCategory','1','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:03:43','0','','N/A');
INSERT INTO `glpi_logs` VALUES ('2524','ITILCategory','1','ITILCategory','19','Administrador Administrador (438)','2017-08-24 11:06:21','0','N/A','');
INSERT INTO `glpi_logs` VALUES ('2504','ITILCategory','1','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:04:30','0','','Aplicativos');
INSERT INTO `glpi_logs` VALUES ('2505','ITILCategory','5','0','20','Administrador Administrador (438)','2017-08-24 11:04:30','0','','');
INSERT INTO `glpi_logs` VALUES ('2506','ITILCategory','1','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:04:39','0','','Gestión de datos');
INSERT INTO `glpi_logs` VALUES ('2507','ITILCategory','6','0','20','Administrador Administrador (438)','2017-08-24 11:04:39','0','','');
INSERT INTO `glpi_logs` VALUES ('2508','ITILCategory','1','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:04:48','0','','Gestión de usuarios');
INSERT INTO `glpi_logs` VALUES ('2509','ITILCategory','7','0','20','Administrador Administrador (438)','2017-08-24 11:04:48','0','','');
INSERT INTO `glpi_logs` VALUES ('2510','ITILCategory','1','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:04:55','0','','Correos');
INSERT INTO `glpi_logs` VALUES ('2511','ITILCategory','8','0','20','Administrador Administrador (438)','2017-08-24 11:04:55','0','','');
INSERT INTO `glpi_logs` VALUES ('2512','ITILCategory','1','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:05:02','0','','Equipo de cómputo');
INSERT INTO `glpi_logs` VALUES ('2513','ITILCategory','9','0','20','Administrador Administrador (438)','2017-08-24 11:05:02','0','','');
INSERT INTO `glpi_logs` VALUES ('2514','ITILCategory','1','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:05:19','0','','Impresoras');
INSERT INTO `glpi_logs` VALUES ('2515','ITILCategory','10','0','20','Administrador Administrador (438)','2017-08-24 11:05:19','0','','');
INSERT INTO `glpi_logs` VALUES ('2516','ITILCategory','1','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:05:25','0','','Internet');
INSERT INTO `glpi_logs` VALUES ('2517','ITILCategory','11','0','20','Administrador Administrador (438)','2017-08-24 11:05:25','0','','');
INSERT INTO `glpi_logs` VALUES ('2518','ITILCategory','1','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:05:29','0','','Red local');
INSERT INTO `glpi_logs` VALUES ('2519','ITILCategory','12','0','20','Administrador Administrador (438)','2017-08-24 11:05:29','0','','');
INSERT INTO `glpi_logs` VALUES ('2520','ITILCategory','1','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:05:33','0','','Sistema operativo');
INSERT INTO `glpi_logs` VALUES ('2521','ITILCategory','13','0','20','Administrador Administrador (438)','2017-08-24 11:05:33','0','','');
INSERT INTO `glpi_logs` VALUES ('2522','ITILCategory','1','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:05:38','0','','Telefonía');
INSERT INTO `glpi_logs` VALUES ('2523','ITILCategory','14','0','20','Administrador Administrador (438)','2017-08-24 11:05:38','0','','');
INSERT INTO `glpi_logs` VALUES ('2525','ITILCategory','1','','0','Administrador Administrador (438)','2017-08-24 11:13:31','14','Hardware','Hardware1');
INSERT INTO `glpi_logs` VALUES ('2526','ITILCategory','1','','0','Administrador Administrador (438)','2017-08-24 11:13:31','1','Hardware','Hardware1');
INSERT INTO `glpi_logs` VALUES ('2527','ITILCategory','1','','0','Administrador Administrador (438)','2017-08-24 11:13:43','14','Hardware1','Hardware');
INSERT INTO `glpi_logs` VALUES ('2528','ITILCategory','1','','0','Administrador Administrador (438)','2017-08-24 11:13:43','1','Hardware1','Hardware');
INSERT INTO `glpi_logs` VALUES ('2529','ITILCategory','5','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:15:24','0','','N/A');
INSERT INTO `glpi_logs` VALUES ('2533','ITILCategory','5','ITILCategory','19','Administrador Administrador (438)','2017-08-24 11:16:24','0','N/A','');
INSERT INTO `glpi_logs` VALUES ('2531','ITILCategory','5','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:15:28','0','','Sistema Operativo Windows');
INSERT INTO `glpi_logs` VALUES ('2532','ITILCategory','16','0','20','Administrador Administrador (438)','2017-08-24 11:15:28','0','','');
INSERT INTO `glpi_logs` VALUES ('2534','ITILCategory','5','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:17:39','0','','Microsoft Office');
INSERT INTO `glpi_logs` VALUES ('2535','ITILCategory','17','0','20','Administrador Administrador (438)','2017-08-24 11:17:39','0','','');
INSERT INTO `glpi_logs` VALUES ('2536','ITILCategory','5','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:17:47','0','','Antivirus');
INSERT INTO `glpi_logs` VALUES ('2537','ITILCategory','18','0','20','Administrador Administrador (438)','2017-08-24 11:17:47','0','','');
INSERT INTO `glpi_logs` VALUES ('2538','ITILCategory','5','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:18:17','0','','PDF');
INSERT INTO `glpi_logs` VALUES ('2539','ITILCategory','19','0','20','Administrador Administrador (438)','2017-08-24 11:18:17','0','','');
INSERT INTO `glpi_logs` VALUES ('2540','ITILCategory','5','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:18:26','0','','Otros');
INSERT INTO `glpi_logs` VALUES ('2541','ITILCategory','20','0','20','Administrador Administrador (438)','2017-08-24 11:18:26','0','','');
INSERT INTO `glpi_logs` VALUES ('2542','ITILCategory','6','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:18:52','0','','Copias de seguridad Usuario PC');
INSERT INTO `glpi_logs` VALUES ('2543','ITILCategory','21','0','20','Administrador Administrador (438)','2017-08-24 11:18:52','0','','');
INSERT INTO `glpi_logs` VALUES ('2544','ITILCategory','6','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:18:59','0','','Creación de carpetas compartidas');
INSERT INTO `glpi_logs` VALUES ('2545','ITILCategory','22','0','20','Administrador Administrador (438)','2017-08-24 11:18:59','0','','');
INSERT INTO `glpi_logs` VALUES ('2546','ITILCategory','6','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:19:05','0','','Recuperación de archivos borrados');
INSERT INTO `glpi_logs` VALUES ('2547','ITILCategory','23','0','20','Administrador Administrador (438)','2017-08-24 11:19:05','0','','');
INSERT INTO `glpi_logs` VALUES ('2548','ITILCategory','7','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:20:16','0','','Usuario de red y clave');
INSERT INTO `glpi_logs` VALUES ('2549','ITILCategory','24','0','20','Administrador Administrador (438)','2017-08-24 11:20:16','0','','');
INSERT INTO `glpi_logs` VALUES ('2550','ITILCategory','7','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:20:21','0','','Usuario bloqueado');
INSERT INTO `glpi_logs` VALUES ('2551','ITILCategory','25','0','20','Administrador Administrador (438)','2017-08-24 11:20:21','0','','');
INSERT INTO `glpi_logs` VALUES ('2552','ITILCategory','7','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:20:26','0','','Usuario temporal');
INSERT INTO `glpi_logs` VALUES ('2553','ITILCategory','26','0','20','Administrador Administrador (438)','2017-08-24 11:20:26','0','','');
INSERT INTO `glpi_logs` VALUES ('2554','ITILCategory','7','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:20:31','0','','Configurar acceso a las carpetas compartidas');
INSERT INTO `glpi_logs` VALUES ('2555','ITILCategory','27','0','20','Administrador Administrador (438)','2017-08-24 11:20:31','0','','');
INSERT INTO `glpi_logs` VALUES ('2556','ITILCategory','7','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:20:35','0','','Configurar acceso a las impresoras');
INSERT INTO `glpi_logs` VALUES ('2557','ITILCategory','28','0','20','Administrador Administrador (438)','2017-08-24 11:20:35','0','','');
INSERT INTO `glpi_logs` VALUES ('2558','ITILCategory','7','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:20:40','0','','Configurar acceso a Internet');
INSERT INTO `glpi_logs` VALUES ('2559','ITILCategory','29','0','20','Administrador Administrador (438)','2017-08-24 11:20:40','0','','');
INSERT INTO `glpi_logs` VALUES ('2560','ITILCategory','7','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:20:47','0','','Configurar carpeta de escaneos');
INSERT INTO `glpi_logs` VALUES ('2561','ITILCategory','30','0','20','Administrador Administrador (438)','2017-08-24 11:20:47','0','','');
INSERT INTO `glpi_logs` VALUES ('2562','ITILCategory','8','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:21:20','0','','Microsoft Outlook');
INSERT INTO `glpi_logs` VALUES ('2563','ITILCategory','31','0','20','Administrador Administrador (438)','2017-08-24 11:21:20','0','','');
INSERT INTO `glpi_logs` VALUES ('2564','ITILCategory','8','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:21:30','0','','Zimbra web');
INSERT INTO `glpi_logs` VALUES ('2565','ITILCategory','32','0','20','Administrador Administrador (438)','2017-08-24 11:21:30','0','','');
INSERT INTO `glpi_logs` VALUES ('2566','ITILCategory','8','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:21:39','0','','Hotmail, Gmail, Yahoo');
INSERT INTO `glpi_logs` VALUES ('2567','ITILCategory','33','0','20','Administrador Administrador (438)','2017-08-24 11:21:39','0','','');
INSERT INTO `glpi_logs` VALUES ('2568','ITILCategory','9','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:22:45','0','','CPU');
INSERT INTO `glpi_logs` VALUES ('2569','ITILCategory','34','0','20','Administrador Administrador (438)','2017-08-24 11:22:45','0','','');
INSERT INTO `glpi_logs` VALUES ('2570','ITILCategory','9','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:22:51','0','','Monitor');
INSERT INTO `glpi_logs` VALUES ('2571','ITILCategory','35','0','20','Administrador Administrador (438)','2017-08-24 11:22:51','0','','');
INSERT INTO `glpi_logs` VALUES ('2572','ITILCategory','9','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:22:56','0','','Teclado y/o mouse');
INSERT INTO `glpi_logs` VALUES ('2573','ITILCategory','36','0','20','Administrador Administrador (438)','2017-08-24 11:22:56','0','','');
INSERT INTO `glpi_logs` VALUES ('2574','ITILCategory','9','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:23:00','0','','Disco duro');
INSERT INTO `glpi_logs` VALUES ('2575','ITILCategory','37','0','20','Administrador Administrador (438)','2017-08-24 11:23:00','0','','');
INSERT INTO `glpi_logs` VALUES ('2576','ITILCategory','9','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:23:04','0','','Lectora');
INSERT INTO `glpi_logs` VALUES ('2577','ITILCategory','38','0','20','Administrador Administrador (438)','2017-08-24 11:23:04','0','','');
INSERT INTO `glpi_logs` VALUES ('2578','ITILCategory','9','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:23:08','0','','Fuente / estabilizador');
INSERT INTO `glpi_logs` VALUES ('2579','ITILCategory','39','0','20','Administrador Administrador (438)','2017-08-24 11:23:08','0','','');
INSERT INTO `glpi_logs` VALUES ('2580','ITILCategory','9','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:23:12','0','','Memoria / placa');
INSERT INTO `glpi_logs` VALUES ('2581','ITILCategory','40','0','20','Administrador Administrador (438)','2017-08-24 11:23:12','0','','');
INSERT INTO `glpi_logs` VALUES ('2582','ITILCategory','10','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:24:02','0','','Cambio de tóner, tinta o cinta');
INSERT INTO `glpi_logs` VALUES ('2583','ITILCategory','41','0','20','Administrador Administrador (438)','2017-08-24 11:24:02','0','','');
INSERT INTO `glpi_logs` VALUES ('2584','ITILCategory','10','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:24:13','0','','Fusor');
INSERT INTO `glpi_logs` VALUES ('2585','ITILCategory','42','0','20','Administrador Administrador (438)','2017-08-24 11:24:13','0','','');
INSERT INTO `glpi_logs` VALUES ('2586','ITILCategory','10','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:24:16','0','','Atasco de papel');
INSERT INTO `glpi_logs` VALUES ('2587','ITILCategory','43','0','20','Administrador Administrador (438)','2017-08-24 11:24:16','0','','');
INSERT INTO `glpi_logs` VALUES ('2588','ITILCategory','10','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:24:23','0','','No imprime');
INSERT INTO `glpi_logs` VALUES ('2589','ITILCategory','44','0','20','Administrador Administrador (438)','2017-08-24 11:24:23','0','','');
INSERT INTO `glpi_logs` VALUES ('2590','ITILCategory','10','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:24:28','0','','Otros');
INSERT INTO `glpi_logs` VALUES ('2591','ITILCategory','45','0','20','Administrador Administrador (438)','2017-08-24 11:24:28','0','','');
INSERT INTO `glpi_logs` VALUES ('2592','ITILCategory','8','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:24:50','0','','Otros');
INSERT INTO `glpi_logs` VALUES ('2593','ITILCategory','46','0','20','Administrador Administrador (438)','2017-08-24 11:24:50','0','','');
INSERT INTO `glpi_logs` VALUES ('2594','ITILCategory','6','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:25:06','0','','Otros');
INSERT INTO `glpi_logs` VALUES ('2595','ITILCategory','47','0','20','Administrador Administrador (438)','2017-08-24 11:25:06','0','','');
INSERT INTO `glpi_logs` VALUES ('2596','ITILCategory','7','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:25:19','0','','Otros');
INSERT INTO `glpi_logs` VALUES ('2597','ITILCategory','48','0','20','Administrador Administrador (438)','2017-08-24 11:25:19','0','','');
INSERT INTO `glpi_logs` VALUES ('2598','ITILCategory','9','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:25:41','0','','Otros');
INSERT INTO `glpi_logs` VALUES ('2599','ITILCategory','49','0','20','Administrador Administrador (438)','2017-08-24 11:25:41','0','','');
INSERT INTO `glpi_logs` VALUES ('2600','ITILCategory','11','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:26:09','0','','Acceso a páginas bloqueadas por firewall');
INSERT INTO `glpi_logs` VALUES ('2601','ITILCategory','50','0','20','Administrador Administrador (438)','2017-08-24 11:26:09','0','','');
INSERT INTO `glpi_logs` VALUES ('2602','ITILCategory','11','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:26:16','0','','Descargas de aplicativos (Sunat, SPIJ, otros)');
INSERT INTO `glpi_logs` VALUES ('2603','ITILCategory','51','0','20','Administrador Administrador (438)','2017-08-24 11:26:16','0','','');
INSERT INTO `glpi_logs` VALUES ('2604','ITILCategory','11','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:26:22','0','','Sin servicio');
INSERT INTO `glpi_logs` VALUES ('2605','ITILCategory','52','0','20','Administrador Administrador (438)','2017-08-24 11:26:22','0','','');
INSERT INTO `glpi_logs` VALUES ('2606','ITILCategory','11','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:26:29','0','','Otros');
INSERT INTO `glpi_logs` VALUES ('2607','ITILCategory','53','0','20','Administrador Administrador (438)','2017-08-24 11:26:29','0','','');
INSERT INTO `glpi_logs` VALUES ('2608','ITILCategory','12','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:26:50','0','','Cableado y conectividad');
INSERT INTO `glpi_logs` VALUES ('2609','ITILCategory','54','0','20','Administrador Administrador (438)','2017-08-24 11:26:50','0','','');
INSERT INTO `glpi_logs` VALUES ('2610','ITILCategory','12','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:27:01','0','','Routers, Switches y Access Point');
INSERT INTO `glpi_logs` VALUES ('2611','ITILCategory','55','0','20','Administrador Administrador (438)','2017-08-24 11:27:01','0','','');
INSERT INTO `glpi_logs` VALUES ('2612','ITILCategory','12','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:27:07','0','','Nuevos equipos');
INSERT INTO `glpi_logs` VALUES ('2613','ITILCategory','56','0','20','Administrador Administrador (438)','2017-08-24 11:27:07','0','','');
INSERT INTO `glpi_logs` VALUES ('2614','ITILCategory','12','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:27:12','0','','Sin servicio');
INSERT INTO `glpi_logs` VALUES ('2615','ITILCategory','57','0','20','Administrador Administrador (438)','2017-08-24 11:27:12','0','','');
INSERT INTO `glpi_logs` VALUES ('2616','ITILCategory','12','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:27:19','0','','Otros');
INSERT INTO `glpi_logs` VALUES ('2617','ITILCategory','58','0','20','Administrador Administrador (438)','2017-08-24 11:27:19','0','','');
INSERT INTO `glpi_logs` VALUES ('2618','ITILCategory','13','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:27:35','0','','Licencia de software');
INSERT INTO `glpi_logs` VALUES ('2619','ITILCategory','59','0','20','Administrador Administrador (438)','2017-08-24 11:27:35','0','','');
INSERT INTO `glpi_logs` VALUES ('2620','ITILCategory','13','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:27:41','0','','Windows no responde');
INSERT INTO `glpi_logs` VALUES ('2621','ITILCategory','60','0','20','Administrador Administrador (438)','2017-08-24 11:27:41','0','','');
INSERT INTO `glpi_logs` VALUES ('2622','ITILCategory','13','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:27:46','0','','Actualizaciones automáticas');
INSERT INTO `glpi_logs` VALUES ('2623','ITILCategory','61','0','20','Administrador Administrador (438)','2017-08-24 11:27:46','0','','');
INSERT INTO `glpi_logs` VALUES ('2624','ITILCategory','13','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:27:51','0','','Cambio de sistema operativo');
INSERT INTO `glpi_logs` VALUES ('2625','ITILCategory','62','0','20','Administrador Administrador (438)','2017-08-24 11:27:51','0','','');
INSERT INTO `glpi_logs` VALUES ('2626','ITILCategory','13','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:27:56','0','','Otros');
INSERT INTO `glpi_logs` VALUES ('2627','ITILCategory','63','0','20','Administrador Administrador (438)','2017-08-24 11:27:56','0','','');
INSERT INTO `glpi_logs` VALUES ('2628','ITILCategory','14','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:28:07','0','','Cableado');
INSERT INTO `glpi_logs` VALUES ('2629','ITILCategory','64','0','20','Administrador Administrador (438)','2017-08-24 11:28:07','0','','');
INSERT INTO `glpi_logs` VALUES ('2630','ITILCategory','14','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:28:12','0','','Instalación/cambio de equipos');
INSERT INTO `glpi_logs` VALUES ('2631','ITILCategory','65','0','20','Administrador Administrador (438)','2017-08-24 11:28:12','0','','');
INSERT INTO `glpi_logs` VALUES ('2632','ITILCategory','14','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:28:16','0','','Sin servicio');
INSERT INTO `glpi_logs` VALUES ('2633','ITILCategory','66','0','20','Administrador Administrador (438)','2017-08-24 11:28:16','0','','');
INSERT INTO `glpi_logs` VALUES ('2634','ITILCategory','14','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:28:21','0','','Otros');
INSERT INTO `glpi_logs` VALUES ('2635','ITILCategory','67','0','20','Administrador Administrador (438)','2017-08-24 11:28:21','0','','');
INSERT INTO `glpi_logs` VALUES ('2636','ITILCategory','1','','0','Administrador Administrador (438)','2017-08-24 11:33:55','14','Hardware','Soporte técnico');
INSERT INTO `glpi_logs` VALUES ('2637','ITILCategory','1','','0','Administrador Administrador (438)','2017-08-24 11:33:55','1','Hardware','Soporte técnico');
INSERT INTO `glpi_logs` VALUES ('2638','ITILCategory','2','','0','Administrador Administrador (438)','2017-08-24 11:35:06','14','Software','Área de desarrollo');
INSERT INTO `glpi_logs` VALUES ('2639','ITILCategory','2','','0','Administrador Administrador (438)','2017-08-24 11:35:06','1','Software','Área de desarrollo');
INSERT INTO `glpi_logs` VALUES ('2640','ITILCategory','2','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:36:20','0','','Cambios a sistemas');
INSERT INTO `glpi_logs` VALUES ('2641','ITILCategory','68','0','20','Administrador Administrador (438)','2017-08-24 11:36:20','0','','');
INSERT INTO `glpi_logs` VALUES ('2642','ITILCategory','2','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:36:39','0','','Creación de usuarios y perfiles');
INSERT INTO `glpi_logs` VALUES ('2643','ITILCategory','69','0','20','Administrador Administrador (438)','2017-08-24 11:36:39','0','','');
INSERT INTO `glpi_logs` VALUES ('2644','ITILCategory','2','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:37:02','0','','Desarrollo de nuevas funcionalidades');
INSERT INTO `glpi_logs` VALUES ('2645','ITILCategory','70','0','20','Administrador Administrador (438)','2017-08-24 11:37:02','0','','');
INSERT INTO `glpi_logs` VALUES ('2646','ITILCategory','2','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:37:27','0','','Errores en el sistema (bugs)');
INSERT INTO `glpi_logs` VALUES ('2647','ITILCategory','71','0','20','Administrador Administrador (438)','2017-08-24 11:37:27','0','','');
INSERT INTO `glpi_logs` VALUES ('2648','ITILCategory','2','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:37:46','0','','Lentitud y caídas del sistema');
INSERT INTO `glpi_logs` VALUES ('2649','ITILCategory','72','0','20','Administrador Administrador (438)','2017-08-24 11:37:46','0','','');
INSERT INTO `glpi_logs` VALUES ('2650','ITILCategory','2','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:37:51','0','','Otros');
INSERT INTO `glpi_logs` VALUES ('2651','ITILCategory','73','0','20','Administrador Administrador (438)','2017-08-24 11:37:51','0','','');
INSERT INTO `glpi_logs` VALUES ('2652','ITILCategory','3','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:38:30','0','','Creación / modificación de usuarios de red');
INSERT INTO `glpi_logs` VALUES ('2653','ITILCategory','74','0','20','Administrador Administrador (438)','2017-08-24 11:38:30','0','','');
INSERT INTO `glpi_logs` VALUES ('2654','ITILCategory','3','ITILCategory','17','Administrador Administrador (438)','2017-08-24 11:38:50','0','','Desbloqueo de usuarios de red');
INSERT INTO `glpi_logs` VALUES ('2655','ITILCategory','75','0','20','Administrador Administrador (438)','2017-08-24 11:38:50','0','','');
INSERT INTO `glpi_logs` VALUES ('2657','CartridgeItem','1','0','20','Administrador Administrador (438)','2017-08-24 11:51:10','0','','');
INSERT INTO `glpi_logs` VALUES ('2658','Infocom','1','0','20','Administrador Administrador (438)','2017-08-24 11:51:26','0','','');
INSERT INTO `glpi_logs` VALUES ('2662','CartridgeItem','1','Cartridge','19','Administrador Administrador (438)','2017-08-24 11:52:12','0','CF281X - 1 (1)','');
INSERT INTO `glpi_logs` VALUES ('2660','CartridgeItem','1','Cartridge','17','Administrador Administrador (438)','2017-08-24 11:51:51','0','','CF281X - 1 (1)');
INSERT INTO `glpi_logs` VALUES ('2714','CartridgeItem','1','Cartridge','19','Administrador Administrador (438)','2017-08-24 11:55:29','0','CF281X - 2 (2)','');
INSERT INTO `glpi_logs` VALUES ('2664','CartridgeItem','1','Cartridge','17','Administrador Administrador (438)','2017-08-24 11:52:21','0','','CF281X - 2 (2)');
INSERT INTO `glpi_logs` VALUES ('2715','CartridgeItem','1','Cartridge','19','Administrador Administrador (438)','2017-08-24 11:55:29','0','CF281X - 3 (3)','');
INSERT INTO `glpi_logs` VALUES ('2667','CartridgeItem','1','Cartridge','17','Administrador Administrador (438)','2017-08-24 11:52:21','0','','CF281X - 3 (3)');
INSERT INTO `glpi_logs` VALUES ('2716','CartridgeItem','1','Cartridge','19','Administrador Administrador (438)','2017-08-24 11:55:29','0','CF281X - 4 (4)','');
INSERT INTO `glpi_logs` VALUES ('2670','CartridgeItem','1','Cartridge','17','Administrador Administrador (438)','2017-08-24 11:52:21','0','','CF281X - 4 (4)');
INSERT INTO `glpi_logs` VALUES ('2717','CartridgeItem','1','Cartridge','19','Administrador Administrador (438)','2017-08-24 11:55:29','0','CF281X - 5 (5)','');
INSERT INTO `glpi_logs` VALUES ('2673','CartridgeItem','1','Cartridge','17','Administrador Administrador (438)','2017-08-24 11:52:21','0','','CF281X - 5 (5)');
INSERT INTO `glpi_logs` VALUES ('2718','CartridgeItem','1','Cartridge','19','Administrador Administrador (438)','2017-08-24 11:55:29','0','CF281X - 6 (6)','');
INSERT INTO `glpi_logs` VALUES ('2676','CartridgeItem','1','Cartridge','17','Administrador Administrador (438)','2017-08-24 11:52:21','0','','CF281X - 6 (6)');
INSERT INTO `glpi_logs` VALUES ('2719','CartridgeItem','1','Cartridge','19','Administrador Administrador (438)','2017-08-24 11:55:29','0','CF281X - 7 (7)','');
INSERT INTO `glpi_logs` VALUES ('2679','CartridgeItem','1','Cartridge','17','Administrador Administrador (438)','2017-08-24 11:52:21','0','','CF281X - 7 (7)');
INSERT INTO `glpi_logs` VALUES ('2720','CartridgeItem','1','Cartridge','19','Administrador Administrador (438)','2017-08-24 11:55:29','0','CF281X - 8 (8)','');
INSERT INTO `glpi_logs` VALUES ('2682','CartridgeItem','1','Cartridge','17','Administrador Administrador (438)','2017-08-24 11:52:21','0','','CF281X - 8 (8)');
INSERT INTO `glpi_logs` VALUES ('2721','CartridgeItem','1','Cartridge','19','Administrador Administrador (438)','2017-08-24 11:55:29','0','CF281X - 9 (9)','');
INSERT INTO `glpi_logs` VALUES ('2685','CartridgeItem','1','Cartridge','17','Administrador Administrador (438)','2017-08-24 11:52:21','0','','CF281X - 9 (9)');
INSERT INTO `glpi_logs` VALUES ('2722','CartridgeItem','1','Cartridge','19','Administrador Administrador (438)','2017-08-24 11:55:29','0','CF281X - 10 (10)','');
INSERT INTO `glpi_logs` VALUES ('2688','CartridgeItem','1','Cartridge','17','Administrador Administrador (438)','2017-08-24 11:52:21','0','','CF281X - 10 (10)');
INSERT INTO `glpi_logs` VALUES ('2723','CartridgeItem','1','Cartridge','19','Administrador Administrador (438)','2017-08-24 11:55:29','0','CF281X - 11 (11)','');
INSERT INTO `glpi_logs` VALUES ('2691','CartridgeItem','1','Cartridge','17','Administrador Administrador (438)','2017-08-24 11:52:21','0','','CF281X - 11 (11)');
INSERT INTO `glpi_logs` VALUES ('2724','CartridgeItem','1','Cartridge','19','Administrador Administrador (438)','2017-08-24 11:55:29','0','CF281X - 12 (12)','');
INSERT INTO `glpi_logs` VALUES ('2694','CartridgeItem','1','Cartridge','17','Administrador Administrador (438)','2017-08-24 11:52:21','0','','CF281X - 12 (12)');
INSERT INTO `glpi_logs` VALUES ('2725','CartridgeItem','1','Cartridge','19','Administrador Administrador (438)','2017-08-24 11:55:29','0','CF281X - 13 (13)','');
INSERT INTO `glpi_logs` VALUES ('2697','CartridgeItem','1','Cartridge','17','Administrador Administrador (438)','2017-08-24 11:52:21','0','','CF281X - 13 (13)');
INSERT INTO `glpi_logs` VALUES ('2726','CartridgeItem','1','Cartridge','19','Administrador Administrador (438)','2017-08-24 11:55:29','0','CF281X - 14 (14)','');
INSERT INTO `glpi_logs` VALUES ('2700','CartridgeItem','1','Cartridge','17','Administrador Administrador (438)','2017-08-24 11:52:21','0','','CF281X - 14 (14)');
INSERT INTO `glpi_logs` VALUES ('2727','CartridgeItem','1','Cartridge','19','Administrador Administrador (438)','2017-08-24 11:55:29','0','CF281X - 15 (15)','');
INSERT INTO `glpi_logs` VALUES ('2703','CartridgeItem','1','Cartridge','17','Administrador Administrador (438)','2017-08-24 11:52:21','0','','CF281X - 15 (15)');
INSERT INTO `glpi_logs` VALUES ('2728','CartridgeItem','1','Cartridge','19','Administrador Administrador (438)','2017-08-24 11:55:29','0','CF281X - 16 (16)','');
INSERT INTO `glpi_logs` VALUES ('2706','CartridgeItem','1','Cartridge','17','Administrador Administrador (438)','2017-08-24 11:52:21','0','','CF281X - 16 (16)');
INSERT INTO `glpi_logs` VALUES ('2729','CartridgeItem','1','Cartridge','19','Administrador Administrador (438)','2017-08-24 11:55:29','0','CF281X - 17 (17)','');
INSERT INTO `glpi_logs` VALUES ('2709','CartridgeItem','1','Cartridge','17','Administrador Administrador (438)','2017-08-24 11:52:21','0','','CF281X - 17 (17)');
INSERT INTO `glpi_logs` VALUES ('2730','CartridgeItem','1','Cartridge','19','Administrador Administrador (438)','2017-08-24 11:55:29','0','CF281X - 18 (18)','');
INSERT INTO `glpi_logs` VALUES ('2712','CartridgeItem','1','Cartridge','17','Administrador Administrador (438)','2017-08-24 11:52:21','0','','CF281X - 18 (18)');
INSERT INTO `glpi_logs` VALUES ('2749','CartridgeItem','1','Cartridge','19','Administrador Administrador (438)','2017-08-24 11:56:18','0','CF281X - 19 (19)','');
INSERT INTO `glpi_logs` VALUES ('2732','CartridgeItem','1','Cartridge','17','Administrador Administrador (438)','2017-08-24 11:55:32','0','','CF281X - 19 (19)');
INSERT INTO `glpi_logs` VALUES ('2750','CartridgeItem','1','Cartridge','19','Administrador Administrador (438)','2017-08-24 11:56:18','0','CF281X - 20 (20)','');
INSERT INTO `glpi_logs` VALUES ('2735','CartridgeItem','1','Cartridge','17','Administrador Administrador (438)','2017-08-24 11:55:45','0','','CF281X - 20 (20)');
INSERT INTO `glpi_logs` VALUES ('2751','CartridgeItem','1','Cartridge','19','Administrador Administrador (438)','2017-08-24 11:56:18','0','CF281X - 21 (21)','');
INSERT INTO `glpi_logs` VALUES ('2738','CartridgeItem','1','Cartridge','17','Administrador Administrador (438)','2017-08-24 11:55:48','0','','CF281X - 21 (21)');
INSERT INTO `glpi_logs` VALUES ('2752','CartridgeItem','1','Cartridge','19','Administrador Administrador (438)','2017-08-24 11:56:18','0','CF281X - 22 (22)','');
INSERT INTO `glpi_logs` VALUES ('2741','CartridgeItem','1','Cartridge','17','Administrador Administrador (438)','2017-08-24 11:55:48','0','','CF281X - 22 (22)');
INSERT INTO `glpi_logs` VALUES ('2753','CartridgeItem','1','Cartridge','19','Administrador Administrador (438)','2017-08-24 11:56:18','0','CF281X - 23 (23)','');
INSERT INTO `glpi_logs` VALUES ('2744','CartridgeItem','1','Cartridge','17','Administrador Administrador (438)','2017-08-24 11:55:48','0','','CF281X - 23 (23)');
INSERT INTO `glpi_logs` VALUES ('2754','CartridgeItem','1','Cartridge','19','Administrador Administrador (438)','2017-08-24 11:56:18','0','CF281X - 24 (24)','');
INSERT INTO `glpi_logs` VALUES ('2747','CartridgeItem','1','Cartridge','17','Administrador Administrador (438)','2017-08-24 11:55:48','0','','CF281X - 24 (24)');
INSERT INTO `glpi_logs` VALUES ('2755','CartridgeItem','1','0','13','Administrador Administrador (438)','2017-08-24 11:56:39','0','','');
INSERT INTO `glpi_logs` VALUES ('2760','User','303','Group','15','Administrador Administrador (438)','2017-08-24 12:01:51','0','','Soporte Técnico (40)');
INSERT INTO `glpi_logs` VALUES ('2761','Group','40','User','15','Administrador Administrador (438)','2017-08-24 12:01:51','0','','Alvarez Cordova David (303)');
INSERT INTO `glpi_logs` VALUES ('2762','User','422','Group','15','Administrador Administrador (438)','2017-08-24 12:04:32','0','','Soporte Técnico (40)');
INSERT INTO `glpi_logs` VALUES ('2763','Group','40','User','15','Administrador Administrador (438)','2017-08-24 12:04:32','0','','Alcas Golles Alberto (422)');
INSERT INTO `glpi_logs` VALUES ('2764','User','436','Group','15','Administrador Administrador (438)','2017-08-24 12:04:42','0','','Soporte Técnico (40)');
INSERT INTO `glpi_logs` VALUES ('2765','Group','40','User','15','Administrador Administrador (438)','2017-08-24 12:04:42','0','','Mendoza Martel Francisco Jesus (436)');
INSERT INTO `glpi_logs` VALUES ('2766','User','343','Group','15','Administrador Administrador (438)','2017-08-24 12:05:13','0','','Soporte Técnico (40)');
INSERT INTO `glpi_logs` VALUES ('2767','Group','40','User','15','Administrador Administrador (438)','2017-08-24 12:05:13','0','','Mantilla Rios Cesar (343)');
INSERT INTO `glpi_logs` VALUES ('2768','Group','41','0','20','Administrador Administrador (438)','2017-08-24 12:10:07','0','','');
INSERT INTO `glpi_logs` VALUES ('2769','User','184','Group','15','Administrador Administrador (438)','2017-08-24 12:11:06','0','','Desarrollo (41)');
INSERT INTO `glpi_logs` VALUES ('2770','Group','41','User','15','Administrador Administrador (438)','2017-08-24 12:11:06','0','','Santisteban Valencia Jose (184)');
INSERT INTO `glpi_logs` VALUES ('2771','ITILCategory','1','','0','Administrador Administrador (438)','2017-08-24 12:17:12','71','&nbsp; (0)','Soporte Técnico (40)');
INSERT INTO `glpi_logs` VALUES ('2772','Ticket','5','User','15','post-only (3)','2017-08-24 12:22:25','0','','post-only (3)');
INSERT INTO `glpi_logs` VALUES ('2773','Ticket','5','0','20','post-only (3)','2017-08-24 12:22:25','0','','');
INSERT INTO `glpi_logs` VALUES ('2774','AuthMail','1','','0','Administrador Administrador (438)','2017-08-24 12:26:01','3','','saludpol');
INSERT INTO `glpi_logs` VALUES ('2775','AuthMail','1','','0','Administrador Administrador (438)','2017-08-24 12:26:01','4','{zimbra.saludpol.gob.pe:25/pop}','{zimbra.saludpol.gob.pe:465/pop/ssl}');
INSERT INTO `glpi_logs` VALUES ('2776','Profile','6','','0','Administrador Administrador (438)','2017-08-24 12:41:04','59','97','33');
INSERT INTO `glpi_logs` VALUES ('2777','Profile','6','','0','Administrador Administrador (438)','2017-08-24 12:41:04','56','1055','1');
INSERT INTO `glpi_logs` VALUES ('2778','Profile','7','','0','Administrador Administrador (438)','2017-08-24 12:43:27','101','96','0');
INSERT INTO `glpi_logs` VALUES ('2779','Profile','7','','0','Administrador Administrador (438)','2017-08-24 12:43:27','32','96','0');
INSERT INTO `glpi_logs` VALUES ('2780','Profile','7','','0','Administrador Administrador (438)','2017-08-24 12:43:27','31','127','0');
INSERT INTO `glpi_logs` VALUES ('2781','Profile','7','','0','Administrador Administrador (438)','2017-08-24 12:44:00','34','6175','0');
INSERT INTO `glpi_logs` VALUES ('2782','Profile','7','','0','Administrador Administrador (438)','2017-08-24 12:44:00','63','31','0');
INSERT INTO `glpi_logs` VALUES ('2783','Profile','7','','0','Administrador Administrador (438)','2017-08-24 12:44:00','38','1','0');
INSERT INTO `glpi_logs` VALUES ('2784','Profile','7','','0','Administrador Administrador (438)','2017-08-24 12:44:00','36','1055','0');
INSERT INTO `glpi_logs` VALUES ('2785','Profile','7','','0','Administrador Administrador (438)','2017-08-24 12:44:00','120','31','0');
INSERT INTO `glpi_logs` VALUES ('2786','Profile','6','','0','Administrador Administrador (438)','2017-08-24 12:44:45','26','127','0');
INSERT INTO `glpi_logs` VALUES ('2787','Profile','6','','0','Administrador Administrador (438)','2017-08-24 12:44:45','20','127','0');
INSERT INTO `glpi_logs` VALUES ('2788','Profile','6','','0','Administrador Administrador (438)','2017-08-24 12:44:45','27','127','0');
INSERT INTO `glpi_logs` VALUES ('2789','Profile','6','','0','Administrador Administrador (438)','2017-08-24 12:44:45','129','31','0');
INSERT INTO `glpi_logs` VALUES ('2790','Profile','6','','0','Administrador Administrador (438)','2017-08-24 12:44:45','21','127','0');
INSERT INTO `glpi_logs` VALUES ('2791','Profile','6','','0','Administrador Administrador (438)','2017-08-24 12:44:45','23','127','0');
INSERT INTO `glpi_logs` VALUES ('2792','Profile','6','','0','Administrador Administrador (438)','2017-08-24 12:44:45','25','127','0');
INSERT INTO `glpi_logs` VALUES ('2793','Profile','6','','0','Administrador Administrador (438)','2017-08-24 12:44:45','28','127','0');
INSERT INTO `glpi_logs` VALUES ('2794','Profile','6','','0','Administrador Administrador (438)','2017-08-24 12:44:45','24','127','0');
INSERT INTO `glpi_logs` VALUES ('2795','Profile','6','','0','Administrador Administrador (438)','2017-08-24 12:44:45','22','127','0');
INSERT INTO `glpi_logs` VALUES ('2796','Profile','6','','0','Administrador Administrador (438)','2017-08-24 12:46:27','101','96','0');
INSERT INTO `glpi_logs` VALUES ('2797','Profile','6','','0','Administrador Administrador (438)','2017-08-24 12:46:27','32','96','0');
INSERT INTO `glpi_logs` VALUES ('2798','Profile','6','','0','Administrador Administrador (438)','2017-08-24 12:46:27','31','127','0');
INSERT INTO `glpi_logs` VALUES ('2799','Profile','6','','0','Administrador Administrador (438)','2017-08-24 12:47:06','34','6175','6167');
INSERT INTO `glpi_logs` VALUES ('2800','Profile','6','','0','Administrador Administrador (438)','2017-08-24 12:47:06','63','31','0');
INSERT INTO `glpi_logs` VALUES ('2801','Profile','6','','0','Administrador Administrador (438)','2017-08-24 12:47:06','120','31','0');
INSERT INTO `glpi_logs` VALUES ('2802','Profile','6','','0','Administrador Administrador (438)','2017-08-24 12:47:56','59','33','0');
INSERT INTO `glpi_logs` VALUES ('2803','Profile','6','','0','Administrador Administrador (438)','2017-08-24 12:47:56','58','1','0');
INSERT INTO `glpi_logs` VALUES ('2804','Profile','6','','0','Administrador Administrador (438)','2017-08-24 12:47:56','60','1','0');
INSERT INTO `glpi_logs` VALUES ('2805','Profile','1','','0','Administrador Administrador (438)','2017-08-24 12:55:25','36','1024','0');
INSERT INTO `glpi_logs` VALUES ('2806','Profile','1','','0','Administrador Administrador (438)','2017-08-24 12:55:33','120','1','0');
INSERT INTO `glpi_logs` VALUES ('2807','Profile','1','','0','Administrador Administrador (438)','2017-08-24 12:56:18','87','[\"Computer\",\"Monitor\",\"NetworkEquipment\",\"Peripheral\",\"Phone\",\"Printer\",\"Software\"]','[\"Computer\",\"Monitor\",\"NetworkEquipment\",\"Peripheral\",\"Phone\",\"Printer\",\"Software\"]');
INSERT INTO `glpi_logs` VALUES ('2808','Profile','1','','0','Administrador Administrador (438)','2017-08-24 12:56:18','102','131077','5');
INSERT INTO `glpi_logs` VALUES ('2809','Profile','1','','0','Administrador Administrador (438)','2017-08-24 12:57:45','87','[\"Computer\",\"Monitor\",\"NetworkEquipment\",\"Peripheral\",\"Phone\",\"Printer\",\"Software\"]','[\"Computer\",\"Monitor\",\"NetworkEquipment\",\"Peripheral\",\"Phone\",\"Printer\",\"Software\"]');
INSERT INTO `glpi_logs` VALUES ('2810','AuthMail','1','','0','Administrador Administrador (438)','2017-08-24 14:28:17','3','saludpol','zimbra.saludpol.gob.pe');
INSERT INTO `glpi_logs` VALUES ('2811','AuthMail','1','','0','Administrador Administrador (438)','2017-08-24 14:28:17','4','{zimbra.saludpol.gob.pe:465/pop/ssl}','{zimbra.saludpol.gob.pe:25/ssl}');
INSERT INTO `glpi_logs` VALUES ('2812','AuthMail','1','','0','Administrador Administrador (438)','2017-08-24 14:28:22','4','{zimbra.saludpol.gob.pe:25/ssl}','{zimbra.saludpol.gob.pe:25}');
INSERT INTO `glpi_logs` VALUES ('2813','AuthMail','1','','0','Administrador Administrador (438)','2017-08-24 14:44:45','4','{zimbra.saludpol.gob.pe:25}','{zimbra.saludpol.gob.pe:465}');
INSERT INTO `glpi_logs` VALUES ('2814','User','3','UserEmail','17','Administrador Administrador (438)','2017-08-24 15:00:05','0','','dalvarezc@saludpol.gob.pe (403)');
INSERT INTO `glpi_logs` VALUES ('2815','UserEmail','403','0','20','Administrador Administrador (438)','2017-08-24 15:00:05','0','','');
INSERT INTO `glpi_logs` VALUES ('2816','User','3','','0','Administrador Administrador (438)','2017-08-24 15:36:55','1','post-only','prueba');
INSERT INTO `glpi_logs` VALUES ('2817','User','3','','0','Administrador Administrador (438)','2017-08-24 15:36:55','34','','Usuario');
INSERT INTO `glpi_logs` VALUES ('2818','User','3','','0','Administrador Administrador (438)','2017-08-24 15:36:55','9','','Prueba');
INSERT INTO `glpi_logs` VALUES ('2819','User','3','UserEmail','18','Administrador Administrador (438)','2017-08-24 15:36:55','0','dalvarezc@saludpol.gob.pe','fmendoza@saludpol.gob.pe');
INSERT INTO `glpi_logs` VALUES ('2820','AuthLDAP','1','','0','Administrador Administrador (438)','2017-08-24 15:37:20','17','userprincipalname','');
INSERT INTO `glpi_logs` VALUES ('2822','User','436','UserEmail','17','Mendoza Martel Francisco Jesus (436)','2017-08-24 15:56:24','0','','fmendoza@saludpol.gob.pe (404)');
INSERT INTO `glpi_logs` VALUES ('2823','UserEmail','404','0','20','Mendoza Martel Francisco Jesus (436)','2017-08-24 15:56:24','0','','');
INSERT INTO `glpi_logs` VALUES ('2824','Ticket','6','User','15','Mendoza Martel Francisco Jesus (436)','2017-08-24 15:58:16','0','','Mendoza Martel Francisco Jesus (436)');
INSERT INTO `glpi_logs` VALUES ('2825','Ticket','6','User','15','Mendoza Martel Francisco Jesus (436)','2017-08-24 15:58:16','0','','Alvarez Cordova David (303)');
INSERT INTO `glpi_logs` VALUES ('2826','Ticket','6','0','20','Mendoza Martel Francisco Jesus (436)','2017-08-24 15:58:16','0','','');
INSERT INTO `glpi_logs` VALUES ('2827','User','438','UserEmail','17','Administrador Administrador (438)','2017-08-24 16:05:29','0','','soporte@saludpol.gob.pe (405)');
INSERT INTO `glpi_logs` VALUES ('2828','UserEmail','405','0','20','Administrador Administrador (438)','2017-08-24 16:05:29','0','','');
INSERT INTO `glpi_logs` VALUES ('2829','Ticket','7','User','15','Usuario Prueba (3)','2017-08-24 16:37:19','0','','Usuario Prueba (3)');
INSERT INTO `glpi_logs` VALUES ('2830','Ticket','7','0','20','Usuario Prueba (3)','2017-08-24 16:37:19','0','','');
INSERT INTO `glpi_logs` VALUES ('2831','Ticket','8','User','15','Usuario Prueba (3)','2017-08-24 16:47:35','0','','Usuario Prueba (3)');
INSERT INTO `glpi_logs` VALUES ('2832','Ticket','8','0','20','Usuario Prueba (3)','2017-08-24 16:47:35','0','','');
INSERT INTO `glpi_logs` VALUES ('2833','Ticket','9','User','15','Usuario Prueba (3)','2017-08-24 17:23:39','0','','Usuario Prueba (3)');
INSERT INTO `glpi_logs` VALUES ('2834','Ticket','9','0','20','Usuario Prueba (3)','2017-08-24 17:23:39','0','','');
INSERT INTO `glpi_logs` VALUES ('2835','RequestType','1','','0','Administrador Administrador (438)','2017-08-24 17:28:51','1','Helpdesk','Soporte Técnico');
INSERT INTO `glpi_logs` VALUES ('2836','Ticket','6','','0','Administrador Administrador (438)','2017-08-24 17:31:36','24','','&lt;p&gt;SE LE ESTARÁ LLEVANDO EN BREVE&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('2837','Ticket','6','','0','Administrador Administrador (438)','2017-08-24 17:31:36','64','fmendoza (436)','Administrador (438)');
INSERT INTO `glpi_logs` VALUES ('2838','Ticket','6','','0','Administrador Administrador (438)','2017-08-24 17:31:36','12','1','6');
INSERT INTO `glpi_logs` VALUES ('2839','Ticket','6','','0','Administrador Administrador (438)','2017-08-24 17:31:36','16','','2017-08-24 17:31:36');
INSERT INTO `glpi_logs` VALUES ('2840','Ticket','6','','0','Administrador Administrador (438)','2017-08-24 17:31:36','17','','2017-08-24 17:31:36');
INSERT INTO `glpi_logs` VALUES ('2841','Ticket','2','','0','Mantilla Rios Cesar Augusto (4)','2017-08-24 17:41:59','24','','&lt;p&gt;SE PROCEDIO ACTUALIZAR CONTROLADORES Y A LA LIMPIEZA DE LA PC, QUEDO OK.&lt;/p&gt;rn&lt;p&gt; &lt;/p&gt;rn&lt;p&gt; &lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('2842','Ticket','2','','0','Mantilla Rios Cesar Augusto (4)','2017-08-24 17:41:59','64','lescalerar (177)','tech1 (4)');
INSERT INTO `glpi_logs` VALUES ('2843','Ticket','2','','0','Mantilla Rios Cesar Augusto (4)','2017-08-24 17:41:59','12','1','6');
INSERT INTO `glpi_logs` VALUES ('2844','Ticket','2','','0','Mantilla Rios Cesar Augusto (4)','2017-08-24 17:41:59','16','','2017-08-24 17:41:59');
INSERT INTO `glpi_logs` VALUES ('2845','Ticket','2','','0','Mantilla Rios Cesar Augusto (4)','2017-08-24 17:41:59','17','','2017-08-24 17:41:59');
INSERT INTO `glpi_logs` VALUES ('2846','Ticket','9','','0','Mantilla Rios Cesar Augusto (4)','2017-08-24 18:00:24','150','0','2205');
INSERT INTO `glpi_logs` VALUES ('2847','Ticket','9','','0','Mantilla Rios Cesar Augusto (4)','2017-08-24 18:00:24','64','prueba (3)','tech1 (4)');
INSERT INTO `glpi_logs` VALUES ('2848','Ticket','9','','0','Mantilla Rios Cesar Augusto (4)','2017-08-24 18:00:24','12','1','2');
INSERT INTO `glpi_logs` VALUES ('2849','Ticket','9','User','15','Mantilla Rios Cesar Augusto (4)','2017-08-24 18:00:24','0','','Mantilla Rios Cesar Augusto (4)');
INSERT INTO `glpi_logs` VALUES ('2850','Document','3','0','20','Santisteban Valencia Jose (184)','2017-08-24 18:05:14','0','','');
INSERT INTO `glpi_logs` VALUES ('2851','Document','3','Ticket','15','Santisteban Valencia Jose (184)','2017-08-24 18:05:14','0','','Error en Excel (10)');
INSERT INTO `glpi_logs` VALUES ('2852','Ticket','10','Document','15','Santisteban Valencia Jose (184)','2017-08-24 18:05:14','0','','Incidente del Documento 10 (3)');
INSERT INTO `glpi_logs` VALUES ('2853','Ticket','10','User','15','Santisteban Valencia Jose (184)','2017-08-24 18:05:14','0','','Santisteban Valencia Jose (184)');
INSERT INTO `glpi_logs` VALUES ('2854','Ticket','10','User','15','Santisteban Valencia Jose (184)','2017-08-24 18:05:14','0','','Mendoza Martel Francisco Jesus (436)');
INSERT INTO `glpi_logs` VALUES ('2855','Ticket','10','0','20','Santisteban Valencia Jose (184)','2017-08-24 18:05:14','0','','');
INSERT INTO `glpi_logs` VALUES ('2856','Ticket','11','User','15','Usuario Prueba (3)','2017-08-25 12:06:16','0','','Usuario Prueba (3)');
INSERT INTO `glpi_logs` VALUES ('2857','Ticket','11','0','20','Usuario Prueba (3)','2017-08-25 12:06:16','0','','');
INSERT INTO `glpi_logs` VALUES ('2858','Location','1','0','20','Administrador Administrador (438)','2017-08-25 14:19:56','0','','');
INSERT INTO `glpi_logs` VALUES ('2859','Location','2','0','20','Administrador Administrador (438)','2017-08-25 14:20:09','0','','');
INSERT INTO `glpi_logs` VALUES ('2860','Location','3','0','20','Administrador Administrador (438)','2017-08-25 14:20:15','0','','');
INSERT INTO `glpi_logs` VALUES ('2861','Location','4','0','20','Administrador Administrador (438)','2017-08-25 14:21:03','0','','');
INSERT INTO `glpi_logs` VALUES ('2862','Location','5','0','20','Administrador Administrador (438)','2017-08-25 14:21:10','0','','');
INSERT INTO `glpi_logs` VALUES ('2863','Location','6','0','20','Administrador Administrador (438)','2017-08-25 14:21:15','0','','');
INSERT INTO `glpi_logs` VALUES ('2864','Location','7','0','20','Administrador Administrador (438)','2017-08-25 14:21:20','0','','');
INSERT INTO `glpi_logs` VALUES ('2865','Location','8','0','20','Administrador Administrador (438)','2017-08-25 14:21:24','0','','');
INSERT INTO `glpi_logs` VALUES ('2866','Location','9','0','20','Administrador Administrador (438)','2017-08-25 14:21:29','0','','');
INSERT INTO `glpi_logs` VALUES ('2867','Location','10','0','20','Administrador Administrador (438)','2017-08-25 14:21:34','0','','');
INSERT INTO `glpi_logs` VALUES ('2868','Location','11','0','20','Administrador Administrador (438)','2017-08-25 14:21:41','0','','');
INSERT INTO `glpi_logs` VALUES ('2869','Location','1','Location','17','Administrador Administrador (438)','2017-08-25 14:22:06','0','','GERENCIA GENERAL');
INSERT INTO `glpi_logs` VALUES ('2870','Location','12','0','20','Administrador Administrador (438)','2017-08-25 14:22:06','0','','');
INSERT INTO `glpi_logs` VALUES ('2871','Location','2','Location','17','Administrador Administrador (438)','2017-08-25 14:23:07','0','','EQUIPO FUNCIONAL DE PLANEAMIENTO, PRESUPUESTO Y MODERNIZACIÓN');
INSERT INTO `glpi_logs` VALUES ('2872','Location','13','0','20','Administrador Administrador (438)','2017-08-25 14:23:07','0','','');
INSERT INTO `glpi_logs` VALUES ('2873','Location','2','Location','17','Administrador Administrador (438)','2017-08-25 14:23:12','0','','OFICINA DE PLANEAMIENTO');
INSERT INTO `glpi_logs` VALUES ('2874','Location','14','0','20','Administrador Administrador (438)','2017-08-25 14:23:12','0','','');
INSERT INTO `glpi_logs` VALUES ('2875','Location','2','Location','17','Administrador Administrador (438)','2017-08-25 14:23:18','0','','OFICINA DE PRESUPUESTO');
INSERT INTO `glpi_logs` VALUES ('2876','Location','15','0','20','Administrador Administrador (438)','2017-08-25 14:23:18','0','','');
INSERT INTO `glpi_logs` VALUES ('2877','Location','2','Location','17','Administrador Administrador (438)','2017-08-25 14:23:23','0','','OFICINA DE MODERNIZACIÓN');
INSERT INTO `glpi_logs` VALUES ('2878','Location','16','0','20','Administrador Administrador (438)','2017-08-25 14:23:23','0','','');
INSERT INTO `glpi_logs` VALUES ('2879','Location','3','Location','17','Administrador Administrador (438)','2017-08-25 14:23:52','0','','EQUIPO FUNCIONAL DE ASESORÍA JURÍDICA');
INSERT INTO `glpi_logs` VALUES ('2880','Location','17','0','20','Administrador Administrador (438)','2017-08-25 14:23:52','0','','');
INSERT INTO `glpi_logs` VALUES ('2881','Location','4','Location','17','Administrador Administrador (438)','2017-08-25 14:24:39','0','','EQUIPO FUNCIONAL DE ADMINISTRACIÓN');
INSERT INTO `glpi_logs` VALUES ('2882','Location','18','0','20','Administrador Administrador (438)','2017-08-25 14:24:39','0','','');
INSERT INTO `glpi_logs` VALUES ('2883','Location','4','Location','17','Administrador Administrador (438)','2017-08-25 14:24:43','0','','OFICINA DE ECONOMÍA');
INSERT INTO `glpi_logs` VALUES ('2884','Location','19','0','20','Administrador Administrador (438)','2017-08-25 14:24:43','0','','');
INSERT INTO `glpi_logs` VALUES ('2885','Location','4','Location','17','Administrador Administrador (438)','2017-08-25 14:24:48','0','','OFICINA DE LOGÍSTICA Y PATRIMONIO');
INSERT INTO `glpi_logs` VALUES ('2886','Location','20','0','20','Administrador Administrador (438)','2017-08-25 14:24:48','0','','');
INSERT INTO `glpi_logs` VALUES ('2887','Location','4','Location','17','Administrador Administrador (438)','2017-08-25 14:24:53','0','','GESTIÓN DOCUMENTARIA Y ARCHIVO');
INSERT INTO `glpi_logs` VALUES ('2888','Location','21','0','20','Administrador Administrador (438)','2017-08-25 14:24:53','0','','');
INSERT INTO `glpi_logs` VALUES ('2889','Location','4','Location','17','Administrador Administrador (438)','2017-08-25 14:25:20','0','','GESTIÓN DOCUMENTARIA Y ARCHIVO - HLNS');
INSERT INTO `glpi_logs` VALUES ('2890','Location','22','0','20','Administrador Administrador (438)','2017-08-25 14:25:20','0','','');
INSERT INTO `glpi_logs` VALUES ('2891','Location','19','Location','17','Administrador Administrador (438)','2017-08-25 14:25:32','0','','AREA DE TESORERIA');
INSERT INTO `glpi_logs` VALUES ('2892','Location','23','0','20','Administrador Administrador (438)','2017-08-25 14:25:32','0','','');
INSERT INTO `glpi_logs` VALUES ('2893','Location','19','Location','17','Administrador Administrador (438)','2017-08-25 14:25:38','0','','AREA DE CONTABILIDAD');
INSERT INTO `glpi_logs` VALUES ('2894','Location','24','0','20','Administrador Administrador (438)','2017-08-25 14:25:38','0','','');
INSERT INTO `glpi_logs` VALUES ('2895','Location','19','Location','17','Administrador Administrador (438)','2017-08-25 14:25:46','0','','AREA DE CONTROL PREVIO');
INSERT INTO `glpi_logs` VALUES ('2896','Location','25','0','20','Administrador Administrador (438)','2017-08-25 14:25:46','0','','');
INSERT INTO `glpi_logs` VALUES ('2897','Location','19','Location','17','Administrador Administrador (438)','2017-08-25 14:25:51','0','','AREA DE CAJA CHICA');
INSERT INTO `glpi_logs` VALUES ('2898','Location','26','0','20','Administrador Administrador (438)','2017-08-25 14:25:51','0','','');
INSERT INTO `glpi_logs` VALUES ('2899','Location','19','Location','17','Administrador Administrador (438)','2017-08-25 14:26:05','0','','AREA DE CAJA CHICA - HLNS');
INSERT INTO `glpi_logs` VALUES ('2900','Location','27','0','20','Administrador Administrador (438)','2017-08-25 14:26:05','0','','');
INSERT INTO `glpi_logs` VALUES ('2901','Location','5','Location','17','Administrador Administrador (438)','2017-08-25 14:26:35','0','','EQUIPO FUNCIONAL DE GESTIÓN Y DESARROLLO DE RECURSOS HUMANOS');
INSERT INTO `glpi_logs` VALUES ('2902','Location','28','0','20','Administrador Administrador (438)','2017-08-25 14:26:35','0','','');
INSERT INTO `glpi_logs` VALUES ('2903','Location','7','Location','17','Administrador Administrador (438)','2017-08-25 14:27:10','0','','EQUIPO FUNCIONAL DE GESTIÓN DEL ASEGURADO');
INSERT INTO `glpi_logs` VALUES ('2904','Location','29','0','20','Administrador Administrador (438)','2017-08-25 14:27:10','0','','');
INSERT INTO `glpi_logs` VALUES ('2905','Location','7','Location','17','Administrador Administrador (438)','2017-08-25 14:27:14','0','','OFICINA DE PROMOCION Y VIGILANCIA DE LOS DERECHOS DEL ASEGURADO');
INSERT INTO `glpi_logs` VALUES ('2906','Location','30','0','20','Administrador Administrador (438)','2017-08-25 14:27:14','0','','');
INSERT INTO `glpi_logs` VALUES ('2907','Location','7','Location','17','Administrador Administrador (438)','2017-08-25 14:27:19','0','','OFICINA DE GESTION DEL ASEGURAMIENTO');
INSERT INTO `glpi_logs` VALUES ('2908','Location','31','0','20','Administrador Administrador (438)','2017-08-25 14:27:19','0','','');
INSERT INTO `glpi_logs` VALUES ('2909','Location','7','Location','17','Administrador Administrador (438)','2017-08-25 14:27:23','0','','OFICINA DE SEGUROS LIMA');
INSERT INTO `glpi_logs` VALUES ('2910','Location','32','0','20','Administrador Administrador (438)','2017-08-25 14:27:23','0','','');
INSERT INTO `glpi_logs` VALUES ('2911','Location','8','Location','17','Administrador Administrador (438)','2017-08-25 14:27:41','0','','EQUIPO FUNCIONAL DE FINANCIAMIENTO');
INSERT INTO `glpi_logs` VALUES ('2912','Location','33','0','20','Administrador Administrador (438)','2017-08-25 14:27:41','0','','');
INSERT INTO `glpi_logs` VALUES ('2913','Location','8','Location','17','Administrador Administrador (438)','2017-08-25 14:27:49','0','','OFICINA DE CARTAS DE GARANTÍA');
INSERT INTO `glpi_logs` VALUES ('2914','Location','34','0','20','Administrador Administrador (438)','2017-08-25 14:27:49','0','','');
INSERT INTO `glpi_logs` VALUES ('2915','Location','9','Location','17','Administrador Administrador (438)','2017-08-25 14:28:26','0','','EQUIPO FUNCIONAL DE PRESTACIONES DE SALUD');
INSERT INTO `glpi_logs` VALUES ('2916','Location','35','0','20','Administrador Administrador (438)','2017-08-25 14:28:26','0','','');
INSERT INTO `glpi_logs` VALUES ('2917','Location','10','Location','17','Administrador Administrador (438)','2017-08-25 14:28:42','0','','OFICINAS DE SEGUROS');
INSERT INTO `glpi_logs` VALUES ('2918','Location','36','0','20','Administrador Administrador (438)','2017-08-25 14:28:42','0','','');
INSERT INTO `glpi_logs` VALUES ('2919','Location','10','Location','17','Administrador Administrador (438)','2017-08-25 14:28:49','0','','UNIDAD SALUDPOL LIMA');
INSERT INTO `glpi_logs` VALUES ('2920','Location','37','0','20','Administrador Administrador (438)','2017-08-25 14:28:49','0','','');
INSERT INTO `glpi_logs` VALUES ('2921','Location','10','Location','17','Administrador Administrador (438)','2017-08-25 14:29:01','0','','UNIDAD SALUDPOL LAMBAYEQUE');
INSERT INTO `glpi_logs` VALUES ('2922','Location','38','0','20','Administrador Administrador (438)','2017-08-25 14:29:01','0','','');
INSERT INTO `glpi_logs` VALUES ('2923','Location','10','Location','17','Administrador Administrador (438)','2017-08-25 14:29:06','0','','UNIDAD SALUDPOL TUMBES');
INSERT INTO `glpi_logs` VALUES ('2924','Location','39','0','20','Administrador Administrador (438)','2017-08-25 14:29:06','0','','');
INSERT INTO `glpi_logs` VALUES ('2925','Location','10','Location','17','Administrador Administrador (438)','2017-08-25 14:29:11','0','','UNIDAD SALUDPOL PIURA');
INSERT INTO `glpi_logs` VALUES ('2926','Location','40','0','20','Administrador Administrador (438)','2017-08-25 14:29:11','0','','');
INSERT INTO `glpi_logs` VALUES ('2927','Location','10','Location','17','Administrador Administrador (438)','2017-08-25 14:29:15','0','','UNIDAD SALUDPOL SAN MARTIN');
INSERT INTO `glpi_logs` VALUES ('2928','Location','41','0','20','Administrador Administrador (438)','2017-08-25 14:29:15','0','','');
INSERT INTO `glpi_logs` VALUES ('2929','Location','10','Location','17','Administrador Administrador (438)','2017-08-25 14:29:20','0','','UNIDAD SALUDPOL HUARAZ');
INSERT INTO `glpi_logs` VALUES ('2930','Location','42','0','20','Administrador Administrador (438)','2017-08-25 14:29:20','0','','');
INSERT INTO `glpi_logs` VALUES ('2931','Location','10','Location','17','Administrador Administrador (438)','2017-08-25 14:29:25','0','','UNIDAD SALUDPOL CUSCO');
INSERT INTO `glpi_logs` VALUES ('2932','Location','43','0','20','Administrador Administrador (438)','2017-08-25 14:29:25','0','','');
INSERT INTO `glpi_logs` VALUES ('2933','Location','10','Location','17','Administrador Administrador (438)','2017-08-25 14:29:29','0','','UNIDAD SALUDPOL CAJAMARCA');
INSERT INTO `glpi_logs` VALUES ('2934','Location','44','0','20','Administrador Administrador (438)','2017-08-25 14:29:29','0','','');
INSERT INTO `glpi_logs` VALUES ('2935','Location','10','Location','17','Administrador Administrador (438)','2017-08-25 14:29:33','0','','UNIDAD SALUDPOL MADRE DE DIOS');
INSERT INTO `glpi_logs` VALUES ('2936','Location','45','0','20','Administrador Administrador (438)','2017-08-25 14:29:33','0','','');
INSERT INTO `glpi_logs` VALUES ('2937','Location','10','Location','17','Administrador Administrador (438)','2017-08-25 14:29:38','0','','UNIDAD SALUDPOL AMAZONAS');
INSERT INTO `glpi_logs` VALUES ('2938','Location','46','0','20','Administrador Administrador (438)','2017-08-25 14:29:38','0','','');
INSERT INTO `glpi_logs` VALUES ('2939','Location','10','Location','17','Administrador Administrador (438)','2017-08-25 14:29:42','0','','UNIDAD SALUDPOL AYACUCHO');
INSERT INTO `glpi_logs` VALUES ('2940','Location','47','0','20','Administrador Administrador (438)','2017-08-25 14:29:42','0','','');
INSERT INTO `glpi_logs` VALUES ('2941','Location','10','Location','17','Administrador Administrador (438)','2017-08-25 14:29:46','0','','UNIDAD SALUDPOL ICA');
INSERT INTO `glpi_logs` VALUES ('2942','Location','48','0','20','Administrador Administrador (438)','2017-08-25 14:29:46','0','','');
INSERT INTO `glpi_logs` VALUES ('2943','Location','10','Location','17','Administrador Administrador (438)','2017-08-25 14:29:51','0','','UNIDAD SALUDPOL LORETO');
INSERT INTO `glpi_logs` VALUES ('2944','Location','49','0','20','Administrador Administrador (438)','2017-08-25 14:29:51','0','','');
INSERT INTO `glpi_logs` VALUES ('2945','Location','10','Location','17','Administrador Administrador (438)','2017-08-25 14:29:55','0','','UNIDAD SALUDPOL MOQUEGUA');
INSERT INTO `glpi_logs` VALUES ('2946','Location','50','0','20','Administrador Administrador (438)','2017-08-25 14:29:55','0','','');
INSERT INTO `glpi_logs` VALUES ('2947','Location','10','Location','17','Administrador Administrador (438)','2017-08-25 14:30:00','0','','UNIDAD SALUDPOL TACNA');
INSERT INTO `glpi_logs` VALUES ('2948','Location','51','0','20','Administrador Administrador (438)','2017-08-25 14:30:00','0','','');
INSERT INTO `glpi_logs` VALUES ('2949','Location','10','Location','17','Administrador Administrador (438)','2017-08-25 14:30:04','0','','UNIDAD SALUDPOL PUNO');
INSERT INTO `glpi_logs` VALUES ('2950','Location','52','0','20','Administrador Administrador (438)','2017-08-25 14:30:04','0','','');
INSERT INTO `glpi_logs` VALUES ('2951','Location','10','Location','17','Administrador Administrador (438)','2017-08-25 14:30:09','0','','UNIDAD SALUDPOL AREQUIPA');
INSERT INTO `glpi_logs` VALUES ('2952','Location','53','0','20','Administrador Administrador (438)','2017-08-25 14:30:09','0','','');
INSERT INTO `glpi_logs` VALUES ('2953','Location','10','Location','17','Administrador Administrador (438)','2017-08-25 14:30:14','0','','UNIDAD SALUDPOL LA LIBERTAD');
INSERT INTO `glpi_logs` VALUES ('2954','Location','54','0','20','Administrador Administrador (438)','2017-08-25 14:30:14','0','','');
INSERT INTO `glpi_logs` VALUES ('2955','Location','10','Location','17','Administrador Administrador (438)','2017-08-25 14:30:18','0','','UNIDAD SALUDPOL APURIMAC');
INSERT INTO `glpi_logs` VALUES ('2956','Location','55','0','20','Administrador Administrador (438)','2017-08-25 14:30:18','0','','');
INSERT INTO `glpi_logs` VALUES ('2957','Location','10','Location','17','Administrador Administrador (438)','2017-08-25 14:30:23','0','','UNIDAD SALUDPOL JUNIN');
INSERT INTO `glpi_logs` VALUES ('2958','Location','56','0','20','Administrador Administrador (438)','2017-08-25 14:30:23','0','','');
INSERT INTO `glpi_logs` VALUES ('2959','Location','10','Location','17','Administrador Administrador (438)','2017-08-25 14:30:27','0','','UNIDAD SALUDPOL UCAYALI');
INSERT INTO `glpi_logs` VALUES ('2960','Location','57','0','20','Administrador Administrador (438)','2017-08-25 14:30:27','0','','');
INSERT INTO `glpi_logs` VALUES ('2961','Location','10','Location','17','Administrador Administrador (438)','2017-08-25 14:30:33','0','','UNIDAD SALUDPOL PASCO');
INSERT INTO `glpi_logs` VALUES ('2962','Location','58','0','20','Administrador Administrador (438)','2017-08-25 14:30:33','0','','');
INSERT INTO `glpi_logs` VALUES ('2963','Location','10','Location','17','Administrador Administrador (438)','2017-08-25 14:30:37','0','','UNIDAD SALUDPOL HUANUCO');
INSERT INTO `glpi_logs` VALUES ('2964','Location','59','0','20','Administrador Administrador (438)','2017-08-25 14:30:37','0','','');
INSERT INTO `glpi_logs` VALUES ('2965','Location','10','Location','17','Administrador Administrador (438)','2017-08-25 14:30:42','0','','UNIDAD SALUDPOL HUANCAVELICA');
INSERT INTO `glpi_logs` VALUES ('2966','Location','60','0','20','Administrador Administrador (438)','2017-08-25 14:30:42','0','','');
INSERT INTO `glpi_logs` VALUES ('2967','Ticket','9','','0','Administrador Administrador (438)','2017-08-25 16:27:05','21','&lt;p&gt;Mi PC no prende&lt;/p&gt;
&lt;table style=\"height: 91px;\" width=\"385\"&gt;
&lt;tbody&gt;
&lt;tr style=\"height: 12px;\"&gt;
&lt;td style=\"width: 70.2px; height: 12px;\"&gt; &l','&lt;p&gt;Mi PC no prende&lt;/p&gt;n&lt;table style=\"height: 91px;\" border=\"1\" width=\"385\"&gt;n&lt;tbody&gt;n&lt;tr style=\"height: 12px;\"&gt;n&lt;td style=\"width: 70px; height: 12px');
INSERT INTO `glpi_logs` VALUES ('2968','Ticket','9','','0','Administrador Administrador (438)','2017-08-25 16:27:05','64','tech1 (4)','Administrador (438)');
INSERT INTO `glpi_logs` VALUES ('2969','User','141','','0','Administrador Administrador (438)','2017-08-25 16:40:27','3','&nbsp; (0)','EQUIPO FUNCIONAL DE ADMINISTRACIÓN > OFICINA DE ECONOMÍA > AREA DE CONTABILIDAD (24)');
INSERT INTO `glpi_logs` VALUES ('2970','User','351','','0','Administrador Administrador (438)','2017-08-25 16:41:20','3','&nbsp; (0)','EQUIPO FUNCIONAL DE ESTADÍSTICA, TECNOLOGÍA DE LA INFORMACIÓN Y COMUNICACIONES (6)');
INSERT INTO `glpi_logs` VALUES ('2971','User','184','','0','Administrador Administrador (438)','2017-08-25 16:41:44','3','&nbsp; (0)','EQUIPO FUNCIONAL DE ESTADÍSTICA, TECNOLOGÍA DE LA INFORMACIÓN Y COMUNICACIONES (6)');
INSERT INTO `glpi_logs` VALUES ('2972','UserCategory','2','0','20','Administrador Administrador (438)','2017-08-25 16:44:05','0','','');
INSERT INTO `glpi_logs` VALUES ('2973','Ticket','12','User','15','Escalera Requejo Luis (177)','2017-08-25 17:08:09','0','','Escalera Requejo Luis (177)');
INSERT INTO `glpi_logs` VALUES ('2974','Ticket','12','User','15','Escalera Requejo Luis (177)','2017-08-25 17:08:09','0','','Mendoza Martel Francisco Jesus (436)');
INSERT INTO `glpi_logs` VALUES ('2975','Ticket','12','0','20','Escalera Requejo Luis (177)','2017-08-25 17:08:09','0','','');
INSERT INTO `glpi_logs` VALUES ('2976','Ticket','13','User','15','Mendoza Martel Francisco Jesus (436)','2017-08-25 17:54:32','0','','Mendoza Martel Francisco Jesus (436)');
INSERT INTO `glpi_logs` VALUES ('2977','Ticket','13','0','20','Mendoza Martel Francisco Jesus (436)','2017-08-25 17:54:32','0','','');
INSERT INTO `glpi_logs` VALUES ('2978','Ticket','14','User','15','Mendoza Martel Francisco Jesus (436)','2017-08-25 18:39:44','0','','Mendoza Martel Francisco Jesus (436)');
INSERT INTO `glpi_logs` VALUES ('2979','Ticket','14','0','20','Mendoza Martel Francisco Jesus (436)','2017-08-25 18:39:44','0','','');
INSERT INTO `glpi_logs` VALUES ('2980','Ticket','15','User','15','Mendoza Martel Francisco Jesus (436)','2017-08-25 18:42:04','0','','Mendoza Martel Francisco Jesus (436)');
INSERT INTO `glpi_logs` VALUES ('2981','Ticket','15','0','20','Mendoza Martel Francisco Jesus (436)','2017-08-25 18:42:04','0','','');
INSERT INTO `glpi_logs` VALUES ('2982','Ticket','16','User','15','Mendoza Martel Francisco Jesus (436)','2017-08-25 19:13:33','0','','Mendoza Martel Francisco Jesus (436)');
INSERT INTO `glpi_logs` VALUES ('2983','Ticket','16','0','20','Mendoza Martel Francisco Jesus (436)','2017-08-25 19:13:33','0','','');

### Dump table glpi_mailcollectors

DROP TABLE IF EXISTS `glpi_mailcollectors`;
CREATE TABLE `glpi_mailcollectors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `host` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `login` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `filesize_max` int(11) NOT NULL DEFAULT '2097152',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `date_mod` datetime DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `passwd` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `accepted` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `refused` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `use_kerberos` tinyint(1) NOT NULL DEFAULT '0',
  `errors` int(11) NOT NULL DEFAULT '0',
  `use_mail_date` tinyint(1) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `is_active` (`is_active`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_manufacturers

DROP TABLE IF EXISTS `glpi_manufacturers`;
CREATE TABLE `glpi_manufacturers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_monitormodels

DROP TABLE IF EXISTS `glpi_monitormodels`;
CREATE TABLE `glpi_monitormodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_monitors

DROP TABLE IF EXISTS `glpi_monitors`;
CREATE TABLE `glpi_monitors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `contact` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_num` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `size` int(11) NOT NULL DEFAULT '0',
  `have_micro` tinyint(1) NOT NULL DEFAULT '0',
  `have_speaker` tinyint(1) NOT NULL DEFAULT '0',
  `have_subd` tinyint(1) NOT NULL DEFAULT '0',
  `have_bnc` tinyint(1) NOT NULL DEFAULT '0',
  `have_dvi` tinyint(1) NOT NULL DEFAULT '0',
  `have_pivot` tinyint(1) NOT NULL DEFAULT '0',
  `have_hdmi` tinyint(1) NOT NULL DEFAULT '0',
  `have_displayport` tinyint(1) NOT NULL DEFAULT '0',
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `monitortypes_id` int(11) NOT NULL DEFAULT '0',
  `monitormodels_id` int(11) NOT NULL DEFAULT '0',
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `is_global` tinyint(1) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  `ticket_tco` decimal(20,4) DEFAULT '0.0000',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_template` (`is_template`),
  KEY `is_global` (`is_global`),
  KEY `entities_id` (`entities_id`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `groups_id` (`groups_id`),
  KEY `users_id` (`users_id`),
  KEY `locations_id` (`locations_id`),
  KEY `monitormodels_id` (`monitormodels_id`),
  KEY `states_id` (`states_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `monitortypes_id` (`monitortypes_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `serial` (`serial`),
  KEY `otherserial` (`otherserial`),
  KEY `date_creation` (`date_creation`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_monitortypes

DROP TABLE IF EXISTS `glpi_monitortypes`;
CREATE TABLE `glpi_monitortypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_netpoints

DROP TABLE IF EXISTS `glpi_netpoints`;
CREATE TABLE `glpi_netpoints` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `complete` (`entities_id`,`locations_id`,`name`),
  KEY `location_name` (`locations_id`,`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkaliases

DROP TABLE IF EXISTS `glpi_networkaliases`;
CREATE TABLE `glpi_networkaliases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `networknames_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fqdns_id` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `name` (`name`),
  KEY `networknames_id` (`networknames_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkequipmentfirmwares

DROP TABLE IF EXISTS `glpi_networkequipmentfirmwares`;
CREATE TABLE `glpi_networkequipmentfirmwares` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkequipmentmodels

DROP TABLE IF EXISTS `glpi_networkequipmentmodels`;
CREATE TABLE `glpi_networkequipmentmodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkequipments

DROP TABLE IF EXISTS `glpi_networkequipments`;
CREATE TABLE `glpi_networkequipments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ram` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_num` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `domains_id` int(11) NOT NULL DEFAULT '0',
  `networks_id` int(11) NOT NULL DEFAULT '0',
  `networkequipmenttypes_id` int(11) NOT NULL DEFAULT '0',
  `networkequipmentmodels_id` int(11) NOT NULL DEFAULT '0',
  `networkequipmentfirmwares_id` int(11) NOT NULL DEFAULT '0',
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  `ticket_tco` decimal(20,4) DEFAULT '0.0000',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_template` (`is_template`),
  KEY `domains_id` (`domains_id`),
  KEY `networkequipmentfirmwares_id` (`networkequipmentfirmwares_id`),
  KEY `entities_id` (`entities_id`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `groups_id` (`groups_id`),
  KEY `users_id` (`users_id`),
  KEY `locations_id` (`locations_id`),
  KEY `networkequipmentmodels_id` (`networkequipmentmodels_id`),
  KEY `networks_id` (`networks_id`),
  KEY `states_id` (`states_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `networkequipmenttypes_id` (`networkequipmenttypes_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `date_mod` (`date_mod`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `serial` (`serial`),
  KEY `otherserial` (`otherserial`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkequipmenttypes

DROP TABLE IF EXISTS `glpi_networkequipmenttypes`;
CREATE TABLE `glpi_networkequipmenttypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkinterfaces

DROP TABLE IF EXISTS `glpi_networkinterfaces`;
CREATE TABLE `glpi_networkinterfaces` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networknames

DROP TABLE IF EXISTS `glpi_networknames`;
CREATE TABLE `glpi_networknames` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `fqdns_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `FQDN` (`name`,`fqdns_id`),
  KEY `name` (`name`),
  KEY `fqdns_id` (`fqdns_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `item` (`itemtype`,`items_id`,`is_deleted`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkportaggregates

DROP TABLE IF EXISTS `glpi_networkportaggregates`;
CREATE TABLE `glpi_networkportaggregates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `networkports_id` int(11) NOT NULL DEFAULT '0',
  `networkports_id_list` text COLLATE utf8_unicode_ci COMMENT 'array of associated networkports_id',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `networkports_id` (`networkports_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkportaliases

DROP TABLE IF EXISTS `glpi_networkportaliases`;
CREATE TABLE `glpi_networkportaliases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `networkports_id` int(11) NOT NULL DEFAULT '0',
  `networkports_id_alias` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `networkports_id` (`networkports_id`),
  KEY `networkports_id_alias` (`networkports_id_alias`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkportdialups

DROP TABLE IF EXISTS `glpi_networkportdialups`;
CREATE TABLE `glpi_networkportdialups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `networkports_id` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `networkports_id` (`networkports_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkportethernets

DROP TABLE IF EXISTS `glpi_networkportethernets`;
CREATE TABLE `glpi_networkportethernets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `networkports_id` int(11) NOT NULL DEFAULT '0',
  `items_devicenetworkcards_id` int(11) NOT NULL DEFAULT '0',
  `netpoints_id` int(11) NOT NULL DEFAULT '0',
  `type` varchar(10) COLLATE utf8_unicode_ci DEFAULT '' COMMENT 'T, LX, SX',
  `speed` int(11) NOT NULL DEFAULT '10' COMMENT 'Mbit/s: 10, 100, 1000, 10000',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `networkports_id` (`networkports_id`),
  KEY `card` (`items_devicenetworkcards_id`),
  KEY `netpoint` (`netpoints_id`),
  KEY `type` (`type`),
  KEY `speed` (`speed`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkportfiberchannels

DROP TABLE IF EXISTS `glpi_networkportfiberchannels`;
CREATE TABLE `glpi_networkportfiberchannels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `networkports_id` int(11) NOT NULL DEFAULT '0',
  `items_devicenetworkcards_id` int(11) NOT NULL DEFAULT '0',
  `netpoints_id` int(11) NOT NULL DEFAULT '0',
  `wwn` varchar(16) COLLATE utf8_unicode_ci DEFAULT '',
  `speed` int(11) NOT NULL DEFAULT '10' COMMENT 'Mbit/s: 10, 100, 1000, 10000',
  PRIMARY KEY (`id`),
  UNIQUE KEY `networkports_id` (`networkports_id`),
  KEY `card` (`items_devicenetworkcards_id`),
  KEY `netpoint` (`netpoints_id`),
  KEY `wwn` (`wwn`),
  KEY `speed` (`speed`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkportlocals

DROP TABLE IF EXISTS `glpi_networkportlocals`;
CREATE TABLE `glpi_networkportlocals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `networkports_id` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `networkports_id` (`networkports_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkports

DROP TABLE IF EXISTS `glpi_networkports`;
CREATE TABLE `glpi_networkports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `logical_number` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `instantiation_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mac` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `on_device` (`items_id`,`itemtype`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `mac` (`mac`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkports_networkports

DROP TABLE IF EXISTS `glpi_networkports_networkports`;
CREATE TABLE `glpi_networkports_networkports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `networkports_id_1` int(11) NOT NULL DEFAULT '0',
  `networkports_id_2` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`networkports_id_1`,`networkports_id_2`),
  KEY `networkports_id_2` (`networkports_id_2`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkports_vlans

DROP TABLE IF EXISTS `glpi_networkports_vlans`;
CREATE TABLE `glpi_networkports_vlans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `networkports_id` int(11) NOT NULL DEFAULT '0',
  `vlans_id` int(11) NOT NULL DEFAULT '0',
  `tagged` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`networkports_id`,`vlans_id`),
  KEY `vlans_id` (`vlans_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkportwifis

DROP TABLE IF EXISTS `glpi_networkportwifis`;
CREATE TABLE `glpi_networkportwifis` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `networkports_id` int(11) NOT NULL DEFAULT '0',
  `items_devicenetworkcards_id` int(11) NOT NULL DEFAULT '0',
  `wifinetworks_id` int(11) NOT NULL DEFAULT '0',
  `networkportwifis_id` int(11) NOT NULL DEFAULT '0' COMMENT 'only useful in case of Managed node',
  `version` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'a, a/b, a/b/g, a/b/g/n, a/b/g/n/y',
  `mode` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'ad-hoc, managed, master, repeater, secondary, monitor, auto',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `networkports_id` (`networkports_id`),
  KEY `card` (`items_devicenetworkcards_id`),
  KEY `essid` (`wifinetworks_id`),
  KEY `version` (`version`),
  KEY `mode` (`mode`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networks

DROP TABLE IF EXISTS `glpi_networks`;
CREATE TABLE `glpi_networks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_notepads

DROP TABLE IF EXISTS `glpi_notepads`;
CREATE TABLE `glpi_notepads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemtype` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `date` datetime DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `users_id_lastupdater` int(11) NOT NULL DEFAULT '0',
  `content` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date` (`date`),
  KEY `users_id_lastupdater` (`users_id_lastupdater`),
  KEY `users_id` (`users_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_notifications

DROP TABLE IF EXISTS `glpi_notifications`;
CREATE TABLE `glpi_notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `event` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `mode` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `notificationtemplates_id` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `itemtype` (`itemtype`),
  KEY `entities_id` (`entities_id`),
  KEY `is_active` (`is_active`),
  KEY `date_mod` (`date_mod`),
  KEY `is_recursive` (`is_recursive`),
  KEY `notificationtemplates_id` (`notificationtemplates_id`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_notifications` VALUES ('1','Alert Tickets not closed','0','Ticket','alertnotclosed','mail','6','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('2','New Ticket','0','Ticket','new','mail','4','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('3','Update Ticket','0','Ticket','update','mail','4','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('4','Close Ticket','0','Ticket','closed','mail','4','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('5','Add Followup','0','Ticket','add_followup','mail','4','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('6','Add Task','0','Ticket','add_task','mail','4','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('7','Update Followup','0','Ticket','update_followup','mail','4','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('8','Update Task','0','Ticket','update_task','mail','4','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('9','Delete Followup','0','Ticket','delete_followup','mail','4','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('10','Delete Task','0','Ticket','delete_task','mail','4','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('11','Resolve ticket','0','Ticket','solved','mail','4','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('12','Ticket Validation','0','Ticket','validation','mail','7','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('13','New Reservation','0','Reservation','new','mail','2','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('14','Update Reservation','0','Reservation','update','mail','2','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('15','Delete Reservation','0','Reservation','delete','mail','2','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('16','Alert Reservation','0','Reservation','alert','mail','3','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('17','Contract Notice','0','Contract','notice','mail','12','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('18','Contract End','0','Contract','end','mail','12','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('19','MySQL Synchronization','0','DBConnection','desynchronization','mail','1','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('20','Cartridges','0','CartridgeItem','alert','mail','8','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('21','Consumables','0','ConsumableItem','alert','mail','9','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('22','Infocoms','0','Infocom','alert','mail','10','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('23','Software Licenses','0','SoftwareLicense','alert','mail','11','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('24','Ticket Recall','0','Ticket','recall','mail','4','','1','1','2011-03-04 11:35:13',NULL);
INSERT INTO `glpi_notifications` VALUES ('25','Password Forget','0','User','passwordforget','mail','13','','1','1','2011-03-04 11:35:13',NULL);
INSERT INTO `glpi_notifications` VALUES ('26','Ticket Satisfaction','0','Ticket','satisfaction','mail','14','','1','1','2011-03-04 11:35:15',NULL);
INSERT INTO `glpi_notifications` VALUES ('27','Item not unique','0','FieldUnicity','refuse','mail','15','','1','1','2011-03-04 11:35:16',NULL);
INSERT INTO `glpi_notifications` VALUES ('28','Crontask Watcher','0','Crontask','alert','mail','16','','1','1','2011-03-04 11:35:16',NULL);
INSERT INTO `glpi_notifications` VALUES ('29','New Problem','0','Problem','new','mail','17','','1','1','2011-12-06 09:48:33',NULL);
INSERT INTO `glpi_notifications` VALUES ('30','Update Problem','0','Problem','update','mail','17','','1','1','2011-12-06 09:48:33',NULL);
INSERT INTO `glpi_notifications` VALUES ('31','Resolve Problem','0','Problem','solved','mail','17','','1','1','2011-12-06 09:48:33',NULL);
INSERT INTO `glpi_notifications` VALUES ('32','Add Task','0','Problem','add_task','mail','17','','1','1','2011-12-06 09:48:33',NULL);
INSERT INTO `glpi_notifications` VALUES ('33','Update Task','0','Problem','update_task','mail','17','','1','1','2011-12-06 09:48:33',NULL);
INSERT INTO `glpi_notifications` VALUES ('34','Delete Task','0','Problem','delete_task','mail','17','','1','1','2011-12-06 09:48:33',NULL);
INSERT INTO `glpi_notifications` VALUES ('35','Close Problem','0','Problem','closed','mail','17','','1','1','2011-12-06 09:48:33',NULL);
INSERT INTO `glpi_notifications` VALUES ('36','Delete Problem','0','Problem','delete','mail','17','','1','1','2011-12-06 09:48:33',NULL);
INSERT INTO `glpi_notifications` VALUES ('37','Ticket Validation Answer','0','Ticket','validation_answer','mail','7','','1','1','2014-01-15 14:35:24',NULL);
INSERT INTO `glpi_notifications` VALUES ('38','Contract End Periodicity','0','Contract','periodicity','mail','12','','1','1','2014-01-15 14:35:24',NULL);
INSERT INTO `glpi_notifications` VALUES ('39','Contract Notice Periodicity','0','Contract','periodicitynotice','mail','12','','1','1','2014-01-15 14:35:24',NULL);
INSERT INTO `glpi_notifications` VALUES ('40','Planning recall','0','PlanningRecall','planningrecall','mail','18','','1','1','2014-01-15 14:35:24',NULL);
INSERT INTO `glpi_notifications` VALUES ('41','Delete Ticket','0','Ticket','delete','mail','4','','1','1','2014-01-15 14:35:26',NULL);
INSERT INTO `glpi_notifications` VALUES ('42','New Change','0','Change','new','mail','19','','1','1','2014-06-18 08:02:07',NULL);
INSERT INTO `glpi_notifications` VALUES ('43','Update Change','0','Change','update','mail','19','','1','1','2014-06-18 08:02:07',NULL);
INSERT INTO `glpi_notifications` VALUES ('44','Resolve Change','0','Change','solved','mail','19','','1','1','2014-06-18 08:02:07',NULL);
INSERT INTO `glpi_notifications` VALUES ('45','Add Task','0','Change','add_task','mail','19','','1','1','2014-06-18 08:02:07',NULL);
INSERT INTO `glpi_notifications` VALUES ('46','Update Task','0','Change','update_task','mail','19','','1','1','2014-06-18 08:02:07',NULL);
INSERT INTO `glpi_notifications` VALUES ('47','Delete Task','0','Change','delete_task','mail','19','','1','1','2014-06-18 08:02:07',NULL);
INSERT INTO `glpi_notifications` VALUES ('48','Close Change','0','Change','closed','mail','19','','1','1','2014-06-18 08:02:07',NULL);
INSERT INTO `glpi_notifications` VALUES ('49','Delete Change','0','Change','delete','mail','19','','1','1','2014-06-18 08:02:07',NULL);
INSERT INTO `glpi_notifications` VALUES ('50','Ticket Satisfaction Answer','0','Ticket','replysatisfaction','mail','14','','1','1','2014-06-18 08:02:08',NULL);
INSERT INTO `glpi_notifications` VALUES ('51','Receiver errors','0','MailCollector','error','mail','20','','1','1','2014-06-18 08:02:08',NULL);
INSERT INTO `glpi_notifications` VALUES ('52','New Project','0','Project','new','mail','21','','1','1','2014-06-18 08:02:09',NULL);
INSERT INTO `glpi_notifications` VALUES ('53','Update Project','0','Project','update','mail','21','','1','1','2014-06-18 08:02:09',NULL);
INSERT INTO `glpi_notifications` VALUES ('54','Delete Project','0','Project','delete','mail','21','','1','1','2014-06-18 08:02:09',NULL);
INSERT INTO `glpi_notifications` VALUES ('55','New Project Task','0','ProjectTask','new','mail','22','','1','1','2014-06-18 08:02:09',NULL);
INSERT INTO `glpi_notifications` VALUES ('56','Update Project Task','0','ProjectTask','update','mail','22','','1','1','2014-06-18 08:02:09',NULL);
INSERT INTO `glpi_notifications` VALUES ('57','Delete Project Task','0','ProjectTask','delete','mail','22','','1','1','2014-06-18 08:02:09',NULL);
INSERT INTO `glpi_notifications` VALUES ('58','Request Unlock Items','0','ObjectLock','unlock','mail','23','','1','1','2016-02-08 16:57:46',NULL);

### Dump table glpi_notificationtargets

DROP TABLE IF EXISTS `glpi_notificationtargets`;
CREATE TABLE `glpi_notificationtargets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '0',
  `notifications_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `items` (`type`,`items_id`),
  KEY `notifications_id` (`notifications_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_notificationtargets` VALUES ('1','3','1','13');
INSERT INTO `glpi_notificationtargets` VALUES ('2','1','1','13');
INSERT INTO `glpi_notificationtargets` VALUES ('3','3','2','2');
INSERT INTO `glpi_notificationtargets` VALUES ('4','1','1','2');
INSERT INTO `glpi_notificationtargets` VALUES ('5','1','1','3');
INSERT INTO `glpi_notificationtargets` VALUES ('6','1','1','5');
INSERT INTO `glpi_notificationtargets` VALUES ('7','1','1','4');
INSERT INTO `glpi_notificationtargets` VALUES ('8','2','1','3');
INSERT INTO `glpi_notificationtargets` VALUES ('9','4','1','3');
INSERT INTO `glpi_notificationtargets` VALUES ('10','3','1','2');
INSERT INTO `glpi_notificationtargets` VALUES ('11','3','1','3');
INSERT INTO `glpi_notificationtargets` VALUES ('12','3','1','5');
INSERT INTO `glpi_notificationtargets` VALUES ('13','3','1','4');
INSERT INTO `glpi_notificationtargets` VALUES ('14','1','1','19');
INSERT INTO `glpi_notificationtargets` VALUES ('15','14','1','12');
INSERT INTO `glpi_notificationtargets` VALUES ('16','3','1','14');
INSERT INTO `glpi_notificationtargets` VALUES ('17','1','1','14');
INSERT INTO `glpi_notificationtargets` VALUES ('18','3','1','15');
INSERT INTO `glpi_notificationtargets` VALUES ('19','1','1','15');
INSERT INTO `glpi_notificationtargets` VALUES ('20','1','1','6');
INSERT INTO `glpi_notificationtargets` VALUES ('21','3','1','6');
INSERT INTO `glpi_notificationtargets` VALUES ('22','1','1','7');
INSERT INTO `glpi_notificationtargets` VALUES ('23','3','1','7');
INSERT INTO `glpi_notificationtargets` VALUES ('24','1','1','8');
INSERT INTO `glpi_notificationtargets` VALUES ('25','3','1','8');
INSERT INTO `glpi_notificationtargets` VALUES ('26','1','1','9');
INSERT INTO `glpi_notificationtargets` VALUES ('27','3','1','9');
INSERT INTO `glpi_notificationtargets` VALUES ('28','1','1','10');
INSERT INTO `glpi_notificationtargets` VALUES ('29','3','1','10');
INSERT INTO `glpi_notificationtargets` VALUES ('30','1','1','11');
INSERT INTO `glpi_notificationtargets` VALUES ('31','3','1','11');
INSERT INTO `glpi_notificationtargets` VALUES ('32','19','1','25');
INSERT INTO `glpi_notificationtargets` VALUES ('33','3','1','26');
INSERT INTO `glpi_notificationtargets` VALUES ('34','21','1','2');
INSERT INTO `glpi_notificationtargets` VALUES ('35','21','1','3');
INSERT INTO `glpi_notificationtargets` VALUES ('36','21','1','5');
INSERT INTO `glpi_notificationtargets` VALUES ('37','21','1','4');
INSERT INTO `glpi_notificationtargets` VALUES ('38','21','1','6');
INSERT INTO `glpi_notificationtargets` VALUES ('39','21','1','7');
INSERT INTO `glpi_notificationtargets` VALUES ('40','21','1','8');
INSERT INTO `glpi_notificationtargets` VALUES ('41','21','1','9');
INSERT INTO `glpi_notificationtargets` VALUES ('42','21','1','10');
INSERT INTO `glpi_notificationtargets` VALUES ('43','21','1','11');
INSERT INTO `glpi_notificationtargets` VALUES ('75','1','1','41');
INSERT INTO `glpi_notificationtargets` VALUES ('46','1','1','28');
INSERT INTO `glpi_notificationtargets` VALUES ('47','3','1','29');
INSERT INTO `glpi_notificationtargets` VALUES ('48','1','1','29');
INSERT INTO `glpi_notificationtargets` VALUES ('49','21','1','29');
INSERT INTO `glpi_notificationtargets` VALUES ('50','2','1','30');
INSERT INTO `glpi_notificationtargets` VALUES ('51','4','1','30');
INSERT INTO `glpi_notificationtargets` VALUES ('52','3','1','30');
INSERT INTO `glpi_notificationtargets` VALUES ('53','1','1','30');
INSERT INTO `glpi_notificationtargets` VALUES ('54','21','1','30');
INSERT INTO `glpi_notificationtargets` VALUES ('55','3','1','31');
INSERT INTO `glpi_notificationtargets` VALUES ('56','1','1','31');
INSERT INTO `glpi_notificationtargets` VALUES ('57','21','1','31');
INSERT INTO `glpi_notificationtargets` VALUES ('58','3','1','32');
INSERT INTO `glpi_notificationtargets` VALUES ('59','1','1','32');
INSERT INTO `glpi_notificationtargets` VALUES ('60','21','1','32');
INSERT INTO `glpi_notificationtargets` VALUES ('61','3','1','33');
INSERT INTO `glpi_notificationtargets` VALUES ('62','1','1','33');
INSERT INTO `glpi_notificationtargets` VALUES ('63','21','1','33');
INSERT INTO `glpi_notificationtargets` VALUES ('64','3','1','34');
INSERT INTO `glpi_notificationtargets` VALUES ('65','1','1','34');
INSERT INTO `glpi_notificationtargets` VALUES ('66','21','1','34');
INSERT INTO `glpi_notificationtargets` VALUES ('67','3','1','35');
INSERT INTO `glpi_notificationtargets` VALUES ('68','1','1','35');
INSERT INTO `glpi_notificationtargets` VALUES ('69','21','1','35');
INSERT INTO `glpi_notificationtargets` VALUES ('70','3','1','36');
INSERT INTO `glpi_notificationtargets` VALUES ('71','1','1','36');
INSERT INTO `glpi_notificationtargets` VALUES ('72','21','1','36');
INSERT INTO `glpi_notificationtargets` VALUES ('73','14','1','37');
INSERT INTO `glpi_notificationtargets` VALUES ('74','3','1','40');
INSERT INTO `glpi_notificationtargets` VALUES ('76','3','1','42');
INSERT INTO `glpi_notificationtargets` VALUES ('77','1','1','42');
INSERT INTO `glpi_notificationtargets` VALUES ('78','21','1','42');
INSERT INTO `glpi_notificationtargets` VALUES ('79','2','1','43');
INSERT INTO `glpi_notificationtargets` VALUES ('80','4','1','43');
INSERT INTO `glpi_notificationtargets` VALUES ('81','3','1','43');
INSERT INTO `glpi_notificationtargets` VALUES ('82','1','1','43');
INSERT INTO `glpi_notificationtargets` VALUES ('83','21','1','43');
INSERT INTO `glpi_notificationtargets` VALUES ('84','3','1','44');
INSERT INTO `glpi_notificationtargets` VALUES ('85','1','1','44');
INSERT INTO `glpi_notificationtargets` VALUES ('86','21','1','44');
INSERT INTO `glpi_notificationtargets` VALUES ('87','3','1','45');
INSERT INTO `glpi_notificationtargets` VALUES ('88','1','1','45');
INSERT INTO `glpi_notificationtargets` VALUES ('89','21','1','45');
INSERT INTO `glpi_notificationtargets` VALUES ('90','3','1','46');
INSERT INTO `glpi_notificationtargets` VALUES ('91','1','1','46');
INSERT INTO `glpi_notificationtargets` VALUES ('92','21','1','46');
INSERT INTO `glpi_notificationtargets` VALUES ('93','3','1','47');
INSERT INTO `glpi_notificationtargets` VALUES ('94','1','1','47');
INSERT INTO `glpi_notificationtargets` VALUES ('95','21','1','47');
INSERT INTO `glpi_notificationtargets` VALUES ('96','3','1','48');
INSERT INTO `glpi_notificationtargets` VALUES ('97','1','1','48');
INSERT INTO `glpi_notificationtargets` VALUES ('98','21','1','48');
INSERT INTO `glpi_notificationtargets` VALUES ('99','3','1','49');
INSERT INTO `glpi_notificationtargets` VALUES ('100','1','1','49');
INSERT INTO `glpi_notificationtargets` VALUES ('101','21','1','49');
INSERT INTO `glpi_notificationtargets` VALUES ('102','3','1','50');
INSERT INTO `glpi_notificationtargets` VALUES ('103','2','1','50');
INSERT INTO `glpi_notificationtargets` VALUES ('104','1','1','51');
INSERT INTO `glpi_notificationtargets` VALUES ('105','27','1','52');
INSERT INTO `glpi_notificationtargets` VALUES ('106','1','1','52');
INSERT INTO `glpi_notificationtargets` VALUES ('107','28','1','52');
INSERT INTO `glpi_notificationtargets` VALUES ('108','27','1','53');
INSERT INTO `glpi_notificationtargets` VALUES ('109','1','1','53');
INSERT INTO `glpi_notificationtargets` VALUES ('110','28','1','53');
INSERT INTO `glpi_notificationtargets` VALUES ('111','27','1','54');
INSERT INTO `glpi_notificationtargets` VALUES ('112','1','1','54');
INSERT INTO `glpi_notificationtargets` VALUES ('113','28','1','54');
INSERT INTO `glpi_notificationtargets` VALUES ('114','31','1','55');
INSERT INTO `glpi_notificationtargets` VALUES ('115','1','1','55');
INSERT INTO `glpi_notificationtargets` VALUES ('116','32','1','55');
INSERT INTO `glpi_notificationtargets` VALUES ('117','31','1','56');
INSERT INTO `glpi_notificationtargets` VALUES ('118','1','1','56');
INSERT INTO `glpi_notificationtargets` VALUES ('119','32','1','56');
INSERT INTO `glpi_notificationtargets` VALUES ('120','31','1','57');
INSERT INTO `glpi_notificationtargets` VALUES ('121','1','1','57');
INSERT INTO `glpi_notificationtargets` VALUES ('122','32','1','57');
INSERT INTO `glpi_notificationtargets` VALUES ('123','19','1','58');

### Dump table glpi_notificationtemplates

DROP TABLE IF EXISTS `glpi_notificationtemplates`;
CREATE TABLE `glpi_notificationtemplates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `date_mod` datetime DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `css` text COLLATE utf8_unicode_ci,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `itemtype` (`itemtype`),
  KEY `date_mod` (`date_mod`),
  KEY `name` (`name`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_notificationtemplates` VALUES ('1','MySQL Synchronization','DBConnection','2010-02-01 15:51:46','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('2','Reservations','Reservation','2010-02-03 14:03:45','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('3','Alert Reservation','Reservation','2010-02-03 14:03:45','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('4','Tickets','Ticket','2010-02-07 21:39:15','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('5','Tickets (Simple)','Ticket','2010-02-07 21:39:15','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('6','Alert Tickets not closed','Ticket','2010-02-07 21:39:15','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('7','Tickets Validation','Ticket','2010-02-26 21:39:15','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('8','Cartridges','CartridgeItem','2010-02-16 13:17:24','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('9','Consumables','ConsumableItem','2010-02-16 13:17:38','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('10','Infocoms','Infocom','2010-02-16 13:17:55','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('11','Licenses','SoftwareLicense','2010-02-16 13:18:12','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('12','Contracts','Contract','2010-02-16 13:18:12','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('13','Password Forget','User','2011-03-04 11:35:13',NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('14','Ticket Satisfaction','Ticket','2011-03-04 11:35:15',NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('15','Item not unique','FieldUnicity','2011-03-04 11:35:16',NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('16','Crontask','Crontask','2011-03-04 11:35:16',NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('17','Problems','Problem','2011-12-06 09:48:33',NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('18','Planning recall','PlanningRecall','2014-01-15 14:35:24',NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('19','Changes','Change','2014-06-18 08:02:07',NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('20','Receiver errors','MailCollector','2014-06-18 08:02:08',NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('21','Projects','Project','2014-06-18 08:02:09',NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('22','Project Tasks','ProjectTask','2014-06-18 08:02:09',NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('23','Unlock Item request','ObjectLock','2016-02-08 16:57:46',NULL,NULL,NULL);

### Dump table glpi_notificationtemplatetranslations

DROP TABLE IF EXISTS `glpi_notificationtemplatetranslations`;
CREATE TABLE `glpi_notificationtemplatetranslations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `notificationtemplates_id` int(11) NOT NULL DEFAULT '0',
  `language` char(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `subject` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `content_text` text COLLATE utf8_unicode_ci,
  `content_html` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `notificationtemplates_id` (`notificationtemplates_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('1','1','','##lang.dbconnection.title##','##lang.dbconnection.delay## : ##dbconnection.delay##
','&lt;p&gt;##lang.dbconnection.delay## : ##dbconnection.delay##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('2','2','','##reservation.action##','======================================================================
##lang.reservation.user##: ##reservation.user##
##lang.reservation.item.name##: ##reservation.itemtype## - ##reservation.item.name##
##IFreservation.tech## ##lang.reservation.tech## ##reservation.tech## ##ENDIFreservation.tech##
##lang.reservation.begin##: ##reservation.begin##
##lang.reservation.end##: ##reservation.end##
##lang.reservation.comment##: ##reservation.comment##
======================================================================
','&lt;!-- description{ color: inherit; background: #ebebeb;border-style: solid;border-color: #8d8d8d; border-width: 0px 1px 1px 0px; } --&gt;
&lt;p&gt;&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.reservation.user##:&lt;/span&gt;##reservation.user##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.reservation.item.name##:&lt;/span&gt;##reservation.itemtype## - ##reservation.item.name##&lt;br /&gt;##IFreservation.tech## ##lang.reservation.tech## ##reservation.tech####ENDIFreservation.tech##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.reservation.begin##:&lt;/span&gt; ##reservation.begin##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.reservation.end##:&lt;/span&gt;##reservation.end##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.reservation.comment##:&lt;/span&gt; ##reservation.comment##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('3','3','','##reservation.action##  ##reservation.entity##','##lang.reservation.entity## : ##reservation.entity##


##FOREACHreservations##
##lang.reservation.itemtype## : ##reservation.itemtype##

 ##lang.reservation.item## : ##reservation.item##

 ##reservation.url##

 ##ENDFOREACHreservations##','&lt;p&gt;##lang.reservation.entity## : ##reservation.entity## &lt;br /&gt; &lt;br /&gt;
##FOREACHreservations## &lt;br /&gt;##lang.reservation.itemtype## :  ##reservation.itemtype##&lt;br /&gt;
 ##lang.reservation.item## :  ##reservation.item##&lt;br /&gt; &lt;br /&gt;
 &lt;a href=\"##reservation.url##\"&gt; ##reservation.url##&lt;/a&gt;&lt;br /&gt;
 ##ENDFOREACHreservations##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('4','4','','##ticket.action## ##ticket.title##',' ##IFticket.storestatus=5##
 ##lang.ticket.url## : ##ticket.urlapprove##
 ##lang.ticket.autoclosewarning##
 ##lang.ticket.solvedate## : ##ticket.solvedate##
 ##lang.ticket.solution.type## : ##ticket.solution.type##
 ##lang.ticket.solution.description## : ##ticket.solution.description## ##ENDIFticket.storestatus##
 ##ELSEticket.storestatus## ##lang.ticket.url## : ##ticket.url## ##ENDELSEticket.storestatus##

 ##lang.ticket.description##

 ##lang.ticket.title## : ##ticket.title##
 ##lang.ticket.authors## : ##IFticket.authors## ##ticket.authors## ##ENDIFticket.authors## ##ELSEticket.authors##--##ENDELSEticket.authors##
 ##lang.ticket.creationdate## : ##ticket.creationdate##
 ##lang.ticket.closedate## : ##ticket.closedate##
 ##lang.ticket.requesttype## : ##ticket.requesttype##
##lang.ticket.item.name## :

##FOREACHitems##

 ##IFticket.itemtype##
  ##ticket.itemtype## - ##ticket.item.name##
  ##IFticket.item.model## ##lang.ticket.item.model## : ##ticket.item.model## ##ENDIFticket.item.model##
  ##IFticket.item.serial## ##lang.ticket.item.serial## : ##ticket.item.serial## ##ENDIFticket.item.serial##
  ##IFticket.item.otherserial## ##lang.ticket.item.otherserial## : ##ticket.item.otherserial## ##ENDIFticket.item.otherserial##
 ##ENDIFticket.itemtype##

##ENDFOREACHitems##
##IFticket.assigntousers## ##lang.ticket.assigntousers## : ##ticket.assigntousers## ##ENDIFticket.assigntousers##
 ##lang.ticket.status## : ##ticket.status##
##IFticket.assigntogroups## ##lang.ticket.assigntogroups## : ##ticket.assigntogroups## ##ENDIFticket.assigntogroups##
 ##lang.ticket.urgency## : ##ticket.urgency##
 ##lang.ticket.impact## : ##ticket.impact##
 ##lang.ticket.priority## : ##ticket.priority##
##IFticket.user.email## ##lang.ticket.user.email## : ##ticket.user.email ##ENDIFticket.user.email##
##IFticket.category## ##lang.ticket.category## : ##ticket.category## ##ENDIFticket.category## ##ELSEticket.category## ##lang.ticket.nocategoryassigned## ##ENDELSEticket.category##
 ##lang.ticket.content## : ##ticket.content##
 ##IFticket.storestatus=6##

 ##lang.ticket.solvedate## : ##ticket.solvedate##
 ##lang.ticket.solution.type## : ##ticket.solution.type##
 ##lang.ticket.solution.description## : ##ticket.solution.description##
 ##ENDIFticket.storestatus##
 ##lang.ticket.numberoffollowups## : ##ticket.numberoffollowups##

##FOREACHfollowups##

 [##followup.date##] ##lang.followup.isprivate## : ##followup.isprivate##
 ##lang.followup.author## ##followup.author##
 ##lang.followup.description## ##followup.description##
 ##lang.followup.date## ##followup.date##
 ##lang.followup.requesttype## ##followup.requesttype##

##ENDFOREACHfollowups##
 ##lang.ticket.numberoftasks## : ##ticket.numberoftasks##

##FOREACHtasks##

 [##task.date##] ##lang.task.isprivate## : ##task.isprivate##
 ##lang.task.author## ##task.author##
 ##lang.task.description## ##task.description##
 ##lang.task.time## ##task.time##
 ##lang.task.category## ##task.category##

##ENDFOREACHtasks##','<!-- description{ color: inherit; background: #ebebeb; border-style: solid;border-color: #8d8d8d; border-width: 0px 1px 1px 0px; }    -->
<div>##IFticket.storestatus=5##</div>
<div>##lang.ticket.url## : <a href=\"##ticket.urlapprove##\">##ticket.urlapprove##</a> <strong>&#160;</strong></div>
<div><strong>##lang.ticket.autoclosewarning##</strong></div>
<div><span style=\"color: #888888;\"><strong><span style=\"text-decoration: underline;\">##lang.ticket.solvedate##</span></strong></span> : ##ticket.solvedate##<br /><span style=\"text-decoration: underline; color: #888888;\"><strong>##lang.ticket.solution.type##</strong></span> : ##ticket.solution.type##<br /><span style=\"text-decoration: underline; color: #888888;\"><strong>##lang.ticket.solution.description##</strong></span> : ##ticket.solution.description## ##ENDIFticket.storestatus##</div>
<div>##ELSEticket.storestatus## ##lang.ticket.url## : <a href=\"##ticket.url##\">##ticket.url##</a> ##ENDELSEticket.storestatus##</div>
<p class=\"description b\"><strong>##lang.ticket.description##</strong></p>
<p><span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.title##</span>&#160;:##ticket.title## <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.authors##</span>&#160;:##IFticket.authors## ##ticket.authors## ##ENDIFticket.authors##    ##ELSEticket.authors##--##ENDELSEticket.authors## <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.creationdate##</span>&#160;:##ticket.creationdate## <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.closedate##</span>&#160;:##ticket.closedate## <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.requesttype##</span>&#160;:##ticket.requesttype##<br />
<br /><span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.item.name##</span>&#160;:
<p>##FOREACHitems##</p>
<div class=\"description b\">##IFticket.itemtype## ##ticket.itemtype##&#160;- ##ticket.item.name## ##IFticket.item.model## ##lang.ticket.item.model## : ##ticket.item.model## ##ENDIFticket.item.model## ##IFticket.item.serial## ##lang.ticket.item.serial## : ##ticket.item.serial## ##ENDIFticket.item.serial## ##IFticket.item.otherserial## ##lang.ticket.item.otherserial## : ##ticket.item.otherserial## ##ENDIFticket.item.otherserial## ##ENDIFticket.itemtype## </div><br />
<p>##ENDFOREACHitems##</p>
##IFticket.assigntousers## <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.assigntousers##</span>&#160;: ##ticket.assigntousers## ##ENDIFticket.assigntousers##<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\">##lang.ticket.status## </span>&#160;: ##ticket.status##<br /> ##IFticket.assigntogroups## <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.assigntogroups##</span>&#160;: ##ticket.assigntogroups## ##ENDIFticket.assigntogroups##<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.urgency##</span>&#160;: ##ticket.urgency##<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.impact##</span>&#160;: ##ticket.impact##<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.priority##</span>&#160;: ##ticket.priority## <br /> ##IFticket.user.email##<span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.user.email##</span>&#160;: ##ticket.user.email ##ENDIFticket.user.email##    <br /> ##IFticket.category##<span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\">##lang.ticket.category## </span>&#160;:##ticket.category## ##ENDIFticket.category## ##ELSEticket.category## ##lang.ticket.nocategoryassigned## ##ENDELSEticket.category##    <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.content##</span>&#160;: ##ticket.content##</p>
<br />##IFticket.storestatus=6##<br /><span style=\"text-decoration: underline;\"><strong><span style=\"color: #888888;\">##lang.ticket.solvedate##</span></strong></span> : ##ticket.solvedate##<br /><span style=\"color: #888888;\"><strong><span style=\"text-decoration: underline;\">##lang.ticket.solution.type##</span></strong></span> : ##ticket.solution.type##<br /><span style=\"text-decoration: underline; color: #888888;\"><strong>##lang.ticket.solution.description##</strong></span> : ##ticket.solution.description##<br />##ENDIFticket.storestatus##</p>
<div class=\"description b\">##lang.ticket.numberoffollowups##&#160;: ##ticket.numberoffollowups##</div>
<p>##FOREACHfollowups##</p>
<div class=\"description b\"><br /> <strong> [##followup.date##] <em>##lang.followup.isprivate## : ##followup.isprivate## </em></strong><br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.followup.author## </span> ##followup.author##<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.followup.description## </span> ##followup.description##<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.followup.date## </span> ##followup.date##<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.followup.requesttype## </span> ##followup.requesttype##</div>
<p>##ENDFOREACHfollowups##</p>
<div class=\"description b\">##lang.ticket.numberoftasks##&#160;: ##ticket.numberoftasks##</div>
<p>##FOREACHtasks##</p>
<div class=\"description b\"><br /> <strong> [##task.date##] <em>##lang.task.isprivate## : ##task.isprivate## </em></strong><br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.task.author##</span> ##task.author##<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.task.description##</span> ##task.description##<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.task.time##</span> ##task.time##<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.task.category##</span> ##task.category##</div>
<p>##ENDFOREACHtasks##</p>');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('5','12','','##contract.action##  ##contract.entity##','##lang.contract.entity## : ##contract.entity##

##FOREACHcontracts##
##lang.contract.name## : ##contract.name##
##lang.contract.number## : ##contract.number##
##lang.contract.time## : ##contract.time##
##IFcontract.type####lang.contract.type## : ##contract.type####ENDIFcontract.type##
##contract.url##
##ENDFOREACHcontracts##','&lt;p&gt;##lang.contract.entity## : ##contract.entity##&lt;br /&gt;
&lt;br /&gt;##FOREACHcontracts##&lt;br /&gt;##lang.contract.name## :
##contract.name##&lt;br /&gt;
##lang.contract.number## : ##contract.number##&lt;br /&gt;
##lang.contract.time## : ##contract.time##&lt;br /&gt;
##IFcontract.type####lang.contract.type## : ##contract.type##
##ENDIFcontract.type##&lt;br /&gt;
&lt;a href=\"##contract.url##\"&gt;
##contract.url##&lt;/a&gt;&lt;br /&gt;
##ENDFOREACHcontracts##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('6','5','','##ticket.action## ##ticket.title##','##lang.ticket.url## : ##ticket.url##

##lang.ticket.description##


##lang.ticket.title##  :##ticket.title##

##lang.ticket.authors##  :##IFticket.authors##
##ticket.authors## ##ENDIFticket.authors##
##ELSEticket.authors##--##ENDELSEticket.authors##

##IFticket.category## ##lang.ticket.category##  :##ticket.category##
##ENDIFticket.category## ##ELSEticket.category##
##lang.ticket.nocategoryassigned## ##ENDELSEticket.category##

##lang.ticket.content##  : ##ticket.content##
##IFticket.itemtype##
##lang.ticket.item.name##  : ##ticket.itemtype## - ##ticket.item.name##
##ENDIFticket.itemtype##','&lt;div&gt;##lang.ticket.url## : &lt;a href=\"##ticket.url##\"&gt;
##ticket.url##&lt;/a&gt;&lt;/div&gt;
&lt;div class=\"description b\"&gt;
##lang.ticket.description##&lt;/div&gt;
&lt;p&gt;&lt;span
style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;
##lang.ticket.title##&lt;/span&gt;&#160;:##ticket.title##
&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;
##lang.ticket.authors##&lt;/span&gt;
##IFticket.authors## ##ticket.authors##
##ENDIFticket.authors##
##ELSEticket.authors##--##ENDELSEticket.authors##
&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;&#160
;&lt;/span&gt;&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; &lt;/span&gt;
##IFticket.category##&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;
##lang.ticket.category## &lt;/span&gt;&#160;:##ticket.category##
##ENDIFticket.category## ##ELSEticket.category##
##lang.ticket.nocategoryassigned## ##ENDELSEticket.category##
&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;
##lang.ticket.content##&lt;/span&gt;&#160;:
##ticket.content##&lt;br /&gt;##IFticket.itemtype##
&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;
##lang.ticket.item.name##&lt;/span&gt;&#160;:
##ticket.itemtype## - ##ticket.item.name##
##ENDIFticket.itemtype##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('15','15','','##lang.unicity.action##','##lang.unicity.entity## : ##unicity.entity##

##lang.unicity.itemtype## : ##unicity.itemtype##

##lang.unicity.message## : ##unicity.message##

##lang.unicity.action_user## : ##unicity.action_user##

##lang.unicity.action_type## : ##unicity.action_type##

##lang.unicity.date## : ##unicity.date##','&lt;p&gt;##lang.unicity.entity## : ##unicity.entity##&lt;/p&gt;
&lt;p&gt;##lang.unicity.itemtype## : ##unicity.itemtype##&lt;/p&gt;
&lt;p&gt;##lang.unicity.message## : ##unicity.message##&lt;/p&gt;
&lt;p&gt;##lang.unicity.action_user## : ##unicity.action_user##&lt;/p&gt;
&lt;p&gt;##lang.unicity.action_type## : ##unicity.action_type##&lt;/p&gt;
&lt;p&gt;##lang.unicity.date## : ##unicity.date##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('7','7','','##ticket.action## ##ticket.title##','##FOREACHvalidations##

##IFvalidation.storestatus=2##
##validation.submission.title##
##lang.validation.commentsubmission## : ##validation.commentsubmission##
##ENDIFvalidation.storestatus##
##ELSEvalidation.storestatus## ##validation.answer.title## ##ENDELSEvalidation.storestatus##

##lang.ticket.url## : ##ticket.urlvalidation##

##IFvalidation.status## ##lang.validation.status## : ##validation.status## ##ENDIFvalidation.status##
##IFvalidation.commentvalidation##
##lang.validation.commentvalidation## : ##validation.commentvalidation##
##ENDIFvalidation.commentvalidation##
##ENDFOREACHvalidations##','&lt;div&gt;##FOREACHvalidations##&lt;/div&gt;
&lt;p&gt;##IFvalidation.storestatus=2##&lt;/p&gt;
&lt;div&gt;##validation.submission.title##&lt;/div&gt;
&lt;div&gt;##lang.validation.commentsubmission## : ##validation.commentsubmission##&lt;/div&gt;
&lt;div&gt;##ENDIFvalidation.storestatus##&lt;/div&gt;
&lt;div&gt;##ELSEvalidation.storestatus## ##validation.answer.title## ##ENDELSEvalidation.storestatus##&lt;/div&gt;
&lt;div&gt;&lt;/div&gt;
&lt;div&gt;
&lt;div&gt;##lang.ticket.url## : &lt;a href=\"##ticket.urlvalidation##\"&gt; ##ticket.urlvalidation## &lt;/a&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;p&gt;##IFvalidation.status## ##lang.validation.status## : ##validation.status## ##ENDIFvalidation.status##
&lt;br /&gt; ##IFvalidation.commentvalidation##&lt;br /&gt; ##lang.validation.commentvalidation## :
&#160; ##validation.commentvalidation##&lt;br /&gt; ##ENDIFvalidation.commentvalidation##
&lt;br /&gt;##ENDFOREACHvalidations##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('8','6','','##ticket.action## ##ticket.entity##','##lang.ticket.entity## : ##ticket.entity##

##FOREACHtickets##

##lang.ticket.title## : ##ticket.title##
 ##lang.ticket.status## : ##ticket.status##

 ##ticket.url##
 ##ENDFOREACHtickets##','&lt;table class=\"tab_cadre\" border=\"1\" cellspacing=\"2\" cellpadding=\"3\"&gt;
&lt;tbody&gt;
&lt;tr&gt;
&lt;td style=\"text-align: left;\" width=\"auto\" bgcolor=\"#cccccc\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##lang.ticket.authors##&lt;/span&gt;&lt;/td&gt;
&lt;td style=\"text-align: left;\" width=\"auto\" bgcolor=\"#cccccc\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##lang.ticket.title##&lt;/span&gt;&lt;/td&gt;
&lt;td style=\"text-align: left;\" width=\"auto\" bgcolor=\"#cccccc\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##lang.ticket.priority##&lt;/span&gt;&lt;/td&gt;
&lt;td style=\"text-align: left;\" width=\"auto\" bgcolor=\"#cccccc\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##lang.ticket.status##&lt;/span&gt;&lt;/td&gt;
&lt;td style=\"text-align: left;\" width=\"auto\" bgcolor=\"#cccccc\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##lang.ticket.attribution##&lt;/span&gt;&lt;/td&gt;
&lt;td style=\"text-align: left;\" width=\"auto\" bgcolor=\"#cccccc\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##lang.ticket.creationdate##&lt;/span&gt;&lt;/td&gt;
&lt;td style=\"text-align: left;\" width=\"auto\" bgcolor=\"#cccccc\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##lang.ticket.content##&lt;/span&gt;&lt;/td&gt;
&lt;/tr&gt;
##FOREACHtickets##
&lt;tr&gt;
&lt;td width=\"auto\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##ticket.authors##&lt;/span&gt;&lt;/td&gt;
&lt;td width=\"auto\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;&lt;a href=\"##ticket.url##\"&gt;##ticket.title##&lt;/a&gt;&lt;/span&gt;&lt;/td&gt;
&lt;td width=\"auto\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##ticket.priority##&lt;/span&gt;&lt;/td&gt;
&lt;td width=\"auto\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##ticket.status##&lt;/span&gt;&lt;/td&gt;
&lt;td width=\"auto\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##IFticket.assigntousers####ticket.assigntousers##&lt;br /&gt;##ENDIFticket.assigntousers####IFticket.assigntogroups##&lt;br /&gt;##ticket.assigntogroups## ##ENDIFticket.assigntogroups####IFticket.assigntosupplier##&lt;br /&gt;##ticket.assigntosupplier## ##ENDIFticket.assigntosupplier##&lt;/span&gt;&lt;/td&gt;
&lt;td width=\"auto\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##ticket.creationdate##&lt;/span&gt;&lt;/td&gt;
&lt;td width=\"auto\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##ticket.content##&lt;/span&gt;&lt;/td&gt;
&lt;/tr&gt;
##ENDFOREACHtickets##
&lt;/tbody&gt;
&lt;/table&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('9','9','','##consumable.action##  ##consumable.entity##','##lang.consumable.entity## : ##consumable.entity##


##FOREACHconsumables##
##lang.consumable.item## : ##consumable.item##


##lang.consumable.reference## : ##consumable.reference##

##lang.consumable.remaining## : ##consumable.remaining##

##consumable.url##

##ENDFOREACHconsumables##','&lt;p&gt;
##lang.consumable.entity## : ##consumable.entity##
&lt;br /&gt; &lt;br /&gt;##FOREACHconsumables##
&lt;br /&gt;##lang.consumable.item## : ##consumable.item##&lt;br /&gt;
&lt;br /&gt;##lang.consumable.reference## : ##consumable.reference##&lt;br /&gt;
##lang.consumable.remaining## : ##consumable.remaining##&lt;br /&gt;
&lt;a href=\"##consumable.url##\"&gt; ##consumable.url##&lt;/a&gt;&lt;br /&gt;
   ##ENDFOREACHconsumables##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('10','8','','##cartridge.action##  ##cartridge.entity##','##lang.cartridge.entity## : ##cartridge.entity##


##FOREACHcartridges##
##lang.cartridge.item## : ##cartridge.item##


##lang.cartridge.reference## : ##cartridge.reference##

##lang.cartridge.remaining## : ##cartridge.remaining##

##cartridge.url##
 ##ENDFOREACHcartridges##','&lt;p&gt;##lang.cartridge.entity## : ##cartridge.entity##
&lt;br /&gt; &lt;br /&gt;##FOREACHcartridges##
&lt;br /&gt;##lang.cartridge.item## :
##cartridge.item##&lt;br /&gt; &lt;br /&gt;
##lang.cartridge.reference## :
##cartridge.reference##&lt;br /&gt;
##lang.cartridge.remaining## :
##cartridge.remaining##&lt;br /&gt;
&lt;a href=\"##cartridge.url##\"&gt;
##cartridge.url##&lt;/a&gt;&lt;br /&gt;
##ENDFOREACHcartridges##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('11','10','','##infocom.action##  ##infocom.entity##','##lang.infocom.entity## : ##infocom.entity##


##FOREACHinfocoms##

##lang.infocom.itemtype## : ##infocom.itemtype##

##lang.infocom.item## : ##infocom.item##


##lang.infocom.expirationdate## : ##infocom.expirationdate##

##infocom.url##
 ##ENDFOREACHinfocoms##','&lt;p&gt;##lang.infocom.entity## : ##infocom.entity##
&lt;br /&gt; &lt;br /&gt;##FOREACHinfocoms##
&lt;br /&gt;##lang.infocom.itemtype## : ##infocom.itemtype##&lt;br /&gt;
##lang.infocom.item## : ##infocom.item##&lt;br /&gt; &lt;br /&gt;
##lang.infocom.expirationdate## : ##infocom.expirationdate##
&lt;br /&gt; &lt;a href=\"##infocom.url##\"&gt;
##infocom.url##&lt;/a&gt;&lt;br /&gt;
##ENDFOREACHinfocoms##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('12','11','','##license.action##  ##license.entity##','##lang.license.entity## : ##license.entity##

##FOREACHlicenses##

##lang.license.item## : ##license.item##

##lang.license.serial## : ##license.serial##

##lang.license.expirationdate## : ##license.expirationdate##

##license.url##
 ##ENDFOREACHlicenses##','&lt;p&gt;
##lang.license.entity## : ##license.entity##&lt;br /&gt;
##FOREACHlicenses##
&lt;br /&gt;##lang.license.item## : ##license.item##&lt;br /&gt;
##lang.license.serial## : ##license.serial##&lt;br /&gt;
##lang.license.expirationdate## : ##license.expirationdate##
&lt;br /&gt; &lt;a href=\"##license.url##\"&gt; ##license.url##
&lt;/a&gt;&lt;br /&gt; ##ENDFOREACHlicenses##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('13','13','','##user.action##','##user.realname## ##user.firstname##

##lang.passwordforget.information##

##lang.passwordforget.link## ##user.passwordforgeturl##','&lt;p&gt;&lt;strong&gt;##user.realname## ##user.firstname##&lt;/strong&gt;&lt;/p&gt;
&lt;p&gt;##lang.passwordforget.information##&lt;/p&gt;
&lt;p&gt;##lang.passwordforget.link## &lt;a title=\"##user.passwordforgeturl##\" href=\"##user.passwordforgeturl##\"&gt;##user.passwordforgeturl##&lt;/a&gt;&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('14','14','','##ticket.action## ##ticket.title##','##lang.ticket.title## : ##ticket.title##

##lang.ticket.closedate## : ##ticket.closedate##

##lang.satisfaction.text## ##ticket.urlsatisfaction##','&lt;p&gt;##lang.ticket.title## : ##ticket.title##&lt;/p&gt;
&lt;p&gt;##lang.ticket.closedate## : ##ticket.closedate##&lt;/p&gt;
&lt;p&gt;##lang.satisfaction.text## &lt;a href=\"##ticket.urlsatisfaction##\"&gt;##ticket.urlsatisfaction##&lt;/a&gt;&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('16','16','','##crontask.action##','##lang.crontask.warning##

##FOREACHcrontasks##
 ##crontask.name## : ##crontask.description##

##ENDFOREACHcrontasks##','&lt;p&gt;##lang.crontask.warning##&lt;/p&gt;
&lt;p&gt;##FOREACHcrontasks## &lt;br /&gt;&lt;a href=\"##crontask.url##\"&gt;##crontask.name##&lt;/a&gt; : ##crontask.description##&lt;br /&gt; &lt;br /&gt;##ENDFOREACHcrontasks##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('17','17','','##problem.action## ##problem.title##','##IFproblem.storestatus=5##
 ##lang.problem.url## : ##problem.urlapprove##
 ##lang.problem.solvedate## : ##problem.solvedate##
 ##lang.problem.solution.type## : ##problem.solution.type##
 ##lang.problem.solution.description## : ##problem.solution.description## ##ENDIFproblem.storestatus##
 ##ELSEproblem.storestatus## ##lang.problem.url## : ##problem.url## ##ENDELSEproblem.storestatus##

 ##lang.problem.description##

 ##lang.problem.title##  :##problem.title##
 ##lang.problem.authors##  :##IFproblem.authors## ##problem.authors## ##ENDIFproblem.authors## ##ELSEproblem.authors##--##ENDELSEproblem.authors##
 ##lang.problem.creationdate##  :##problem.creationdate##
 ##IFproblem.assigntousers## ##lang.problem.assigntousers##  : ##problem.assigntousers## ##ENDIFproblem.assigntousers##
 ##lang.problem.status##  : ##problem.status##
 ##IFproblem.assigntogroups## ##lang.problem.assigntogroups##  : ##problem.assigntogroups## ##ENDIFproblem.assigntogroups##
 ##lang.problem.urgency##  : ##problem.urgency##
 ##lang.problem.impact##  : ##problem.impact##
 ##lang.problem.priority## : ##problem.priority##
##IFproblem.category## ##lang.problem.category##  :##problem.category## ##ENDIFproblem.category## ##ELSEproblem.category## ##lang.problem.nocategoryassigned## ##ENDELSEproblem.category##
 ##lang.problem.content##  : ##problem.content##

##IFproblem.storestatus=6##
 ##lang.problem.solvedate## : ##problem.solvedate##
 ##lang.problem.solution.type## : ##problem.solution.type##
 ##lang.problem.solution.description## : ##problem.solution.description##
##ENDIFproblem.storestatus##
 ##lang.problem.numberoftickets## : ##problem.numberoftickets##

##FOREACHtickets##
 [##ticket.date##] ##lang.problem.title## : ##ticket.title##
 ##lang.problem.content## ##ticket.content##

##ENDFOREACHtickets##
 ##lang.problem.numberoftasks## : ##problem.numberoftasks##

##FOREACHtasks##
 [##task.date##]
 ##lang.task.author## ##task.author##
 ##lang.task.description## ##task.description##
 ##lang.task.time## ##task.time##
 ##lang.task.category## ##task.category##

##ENDFOREACHtasks##
','&lt;p&gt;##IFproblem.storestatus=5##&lt;/p&gt;
&lt;div&gt;##lang.problem.url## : &lt;a href=\"##problem.urlapprove##\"&gt;##problem.urlapprove##&lt;/a&gt;&lt;/div&gt;
&lt;div&gt;&lt;span style=\"color: #888888;\"&gt;&lt;strong&gt;&lt;span style=\"text-decoration: underline;\"&gt;##lang.problem.solvedate##&lt;/span&gt;&lt;/strong&gt;&lt;/span&gt; : ##problem.solvedate##&lt;br /&gt;&lt;span style=\"text-decoration: underline; color: #888888;\"&gt;&lt;strong&gt;##lang.problem.solution.type##&lt;/strong&gt;&lt;/span&gt; : ##problem.solution.type##&lt;br /&gt;&lt;span style=\"text-decoration: underline; color: #888888;\"&gt;&lt;strong&gt;##lang.problem.solution.description##&lt;/strong&gt;&lt;/span&gt; : ##problem.solution.description## ##ENDIFproblem.storestatus##&lt;/div&gt;
&lt;div&gt;##ELSEproblem.storestatus## ##lang.problem.url## : &lt;a href=\"##problem.url##\"&gt;##problem.url##&lt;/a&gt; ##ENDELSEproblem.storestatus##&lt;/div&gt;
&lt;p class=\"description b\"&gt;&lt;strong&gt;##lang.problem.description##&lt;/strong&gt;&lt;/p&gt;
&lt;p&gt;&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.problem.title##&lt;/span&gt;&#160;:##problem.title## &lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.problem.authors##&lt;/span&gt;&#160;:##IFproblem.authors## ##problem.authors## ##ENDIFproblem.authors##    ##ELSEproblem.authors##--##ENDELSEproblem.authors## &lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.problem.creationdate##&lt;/span&gt;&#160;:##problem.creationdate## &lt;br /&gt; ##IFproblem.assigntousers## &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.problem.assigntousers##&lt;/span&gt;&#160;: ##problem.assigntousers## ##ENDIFproblem.assigntousers##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.problem.status## &lt;/span&gt;&#160;: ##problem.status##&lt;br /&gt; ##IFproblem.assigntogroups## &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.problem.assigntogroups##&lt;/span&gt;&#160;: ##problem.assigntogroups## ##ENDIFproblem.assigntogroups##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.problem.urgency##&lt;/span&gt;&#160;: ##problem.urgency##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.problem.impact##&lt;/span&gt;&#160;: ##problem.impact##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.problem.priority##&lt;/span&gt; : ##problem.priority## &lt;br /&gt;##IFproblem.category##&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.problem.category## &lt;/span&gt;&#160;:##problem.category##  ##ENDIFproblem.category## ##ELSEproblem.category##  ##lang.problem.nocategoryassigned## ##ENDELSEproblem.category##    &lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.problem.content##&lt;/span&gt;&#160;: ##problem.content##&lt;/p&gt;
&lt;p&gt;##IFproblem.storestatus=6##&lt;br /&gt;&lt;span style=\"text-decoration: underline;\"&gt;&lt;strong&gt;&lt;span style=\"color: #888888;\"&gt;##lang.problem.solvedate##&lt;/span&gt;&lt;/strong&gt;&lt;/span&gt; : ##problem.solvedate##&lt;br /&gt;&lt;span style=\"color: #888888;\"&gt;&lt;strong&gt;&lt;span style=\"text-decoration: underline;\"&gt;##lang.problem.solution.type##&lt;/span&gt;&lt;/strong&gt;&lt;/span&gt; : ##problem.solution.type##&lt;br /&gt;&lt;span style=\"text-decoration: underline; color: #888888;\"&gt;&lt;strong&gt;##lang.problem.solution.description##&lt;/strong&gt;&lt;/span&gt; : ##problem.solution.description##&lt;br /&gt;##ENDIFproblem.storestatus##&lt;/p&gt;
&lt;div class=\"description b\"&gt;##lang.problem.numberoftickets##&#160;: ##problem.numberoftickets##&lt;/div&gt;
&lt;p&gt;##FOREACHtickets##&lt;/p&gt;
&lt;div&gt;&lt;strong&gt; [##ticket.date##] &lt;em&gt;##lang.problem.title## : &lt;a href=\"##ticket.url##\"&gt;##ticket.title## &lt;/a&gt;&lt;/em&gt;&lt;/strong&gt;&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; &lt;/span&gt;&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.problem.content## &lt;/span&gt; ##ticket.content##
&lt;p&gt;##ENDFOREACHtickets##&lt;/p&gt;
&lt;div class=\"description b\"&gt;##lang.problem.numberoftasks##&#160;: ##problem.numberoftasks##&lt;/div&gt;
&lt;p&gt;##FOREACHtasks##&lt;/p&gt;
&lt;div class=\"description b\"&gt;&lt;strong&gt;[##task.date##] &lt;/strong&gt;&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.task.author##&lt;/span&gt; ##task.author##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.task.description##&lt;/span&gt; ##task.description##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.task.time##&lt;/span&gt; ##task.time##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.task.category##&lt;/span&gt; ##task.category##&lt;/div&gt;
&lt;p&gt;##ENDFOREACHtasks##&lt;/p&gt;
&lt;/div&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('18','18','','##recall.action##: ##recall.item.name##','##recall.action##: ##recall.item.name##

##recall.item.content##

##lang.recall.planning.begin##: ##recall.planning.begin##
##lang.recall.planning.end##: ##recall.planning.end##
##lang.recall.planning.state##: ##recall.planning.state##
##lang.recall.item.private##: ##recall.item.private##','&lt;p&gt;##recall.action##: &lt;a href=\"##recall.item.url##\"&gt;##recall.item.name##&lt;/a&gt;&lt;/p&gt;
&lt;p&gt;##recall.item.content##&lt;/p&gt;
&lt;p&gt;##lang.recall.planning.begin##: ##recall.planning.begin##&lt;br /&gt;##lang.recall.planning.end##: ##recall.planning.end##&lt;br /&gt;##lang.recall.planning.state##: ##recall.planning.state##&lt;br /&gt;##lang.recall.item.private##: ##recall.item.private##&lt;br /&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p&gt;&lt;br /&gt;&lt;br /&gt;&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('19','19','','##change.action## ##change.title##','##IFchange.storestatus=5##
 ##lang.change.url## : ##change.urlapprove##
 ##lang.change.solvedate## : ##change.solvedate##
 ##lang.change.solution.type## : ##change.solution.type##
 ##lang.change.solution.description## : ##change.solution.description## ##ENDIFchange.storestatus##
 ##ELSEchange.storestatus## ##lang.change.url## : ##change.url## ##ENDELSEchange.storestatus##

 ##lang.change.description##

 ##lang.change.title##  :##change.title##
 ##lang.change.authors##  :##IFchange.authors## ##change.authors## ##ENDIFchange.authors## ##ELSEchange.authors##--##ENDELSEchange.authors##
 ##lang.change.creationdate##  :##change.creationdate##
 ##IFchange.assigntousers## ##lang.change.assigntousers##  : ##change.assigntousers## ##ENDIFchange.assigntousers##
 ##lang.change.status##  : ##change.status##
 ##IFchange.assigntogroups## ##lang.change.assigntogroups##  : ##change.assigntogroups## ##ENDIFchange.assigntogroups##
 ##lang.change.urgency##  : ##change.urgency##
 ##lang.change.impact##  : ##change.impact##
 ##lang.change.priority## : ##change.priority##
##IFchange.category## ##lang.change.category##  :##change.category## ##ENDIFchange.category## ##ELSEchange.category## ##lang.change.nocategoryassigned## ##ENDELSEchange.category##
 ##lang.change.content##  : ##change.content##

##IFchange.storestatus=6##
 ##lang.change.solvedate## : ##change.solvedate##
 ##lang.change.solution.type## : ##change.solution.type##
 ##lang.change.solution.description## : ##change.solution.description##
##ENDIFchange.storestatus##
 ##lang.change.numberofproblems## : ##change.numberofproblems##

##FOREACHproblems##
 [##problem.date##] ##lang.change.title## : ##problem.title##
 ##lang.change.content## ##problem.content##

##ENDFOREACHproblems##
 ##lang.change.numberoftasks## : ##change.numberoftasks##

##FOREACHtasks##
 [##task.date##]
 ##lang.task.author## ##task.author##
 ##lang.task.description## ##task.description##
 ##lang.task.time## ##task.time##
 ##lang.task.category## ##task.category##

##ENDFOREACHtasks##
','&lt;p&gt;##IFchange.storestatus=5##&lt;/p&gt;
&lt;div&gt;##lang.change.url## : &lt;a href=\"##change.urlapprove##\"&gt;##change.urlapprove##&lt;/a&gt;&lt;/div&gt;
&lt;div&gt;&lt;span style=\"color: #888888;\"&gt;&lt;strong&gt;&lt;span style=\"text-decoration: underline;\"&gt;##lang.change.solvedate##&lt;/span&gt;&lt;/strong&gt;&lt;/span&gt; : ##change.solvedate##&lt;br /&gt;&lt;span style=\"text-decoration: underline; color: #888888;\"&gt;&lt;strong&gt;##lang.change.solution.type##&lt;/strong&gt;&lt;/span&gt; : ##change.solution.type##&lt;br /&gt;&lt;span style=\"text-decoration: underline; color: #888888;\"&gt;&lt;strong&gt;##lang.change.solution.description##&lt;/strong&gt;&lt;/span&gt; : ##change.solution.description## ##ENDIFchange.storestatus##&lt;/div&gt;
&lt;div&gt;##ELSEchange.storestatus## ##lang.change.url## : &lt;a href=\"##change.url##\"&gt;##change.url##&lt;/a&gt; ##ENDELSEchange.storestatus##&lt;/div&gt;
&lt;p class=\"description b\"&gt;&lt;strong&gt;##lang.change.description##&lt;/strong&gt;&lt;/p&gt;
&lt;p&gt;&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.change.title##&lt;/span&gt;&#160;:##change.title## &lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.change.authors##&lt;/span&gt;&#160;:##IFchange.authors## ##change.authors## ##ENDIFchange.authors##    ##ELSEchange.authors##--##ENDELSEchange.authors## &lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.change.creationdate##&lt;/span&gt;&#160;:##change.creationdate## &lt;br /&gt; ##IFchange.assigntousers## &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.change.assigntousers##&lt;/span&gt;&#160;: ##change.assigntousers## ##ENDIFchange.assigntousers##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.change.status## &lt;/span&gt;&#160;: ##change.status##&lt;br /&gt; ##IFchange.assigntogroups## &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.change.assigntogroups##&lt;/span&gt;&#160;: ##change.assigntogroups## ##ENDIFchange.assigntogroups##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.change.urgency##&lt;/span&gt;&#160;: ##change.urgency##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.change.impact##&lt;/span&gt;&#160;: ##change.impact##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.change.priority##&lt;/span&gt; : ##change.priority## &lt;br /&gt;##IFchange.category##&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.change.category## &lt;/span&gt;&#160;:##change.category##  ##ENDIFchange.category## ##ELSEchange.category##  ##lang.change.nocategoryassigned## ##ENDELSEchange.category##    &lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.change.content##&lt;/span&gt;&#160;: ##change.content##&lt;/p&gt;
&lt;p&gt;##IFchange.storestatus=6##&lt;br /&gt;&lt;span style=\"text-decoration: underline;\"&gt;&lt;strong&gt;&lt;span style=\"color: #888888;\"&gt;##lang.change.solvedate##&lt;/span&gt;&lt;/strong&gt;&lt;/span&gt; : ##change.solvedate##&lt;br /&gt;&lt;span style=\"color: #888888;\"&gt;&lt;strong&gt;&lt;span style=\"text-decoration: underline;\"&gt;##lang.change.solution.type##&lt;/span&gt;&lt;/strong&gt;&lt;/span&gt; : ##change.solution.type##&lt;br /&gt;&lt;span style=\"text-decoration: underline; color: #888888;\"&gt;&lt;strong&gt;##lang.change.solution.description##&lt;/strong&gt;&lt;/span&gt; : ##change.solution.description##&lt;br /&gt;##ENDIFchange.storestatus##&lt;/p&gt;
&lt;div class=\"description b\"&gt;##lang.change.numberofproblems##&#160;: ##change.numberofproblems##&lt;/div&gt;
&lt;p&gt;##FOREACHproblems##&lt;/p&gt;
&lt;div&gt;&lt;strong&gt; [##problem.date##] &lt;em&gt;##lang.change.title## : &lt;a href=\"##problem.url##\"&gt;##problem.title## &lt;/a&gt;&lt;/em&gt;&lt;/strong&gt;&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; &lt;/span&gt;&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.change.content## &lt;/span&gt; ##problem.content##
&lt;p&gt;##ENDFOREACHproblems##&lt;/p&gt;
&lt;div class=\"description b\"&gt;##lang.change.numberoftasks##&#160;: ##change.numberoftasks##&lt;/div&gt;
&lt;p&gt;##FOREACHtasks##&lt;/p&gt;
&lt;div class=\"description b\"&gt;&lt;strong&gt;[##task.date##] &lt;/strong&gt;&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.task.author##&lt;/span&gt; ##task.author##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.task.description##&lt;/span&gt; ##task.description##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.task.time##&lt;/span&gt; ##task.time##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.task.category##&lt;/span&gt; ##task.category##&lt;/div&gt;
&lt;p&gt;##ENDFOREACHtasks##&lt;/p&gt;
&lt;/div&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('20','20','','##mailcollector.action##','##FOREACHmailcollectors##
##lang.mailcollector.name## : ##mailcollector.name##
##lang.mailcollector.errors## : ##mailcollector.errors##
##mailcollector.url##
##ENDFOREACHmailcollectors##','&lt;p&gt;##FOREACHmailcollectors##&lt;br /&gt;##lang.mailcollector.name## : ##mailcollector.name##&lt;br /&gt; ##lang.mailcollector.errors## : ##mailcollector.errors##&lt;br /&gt;&lt;a href=\"##mailcollector.url##\"&gt;##mailcollector.url##&lt;/a&gt;&lt;br /&gt; ##ENDFOREACHmailcollectors##&lt;/p&gt;
&lt;p&gt;&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('21','21','','##project.action## ##project.name## ##project.code##','##lang.project.url## : ##project.url##

##lang.project.description##

##lang.project.name## : ##project.name##
##lang.project.code## : ##project.code##
##lang.project.manager## : ##project.manager##
##lang.project.managergroup## : ##project.managergroup##
##lang.project.creationdate## : ##project.creationdate##
##lang.project.priority## : ##project.priority##
##lang.project.state## : ##project.state##
##lang.project.type## : ##project.type##
##lang.project.description## : ##project.description##

##lang.project.numberoftasks## : ##project.numberoftasks##



##FOREACHtasks##

[##task.creationdate##]
##lang.task.name## : ##task.name##
##lang.task.state## : ##task.state##
##lang.task.type## : ##task.type##
##lang.task.percent## : ##task.percent##
##lang.task.description## : ##task.description##

##ENDFOREACHtasks##','&lt;p&gt;##lang.project.url## : &lt;a href=\"##project.url##\"&gt;##project.url##&lt;/a&gt;&lt;/p&gt;
&lt;p&gt;&lt;strong&gt;##lang.project.description##&lt;/strong&gt;&lt;/p&gt;
&lt;p&gt;##lang.project.name## : ##project.name##&lt;br /&gt;##lang.project.code## : ##project.code##&lt;br /&gt; ##lang.project.manager## : ##project.manager##&lt;br /&gt;##lang.project.managergroup## : ##project.managergroup##&lt;br /&gt; ##lang.project.creationdate## : ##project.creationdate##&lt;br /&gt;##lang.project.priority## : ##project.priority## &lt;br /&gt;##lang.project.state## : ##project.state##&lt;br /&gt;##lang.project.type## : ##project.type##&lt;br /&gt;##lang.project.description## : ##project.description##&lt;/p&gt;
&lt;p&gt;##lang.project.numberoftasks## : ##project.numberoftasks##&lt;/p&gt;
&lt;div&gt;
&lt;p&gt;##FOREACHtasks##&lt;/p&gt;
&lt;div&gt;&lt;strong&gt;[##task.creationdate##] &lt;/strong&gt;&lt;br /&gt; ##lang.task.name## : ##task.name##&lt;br /&gt;##lang.task.state## : ##task.state##&lt;br /&gt;##lang.task.type## : ##task.type##&lt;br /&gt;##lang.task.percent## : ##task.percent##&lt;br /&gt;##lang.task.description## : ##task.description##&lt;/div&gt;
&lt;p&gt;##ENDFOREACHtasks##&lt;/p&gt;
&lt;/div&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('22','22','','##projecttask.action## ##projecttask.name##','##lang.projecttask.url## : ##projecttask.url##

##lang.projecttask.description##

##lang.projecttask.name## : ##projecttask.name##
##lang.projecttask.project## : ##projecttask.project##
##lang.projecttask.creationdate## : ##projecttask.creationdate##
##lang.projecttask.state## : ##projecttask.state##
##lang.projecttask.type## : ##projecttask.type##
##lang.projecttask.description## : ##projecttask.description##

##lang.projecttask.numberoftasks## : ##projecttask.numberoftasks##



##FOREACHtasks##

[##task.creationdate##]
##lang.task.name## : ##task.name##
##lang.task.state## : ##task.state##
##lang.task.type## : ##task.type##
##lang.task.percent## : ##task.percent##
##lang.task.description## : ##task.description##

##ENDFOREACHtasks##','&lt;p&gt;##lang.projecttask.url## : &lt;a href=\"##projecttask.url##\"&gt;##projecttask.url##&lt;/a&gt;&lt;/p&gt;
&lt;p&gt;&lt;strong&gt;##lang.projecttask.description##&lt;/strong&gt;&lt;/p&gt;
&lt;p&gt;##lang.projecttask.name## : ##projecttask.name##&lt;br /&gt;##lang.projecttask.project## : &lt;a href=\"##projecttask.projecturl##\"&gt;##projecttask.project##&lt;/a&gt;&lt;br /&gt;##lang.projecttask.creationdate## : ##projecttask.creationdate##&lt;br /&gt;##lang.projecttask.state## : ##projecttask.state##&lt;br /&gt;##lang.projecttask.type## : ##projecttask.type##&lt;br /&gt;##lang.projecttask.description## : ##projecttask.description##&lt;/p&gt;
&lt;p&gt;##lang.projecttask.numberoftasks## : ##projecttask.numberoftasks##&lt;/p&gt;
&lt;div&gt;
&lt;p&gt;##FOREACHtasks##&lt;/p&gt;
&lt;div&gt;&lt;strong&gt;[##task.creationdate##] &lt;/strong&gt;&lt;br /&gt;##lang.task.name## : ##task.name##&lt;br /&gt;##lang.task.state## : ##task.state##&lt;br /&gt;##lang.task.type## : ##task.type##&lt;br /&gt;##lang.task.percent## : ##task.percent##&lt;br /&gt;##lang.task.description## : ##task.description##&lt;/div&gt;
&lt;p&gt;##ENDFOREACHtasks##&lt;/p&gt;
&lt;/div&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('23','23','','##objectlock.action##','##objectlock.type## ###objectlock.id## - ##objectlock.name##

      ##lang.objectlock.url##
      ##objectlock.url##

      ##lang.objectlock.date_mod##
      ##objectlock.date_mod##

      Hello ##objectlock.lockedby.firstname##,
      Could go to this item and unlock it for me?
      Thank you,
      Regards,
      ##objectlock.requester.firstname##','&lt;table&gt;
      &lt;tbody&gt;
      &lt;tr&gt;&lt;th colspan=\"2\"&gt;&lt;a href=\"##objectlock.url##\"&gt;##objectlock.type## ###objectlock.id## - ##objectlock.name##&lt;/a&gt;&lt;/th&gt;&lt;/tr&gt;
      &lt;tr&gt;
      &lt;td&gt;##lang.objectlock.url##&lt;/td&gt;
      &lt;td&gt;##objectlock.url##&lt;/td&gt;
      &lt;/tr&gt;
      &lt;tr&gt;
      &lt;td&gt;##lang.objectlock.date_mod##&lt;/td&gt;
      &lt;td&gt;##objectlock.date_mod##&lt;/td&gt;
      &lt;/tr&gt;
      &lt;/tbody&gt;
      &lt;/table&gt;
      &lt;p&gt;&lt;span style=\"font-size: small;\"&gt;Hello ##objectlock.lockedby.firstname##,&lt;br /&gt;Could go to this item and unlock it for me?&lt;br /&gt;Thank you,&lt;br /&gt;Regards,&lt;br /&gt;##objectlock.requester.firstname## ##objectlock.requester.lastname##&lt;/span&gt;&lt;/p&gt;');

### Dump table glpi_notimportedemails

DROP TABLE IF EXISTS `glpi_notimportedemails`;
CREATE TABLE `glpi_notimportedemails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from` varchar(255) NOT NULL,
  `to` varchar(255) NOT NULL,
  `mailcollectors_id` int(11) NOT NULL DEFAULT '0',
  `date` datetime NOT NULL,
  `subject` text,
  `messageid` varchar(255) NOT NULL,
  `reason` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `users_id` (`users_id`),
  KEY `mailcollectors_id` (`mailcollectors_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


### Dump table glpi_objectlocks

DROP TABLE IF EXISTS `glpi_objectlocks`;
CREATE TABLE `glpi_objectlocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Type of locked object',
  `items_id` int(11) NOT NULL COMMENT 'RELATION to various tables, according to itemtype (ID)',
  `users_id` int(11) NOT NULL COMMENT 'id of the locker',
  `date_mod` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Timestamp of the lock',
  PRIMARY KEY (`id`),
  UNIQUE KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_operatingsystemarchitectures

DROP TABLE IF EXISTS `glpi_operatingsystemarchitectures`;
CREATE TABLE `glpi_operatingsystemarchitectures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_operatingsystems

DROP TABLE IF EXISTS `glpi_operatingsystems`;
CREATE TABLE `glpi_operatingsystems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_operatingsystemservicepacks

DROP TABLE IF EXISTS `glpi_operatingsystemservicepacks`;
CREATE TABLE `glpi_operatingsystemservicepacks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_operatingsystemversions

DROP TABLE IF EXISTS `glpi_operatingsystemversions`;
CREATE TABLE `glpi_operatingsystemversions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_peripheralmodels

DROP TABLE IF EXISTS `glpi_peripheralmodels`;
CREATE TABLE `glpi_peripheralmodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_peripherals

DROP TABLE IF EXISTS `glpi_peripherals`;
CREATE TABLE `glpi_peripherals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `contact` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_num` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `peripheraltypes_id` int(11) NOT NULL DEFAULT '0',
  `peripheralmodels_id` int(11) NOT NULL DEFAULT '0',
  `brand` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `is_global` tinyint(1) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  `ticket_tco` decimal(20,4) DEFAULT '0.0000',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_template` (`is_template`),
  KEY `is_global` (`is_global`),
  KEY `entities_id` (`entities_id`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `groups_id` (`groups_id`),
  KEY `users_id` (`users_id`),
  KEY `locations_id` (`locations_id`),
  KEY `peripheralmodels_id` (`peripheralmodels_id`),
  KEY `states_id` (`states_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `peripheraltypes_id` (`peripheraltypes_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `date_mod` (`date_mod`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `serial` (`serial`),
  KEY `otherserial` (`otherserial`),
  KEY `date_creation` (`date_creation`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_peripheraltypes

DROP TABLE IF EXISTS `glpi_peripheraltypes`;
CREATE TABLE `glpi_peripheraltypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_phonemodels

DROP TABLE IF EXISTS `glpi_phonemodels`;
CREATE TABLE `glpi_phonemodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_phonepowersupplies

DROP TABLE IF EXISTS `glpi_phonepowersupplies`;
CREATE TABLE `glpi_phonepowersupplies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_phones

DROP TABLE IF EXISTS `glpi_phones`;
CREATE TABLE `glpi_phones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `contact` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_num` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `firmware` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `phonetypes_id` int(11) NOT NULL DEFAULT '0',
  `phonemodels_id` int(11) NOT NULL DEFAULT '0',
  `brand` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phonepowersupplies_id` int(11) NOT NULL DEFAULT '0',
  `number_line` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `have_headset` tinyint(1) NOT NULL DEFAULT '0',
  `have_hp` tinyint(1) NOT NULL DEFAULT '0',
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `is_global` tinyint(1) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  `ticket_tco` decimal(20,4) DEFAULT '0.0000',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_template` (`is_template`),
  KEY `is_global` (`is_global`),
  KEY `entities_id` (`entities_id`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `groups_id` (`groups_id`),
  KEY `users_id` (`users_id`),
  KEY `locations_id` (`locations_id`),
  KEY `phonemodels_id` (`phonemodels_id`),
  KEY `phonepowersupplies_id` (`phonepowersupplies_id`),
  KEY `states_id` (`states_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `phonetypes_id` (`phonetypes_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `date_mod` (`date_mod`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `serial` (`serial`),
  KEY `otherserial` (`otherserial`),
  KEY `date_creation` (`date_creation`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_phonetypes

DROP TABLE IF EXISTS `glpi_phonetypes`;
CREATE TABLE `glpi_phonetypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_planningrecalls

DROP TABLE IF EXISTS `glpi_planningrecalls`;
CREATE TABLE `glpi_planningrecalls` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `before_time` int(11) NOT NULL DEFAULT '-10',
  `when` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`itemtype`,`items_id`,`users_id`),
  KEY `users_id` (`users_id`),
  KEY `before_time` (`before_time`),
  KEY `when` (`when`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

